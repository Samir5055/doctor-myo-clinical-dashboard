import { Component, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Patient, View, healthClass, Health } from '../models';
import { AppService } from '../app.service';

@Component({
  selector: 'app-patient-status',
  template: `
    <!-- ── Page heading ── -->
    <section class="page-heading">
      <div>
        <button class="text-button back-link" (click)="back.emit()">
          <span style="transform:rotate(180deg);display:flex"><app-icon name="arrow" [size]="15"></app-icon></span>All patients
        </button>
        <p class="eyebrow">Patient status</p>
        <h1>{{patient.name}}</h1>
        <p>{{patient.age}} years &middot; {{patient.condition}}</p>
      </div>

      <!-- Doctor Clinical State Selector -->
      <div class="doctor-state-wrapper">
        <span class="doctor-state-title">Clinical State:</span>
        <div class="doctor-state-group">
          <button type="button" class="doc-state-btn good"
                  [class.active]="editHealthStatus === 'Improving'"
                  (click)="setHealthStatus('Improving')">
            🟢 Improving
          </button>
          <button type="button" class="doc-state-btn neutral"
                  [class.active]="editHealthStatus === 'Stable'"
                  (click)="setHealthStatus('Stable')">
            🟡 Stable
          </button>
          <button type="button" class="doc-state-btn warn"
                  [class.active]="editHealthStatus === 'Needs attention'"
                  (click)="setHealthStatus('Needs attention')">
            🔴 Needs attention
          </button>
        </div>
      </div>
    </section>

    <!-- ── KPI cards ── -->
    <div class="metrics-grid">
      <app-metric-card icon="trend"   label="Recovery score"  [value]="patient.recovery + '%'"      detail="Overall progress"></app-metric-card>
      <app-metric-card icon="clock"   label="Training today"  [value]="patient.minutes + ' min'"    detail="Goal: 30 min"        tone="mint"></app-metric-card>
      <app-metric-card icon="signal"  label="Current streak"  [value]="patient.streak + ' days'"   detail="Consecutive sessions" tone="amber"></app-metric-card>
    </div>

    <!-- ══════════════════════════════════════════════════
         MUSCLE HEALTH DASHBOARD
    ══════════════════════════════════════════════════ -->
    <section class="panel mh-panel">

      <!-- Header -->
      <div class="mh-header">
        <div class="mh-header-left">
          <div class="mh-header-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M9 12l2 2 4-4"/><path d="M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0z"/>
            </svg>
          </div>
          <div>
            <h2 class="mh-title">Muscle Health Dashboard</h2>
            <p class="mh-subtitle">Live monitoring · Manual override · 6-week trend</p>
          </div>
        </div>
        <div class="mh-overall-badge" [ngClass]="overallClass">
          <span class="mh-badge-score">{{overallScore}}%</span>
          <span class="mh-badge-label">{{overallLabel}}</span>
        </div>
      </div>

      <!-- ① Manual Input Section -->
      <div class="mh-input-section">
        <p class="mh-section-label-plain">📝 Manual Input — Set values to update all statistics instantly</p>
        <div class="mh-inputs-grid">

          <!-- Overall Muscle Health -->
          <div class="mh-input-card">
            <label class="mh-input-label">
              <span class="mh-input-dot" style="background:#10b981"></span>
              Overall Muscle Health
            </label>
            <div class="mh-slider-row">
              <input type="range" min="0" max="100" step="1" [(ngModel)]="editHealth"
                     (ngModelChange)="onHealthChange()" class="mh-slider mh-slider-green"/>
              <input type="number" min="0" max="100" [(ngModel)]="editHealth"
                     (ngModelChange)="onHealthChange()" class="mh-num-input"/>
            </div>
            <div class="mh-mini-bar"><div class="mh-mini-fill" [style.width.%]="editHealth" style="background:#10b981"></div></div>
            <div class="mh-ticks">
              <span *ngFor="let t of ticks">{{t}}%</span>
            </div>
          </div>

          <!-- Strength -->
          <div class="mh-input-card">
            <label class="mh-input-label">
              <span class="mh-input-dot" style="background:#10b981"></span>
              💪 Strength
            </label>
            <div class="mh-slider-row">
              <input type="range" min="0" max="100" step="1" [(ngModel)]="editStrength"
                     (ngModelChange)="recalc()" class="mh-slider mh-slider-green"/>
              <input type="number" min="0" max="100" [(ngModel)]="editStrength"
                     (ngModelChange)="recalc()" class="mh-num-input"/>
            </div>
            <div class="mh-mini-bar"><div class="mh-mini-fill" [style.width.%]="editStrength" style="background:#10b981"></div></div>
            <div class="mh-ticks">
              <span *ngFor="let t of ticks">{{t}}%</span>
            </div>
          </div>

          <!-- Endurance -->
          <div class="mh-input-card">
            <label class="mh-input-label">
              <span class="mh-input-dot" style="background:#818cf8"></span>
              🏃 Endurance
            </label>
            <div class="mh-slider-row">
              <input type="range" min="0" max="100" step="1" [(ngModel)]="editEndurance"
                     (ngModelChange)="recalc()" class="mh-slider mh-slider-indigo"/>
              <input type="number" min="0" max="100" [(ngModel)]="editEndurance"
                     (ngModelChange)="recalc()" class="mh-num-input"/>
            </div>
            <div class="mh-mini-bar"><div class="mh-mini-fill" [style.width.%]="editEndurance" style="background:#818cf8"></div></div>
            <div class="mh-ticks">
              <span *ngFor="let t of ticks">{{t}}%</span>
            </div>
          </div>

          <!-- Flexibility -->
          <div class="mh-input-card">
            <label class="mh-input-label">
              <span class="mh-input-dot" style="background:#f59e0b"></span>
              🤸 Flexibility
            </label>
            <div class="mh-slider-row">
              <input type="range" min="0" max="100" step="1" [(ngModel)]="editFlexibility"
                     (ngModelChange)="recalc()" class="mh-slider mh-slider-amber"/>
              <input type="number" min="0" max="100" [(ngModel)]="editFlexibility"
                     (ngModelChange)="recalc()" class="mh-num-input"/>
            </div>
            <div class="mh-mini-bar"><div class="mh-mini-fill" [style.width.%]="editFlexibility" style="background:#f59e0b"></div></div>
            <div class="mh-ticks">
              <span *ngFor="let t of ticks">{{t}}%</span>
            </div>
          </div>

        </div>

        <!-- Save + Reset buttons -->
        <div class="mh-btn-row">
          <button class="mh-save-btn" (click)="saveChanges()" [class.mh-saved]="savedMessage">
            <span *ngIf="!savedMessage">💾 Save Changes</span>
            <span *ngIf="savedMessage">✅ Saved!</span>
          </button>
          <button class="mh-reset-btn" (click)="resetToOriginal()">↺ Reset to original</button>
        </div>
      </div>

      <!-- ② Estimated MyoArm Wearing Hours -->
      <div class="mh-wearing-estimate" [ngClass]="overallClass">
        <div class="mh-wear-left">
          <div class="mh-wear-icon">🦾</div>
          <div>
            <p class="mh-wear-title">Estimated MyoArm Wearing Time</p>
            <p class="mh-wear-sub">Calculated from Strength (40%) · Endurance (35%) · Flexibility (25%)</p>
          </div>
        </div>
        <div class="mh-wear-right">
          <span class="mh-wear-hours">{{estimatedWearingHours}} hrs</span>
          <span class="mh-wear-label">/ day recommended</span>
          <span class="mh-wear-desc">{{wearingHoursDesc}}</span>
        </div>
      </div>

      <!-- ③ 3 circular gauge rings -->
      <div class="mh-gauges">

        <div class="mh-gauge-card">
          <div class="mh-gauge-wrap">
            <svg viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="50" fill="none" stroke="#e8f5e9" stroke-width="10"/>
              <circle cx="60" cy="60" r="50" fill="none" stroke="#10b981" stroke-width="10"
                      [attr.stroke-dasharray]="dash(editStrength) + ' 314.2'"
                      stroke-dashoffset="78.5" stroke-linecap="round"
                      style="transition: stroke-dasharray 0.4s ease"/>
              <text x="60" y="55" text-anchor="middle" font-size="20" font-weight="900" class="mh-gauge-val" fill="#065f46">{{editStrength}}</text>
              <text x="60" y="72" text-anchor="middle" font-size="10" class="mh-gauge-max" fill="#374151">/ 100</text>
            </svg>
          </div>
          <span class="mh-gauge-name">💪 Strength</span>
          <span class="mh-gauge-tag" [ngClass]="tagClass(editStrength)">{{tag(editStrength)}}</span>
        </div>

        <div class="mh-gauge-card mh-gauge-center">
          <div class="mh-gauge-wrap mh-gauge-big">
            <svg viewBox="0 0 140 140">
              <circle cx="70" cy="70" r="58" fill="none" stroke="#e2e8f0" stroke-width="12"/>
              <circle cx="70" cy="70" r="58" fill="none" [attr.stroke]="overallColor" stroke-width="12"
                      [attr.stroke-dasharray]="dash58(overallScore) + ' 364.4'"
                      stroke-dashoffset="91.1" stroke-linecap="round"
                      style="transition: stroke-dasharray 0.4s ease, stroke 0.4s ease"/>
              <text x="70" y="65" text-anchor="middle" font-size="26" font-weight="900" class="mh-gauge-val" [attr.fill]="overallColor">{{overallScore}}</text>
              <text x="70" y="82" text-anchor="middle" font-size="11" class="mh-gauge-max" fill="#374151">Overall %</text>
            </svg>
          </div>
          <span class="mh-gauge-name" style="font-size:1rem;">⚡ Overall Health</span>
          <span class="mh-gauge-tag" style="font-size:0.85rem;" [ngClass]="tagClass(overallScore)">{{overallLabel}}</span>
        </div>

        <div class="mh-gauge-card">
          <div class="mh-gauge-wrap">
            <svg viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="50" fill="none" stroke="#ede9fe" stroke-width="10"/>
              <circle cx="60" cy="60" r="50" fill="none" stroke="#818cf8" stroke-width="10"
                      [attr.stroke-dasharray]="dash(editEndurance) + ' 314.2'"
                      stroke-dashoffset="78.5" stroke-linecap="round"
                      style="transition: stroke-dasharray 0.4s ease"/>
              <text x="60" y="55" text-anchor="middle" font-size="20" font-weight="900" class="mh-gauge-val" fill="#3730a3">{{editEndurance}}</text>
              <text x="60" y="72" text-anchor="middle" font-size="10" class="mh-gauge-max" fill="#374151">/ 100</text>
            </svg>
          </div>
          <span class="mh-gauge-name">🏃 Endurance</span>
          <span class="mh-gauge-tag" [ngClass]="tagClass(editEndurance)">{{tag(editEndurance)}}</span>
        </div>

      </div>

      <!-- Flexibility bar (full width) -->
      <div class="mh-flex-bar-wrap">
        <div class="mh-flex-bar-label">
          <span>🤸 Flexibility</span>
          <strong style="color:#d97706">{{editFlexibility}}% — {{tag(editFlexibility)}}</strong>
        </div>
        <div class="mh-flex-bar-track">
          <div class="mh-flex-bar-fill" [style.width.%]="editFlexibility"
               [style.background]="'linear-gradient(90deg, #f59e0b, #fbbf24)'"></div>
        </div>
      </div>

      <!-- ④ Live stats row (all computed from manual inputs) -->
      <div class="mh-stats-row">
        <div class="mh-stat-block" [ngClass]="overallClass">
          <div class="mh-stat-icon">📊</div>
          <strong class="mh-stat-num">{{overallScore}}%</strong>
          <span class="mh-stat-lbl">Overall Score</span>
        </div>
        <div class="mh-stat-block">
          <div class="mh-stat-icon">📈</div>
          <strong class="mh-stat-num" [style.color]="weeklyGain >= 0 ? '#059669' : '#dc2626'">{{weeklyGain > 0 ? '+' : ''}}{{weeklyGain}}%</strong>
          <span class="mh-stat-lbl">Week Change</span>
        </div>
        <div class="mh-stat-block">
          <div class="mh-stat-icon">⚡</div>
          <strong class="mh-stat-num">{{recoveryPace}}</strong>
          <span class="mh-stat-lbl">Recovery Pace</span>
        </div>
        <div class="mh-stat-block">
          <div class="mh-stat-icon">🎯</div>
          <strong class="mh-stat-num">{{fitnessGoal}}%</strong>
          <span class="mh-stat-lbl">Goal Progress</span>
        </div>
        <div class="mh-stat-block">
          <div class="mh-stat-icon">🏋️</div>
          <strong class="mh-stat-num">{{intensityLevel}}</strong>
          <span class="mh-stat-lbl">Training Intensity</span>
        </div>
        <div class="mh-stat-block">
          <div class="mh-stat-icon">🔥</div>
          <strong class="mh-stat-num">{{patient.streak}} days</strong>
          <span class="mh-stat-lbl">Active Streak</span>
        </div>
      </div>

      <!-- ⑤ 6-week trend chart -->
      <div class="mh-chart-section">
        <div class="mh-chart-header">
          <span class="mh-section-label" style="margin:0">📉 6-Week Muscle Health Trend</span>
          <span class="mh-chart-delta" [ngClass]="weeklyGain >= 0 ? 'up' : 'down'">
            {{weeklyGain >= 0 ? '▲' : '▼'}} {{weeklyGain >= 0 ? '+' : ''}}{{weeklyGain}}% vs last week
          </span>
        </div>
        <div class="mh-chart-box">
          <div class="mh-chart-y">
            <span>100</span><span>75</span><span>50</span><span>25</span><span>0</span>
          </div>
          <div class="mh-chart-area">
            <svg viewBox="0 0 400 110" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="0" y1="5"  x2="400" y2="5"  class="mh-trend-grid" stroke="#e5e7eb" stroke-width="1" stroke-dasharray="5 5"/>
              <line x1="0" y1="30" x2="400" y2="30" class="mh-trend-grid" stroke="#e5e7eb" stroke-width="1" stroke-dasharray="5 5"/>
              <line x1="0" y1="55" x2="400" y2="55" class="mh-trend-grid" stroke="#e5e7eb" stroke-width="1" stroke-dasharray="5 5"/>
              <line x1="0" y1="80" x2="400" y2="80" class="mh-trend-grid" stroke="#e5e7eb" stroke-width="1" stroke-dasharray="5 5"/>
              <line x1="0" y1="105" x2="400" y2="105" class="mh-trend-grid" stroke="#e5e7eb" stroke-width="1" stroke-dasharray="5 5"/>
              <!-- Gradient area fill -->
              <defs>
                <linearGradient id="chartGrad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#6366f1" stop-opacity="0.25"/>
                  <stop offset="100%" stop-color="#6366f1" stop-opacity="0"/>
                </linearGradient>
              </defs>
              <polygon [attr.points]="chartArea" fill="url(#chartGrad2)"/>
              <!-- Trend line -->
              <polyline [attr.points]="chartLine" fill="none" stroke="#6366f1"
                        stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
              <!-- Data dots -->
              <circle *ngFor="let pt of chartPoints; let i = index"
                      [attr.cx]="pt.x" [attr.cy]="pt.y" r="5"
                      fill="#fff" stroke="#6366f1" stroke-width="2.5"/>
              <!-- Score labels above dots -->
              <text *ngFor="let pt of chartPoints; let i = index"
                    [attr.x]="pt.x" [attr.y]="pt.y - 10"
                    text-anchor="middle" font-size="9" font-weight="700" class="mh-dot-label" fill="#4f46e5">
                {{patient.muscleHistory[i].score}}
              </text>
            </svg>
            <!-- X-axis labels -->
            <div class="mh-chart-x">
              <span *ngFor="let h of patient.muscleHistory">{{h.week}}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- ⑥ Recommendation banner -->
      <div class="mh-recommendation" [ngClass]="recClass">
        <span class="mh-rec-icon">{{recIcon}}</span>
        <div>
          <strong>{{recTitle}}</strong>
          <p>{{recText}}</p>
        </div>
      </div>

    </section>

    <!-- ── MYO Arm Wearing Time ── -->
    <section class="panel ps-panel">
      <div class="panel-header">
        <div class="metric-icon blue"><app-icon name="clock"></app-icon></div>
        <div><h2>MYO Arm Wearing Time</h2><p>Daily usage and total wearing history &middot; Doctor editable</p></div>
      </div>
      <div class="ps-inline-grid">
        <div class="ps-inline-card ps-editable-box">
          <label class="ps-box-label">Wearing Hours / Day</label>
          <div class="ps-input-flex">
            <input type="number" step="0.5" min="0" max="16" [(ngModel)]="editWearingHours" (ngModelChange)="saveWearingTime()" class="ps-num-box" />
            <span class="ps-box-unit">hrs</span>
          </div>
          <span class="ps-box-sub">Avg daily wear time</span>
        </div>
        <div class="ps-inline-card ps-editable-box">
          <label class="ps-box-label">Total Wearing Days</label>
          <div class="ps-input-flex">
            <input type="number" min="0" max="3650" [(ngModel)]="editTotalWearingDays" (ngModelChange)="saveWearingTime()" class="ps-num-box" />
            <span class="ps-box-unit">days</span>
          </div>
          <span class="ps-box-sub">Total tracked days</span>
        </div>
        <div class="ps-inline-card">
          <strong style="color:#4338ca;">{{patient.streak}} days</strong>
          <span>Current streak</span>
        </div>
        <div class="ps-inline-card">
          <strong style="color:#0369a1;">{{patient.minutes}} min</strong>
          <span>Last session</span>
        </div>
      </div>
    </section>

    <!-- ── Muscle Recovery ── -->
    <section class="panel ps-panel">
      <div class="panel-header">
        <div class="metric-icon mint"><app-icon name="trend"></app-icon></div>
        <div><h2>Muscle Recovery</h2><p>Overall recovery progress and trajectory &middot; Doctor editable</p></div>
      </div>
      <div class="ps-inline-grid">
        <div class="ps-inline-card ps-editable-box">
          <label class="ps-box-label">Recovery Score</label>
          <div class="ps-input-flex">
            <input type="number" min="0" max="100" [(ngModel)]="editRecoveryScore" (ngModelChange)="saveRecoveryStats()" class="ps-num-box" />
            <span class="ps-box-unit">%</span>
          </div>
          <span class="ps-box-sub">Overall progress</span>
        </div>
        <div class="ps-inline-card ps-editable-box">
          <label class="ps-box-label">Recovery Pace</label>
          <div class="ps-input-flex">
            <select [(ngModel)]="editRecoveryPace" (ngModelChange)="saveRecoveryStats()" class="ps-select-box">
              <option value="Fast">⚡ Fast</option>
              <option value="Good">🟢 Good</option>
              <option value="Moderate">🟡 Moderate</option>
              <option value="Slow">🔴 Slow</option>
            </select>
          </div>
          <span class="ps-box-sub">Pace rate</span>
        </div>
        <div class="ps-inline-card">
          <strong style="color:#047857;">{{patient.health}}</strong>
          <span>Health status</span>
        </div>
        <div class="ps-inline-card">
          <strong style="color:#2563eb;">{{patient.accuracy}}%</strong>
          <span>Signal accuracy</span>
        </div>
      </div>
    </section>

    <!-- ── Recommended Training Plan ── -->
    <section class="panel ps-panel">
      <div class="panel-header">
        <div class="metric-icon amber"><app-icon name="target"></app-icon></div>
        <div><h2>Recommended Training</h2><p>Personalised exercises based on current muscle health ({{overallScore}}%) &middot; Doctor curated</p></div>
      </div>
      <ul class="ps-training-list">
        <li *ngFor="let item of patient.trainingPlan; let i = index" class="ps-training-item">
          <span class="ps-training-num">{{i + 1}}</span>
          <span class="ps-training-name">{{item.name}}</span>
          <div style="display:flex; align-items:center; gap:8px;">
            <a [href]="item.url" target="_blank" class="ps-yt-btn" title="Watch on YouTube">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8z"/>
                <polygon fill="white" points="9.75,15.02 15.5,12 9.75,8.98"/>
              </svg>
              Watch
            </a>
            <button type="button" class="ps-del-btn" (click)="deleteTraining(i)" title="Delete exercise">✕</button>
          </div>
        </li>
      </ul>

      <!-- Doctor Add/Choose Training Form -->
      <div class="ps-add-panel">
        <div class="ps-add-title">➕ Add & Choose Training Exercise</div>
        <div class="ps-add-grid">
          <label class="ps-add-label">
            <span>Choose from Presets:</span>
            <select class="ps-form-input" [(ngModel)]="selectedPresetTraining" (change)="onPresetTrainingChange()">
              <option value="">-- Choose preset training --</option>
              <option *ngFor="let t of presetTrainings" [value]="t">{{t}}</option>
            </select>
          </label>
          <label class="ps-add-label">
            <span>Or Type Exercise Name:</span>
            <input class="ps-form-input" [(ngModel)]="newTrainingName" placeholder="e.g. Dual-channel co-contraction drill" />
          </label>
          <label class="ps-add-label" style="grid-column: 1 / -1;">
            <span>YouTube Link (optional, auto-generated if blank):</span>
            <input class="ps-form-input" [(ngModel)]="newTrainingUrl" placeholder="https://www.youtube.com/..." />
          </label>
        </div>
        <button type="button" class="ps-add-submit-btn" (click)="addTraining()">
          ➕ Add Exercise to Patient Plan
        </button>
      </div>

      <div class="mh-training-note" [ngClass]="recClass" style="margin-top:14px;">
        <strong>{{intensityLevel}} intensity recommended</strong> based on current muscle health score of {{overallScore}}%.
      </div>
    </section>

    <!-- ── Prescribed Medicines ── -->
    <section class="panel ps-panel">
      <div class="panel-header">
        <div class="metric-icon" style="background:rgba(239,68,68,0.12);color:#ef4444;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
          </svg>
        </div>
        <div><h2>Prescribed Medicines</h2><p>Medication plan based on patient condition &middot; Doctor editable</p></div>
      </div>
      <div class="ps-med-table">
        <div class="ps-med-header" style="grid-template-columns: 1.5fr 0.8fr 1.4fr 2fr 0.5fr;">
          <span>Medicine</span><span>Dose</span><span>Frequency</span><span>Purpose</span><span style="text-align:center;">Action</span>
        </div>
        <div *ngFor="let m of patient.medicines; let i = index" class="ps-med-row" [class.ps-med-alt]="i % 2 === 1" style="grid-template-columns: 1.5fr 0.8fr 1.4fr 2fr 0.5fr;">
          <span class="ps-med-name">💊 {{m.name}}</span>
          <span class="ps-med-dose">{{m.dose}}</span>
          <span class="ps-med-freq">{{m.frequency}}</span>
          <span class="ps-med-purpose">{{m.purpose}}</span>
          <span class="ps-med-action">
            <button type="button" class="ps-del-btn" (click)="deleteMedicine(i)" title="Remove medicine">✕</button>
          </span>
        </div>
      </div>

      <!-- Doctor Add Medicine Form -->
      <div class="ps-add-panel">
        <div class="ps-add-title">➕ Prescribe New Medicine</div>
        <div class="ps-add-grid">
          <label class="ps-add-label">
            <span>Choose from Presets:</span>
            <select class="ps-form-input" [(ngModel)]="selectedPresetMedicine" (change)="onPresetMedicineChange()">
              <option value="">-- Choose preset medicine --</option>
              <option *ngFor="let pm of presetMedicines" [value]="pm.name">{{pm.name}} ({{pm.dose}})</option>
            </select>
          </label>
          <label class="ps-add-label">
            <span>Medicine Name:</span>
            <input class="ps-form-input" [(ngModel)]="newMedName" placeholder="e.g. Baclofen" />
          </label>
          <label class="ps-add-label">
            <span>Dose:</span>
            <input class="ps-form-input" [(ngModel)]="newMedDose" placeholder="e.g. 10 mg" />
          </label>
          <label class="ps-add-label">
            <span>Frequency:</span>
            <input class="ps-form-input" [(ngModel)]="newMedFrequency" placeholder="e.g. Twice daily" />
          </label>
          <label class="ps-add-label" style="grid-column: 1 / -1;">
            <span>Clinical Purpose:</span>
            <input class="ps-form-input" [(ngModel)]="newMedPurpose" placeholder="e.g. Muscle spasm relief and EMG signal stability" />
          </label>
        </div>
        <button type="button" class="ps-add-submit-btn" (click)="addMedicine()">
          💊 Prescribe Medicine
        </button>
      </div>
    </section>

    <!-- ── Session History & Calendar ── -->
    <section class="panel ps-panel">
      <div class="panel-header">
        <div class="metric-icon" style="background:rgba(99,102,241,0.12);color:#6366f1;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
            <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
          </svg>
        </div>
        <div><h2>Session History & Activity Calendar</h2><p>Past training records and session timeline calendar</p></div>
      </div>

      <!-- Interactive Session Calendar -->
      <div class="ps-calendar-card">
        <div class="ps-cal-header">
          <div class="ps-cal-nav">
            <button type="button" class="ps-cal-arrow" (click)="prevMonth()">◀</button>
            <strong class="ps-cal-month-title">{{calMonthName}} {{calYear}}</strong>
            <button type="button" class="ps-cal-arrow" (click)="nextMonth()">▶</button>
          </div>
          <div class="ps-cal-legend">
            <span class="ps-legend-item"><i class="ps-legend-dot active-dot"></i> Completed Session ({{sessionsThisMonthCount}})</span>
            <span class="ps-legend-item"><i class="ps-legend-dot today-dot"></i> Today</span>
          </div>
        </div>

        <div class="ps-cal-weekdays">
          <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
        </div>

        <div class="ps-cal-grid">
          <div *ngFor="let day of calendarDays" class="ps-cal-cell"
               [class.empty]="!day.date"
               [class.has-session]="day.session"
               [class.is-today]="day.isToday"
               [class.selected]="selectedDay?.dayNum === day.dayNum"
               (click)="selectDay(day)">
            <span class="ps-day-num" *ngIf="day.date">{{day.dayNum}}</span>
            <span class="ps-session-indicator" *ngIf="day.session">
              <span class="ps-indicator-dot"></span>
              <small class="ps-indicator-min">{{day.session.duration}}m</small>
            </span>
          </div>
        </div>

        <!-- Selected Session Detail Popup/Banner -->
        <div class="ps-cal-detail" *ngIf="selectedDay?.session">
          <div class="ps-cal-detail-header">
            <strong>📅 Session Details &mdash; {{selectedDay.session.date}}</strong>
            <span class="health-pill good">{{selectedDay.session.duration}} min &middot; {{selectedDay.session.accuracy}}% accuracy</span>
          </div>
          <p class="ps-cal-detail-notes">{{selectedDay.session.notes}}</p>
        </div>
      </div>

      <!-- Past Sessions List -->
      <div class="ps-sessions" style="margin-top:20px;">
        <h3 class="ps-sessions-title" style="font-size:0.92rem; font-weight:700; margin:0 0 10px;">Recorded Training Sessions</h3>
        <div *ngFor="let s of patient.sessionHistory" class="ps-session-row">
          <div class="ps-session-header">
            <strong>{{s.date}}</strong>
            <span class="health-pill neutral">{{s.duration}} min &middot; {{s.accuracy}}% accuracy</span>
          </div>
          <p class="ps-session-note">{{s.notes}}</p>
        </div>
        <p class="empty-state" *ngIf="!patient.sessionHistory || patient.sessionHistory.length === 0" style="padding:14px; background:#f8fafc; border-radius:10px; color:#64748b; font-size:0.85rem; margin:0;">
          No past sessions recorded yet for this patient.
        </p>
      </div>
    </section>

    <!-- ── Quick actions ── -->
    <div class="ps-actions">
      <button class="primary-button" (click)="setView.emit('signal')">
        <app-icon name="signal" [size]="17"></app-icon>View live signal
      </button>
    </div>
  `,
  styles: [`
    /* ── Shared card shells ── */
    .ps-panel { margin-bottom: 1.4rem; }

    /* Doctor Clinical State Switcher */
    .doctor-state-wrapper {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 6px;
    }
    @media (max-width: 640px) {
      .doctor-state-wrapper { align-items: flex-start; margin-top: 10px; }
    }
    .doctor-state-title { font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: #000000 !important; }
    .doctor-state-group {
      display: flex;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      border-radius: 99px;
      padding: 3px;
      gap: 3px;
    }
    .doc-state-btn { border: none; background: transparent; padding: 6px 14px; border-radius: 99px; font-size: 0.78rem; font-weight: 700; color: #000000 !important; cursor: pointer; transition: all 0.2s ease; }
    .doc-state-btn:hover {
      color: #111827;
      background: rgba(255,255,255,0.7);
    }
    .doc-state-btn.good.active {
      background: #10b981;
      color: #ffffff;
      box-shadow: 0 2px 8px rgba(16,185,129,0.35);
    }
    .doc-state-btn.neutral.active {
      background: #f59e0b;
      color: #ffffff;
      box-shadow: 0 2px 8px rgba(245,158,11,0.35);
    }
    .doc-state-btn.warn.active {
      background: #ef4444;
      color: #ffffff;
      box-shadow: 0 2px 8px rgba(239,68,68,0.35);
    }
    .ps-inline-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 14px; margin-top: 1rem; }
    @media (max-width:760px) { .ps-inline-grid { grid-template-columns: 1fr 1fr; } }
    .ps-inline-card {
      background: #f7f9fc;
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 18px 20px;
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-height: 80px;
      justify-content: center;
    }
    .ps-inline-card strong { font-size: 1.5rem; font-weight: 800; color: var(--ink); line-height: 1.1; }
    .ps-inline-card span   { font-size: 0.75rem; color: var(--muted); font-weight: 500; }
    .ps-training-list  { margin:1rem 0 0; padding:0; list-style:none; display:flex; flex-direction:column; gap:0.55rem; }
    .ps-training-item  { display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f4f9f8; border:1px solid #d4ece8; border-radius:10px; font-size:0.9rem; color:var(--ink); }
    .ps-training-num   { width:28px; height:28px; background:var(--blue); color:#fff; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.75rem; font-weight:800; flex-shrink:0; }
    .ps-training-name  { flex:1; }
    .ps-yt-btn {
      display: inline-flex; align-items: center; gap: 5px;
      background: #ff0000; color: #fff; border-radius: 6px;
      padding: 5px 10px; font-size: 0.75rem; font-weight: 700;
      text-decoration: none; flex-shrink: 0;
      transition: background 0.2s;
    }
    .ps-yt-btn:hover { background: #cc0000; }
    .ps-sessions       { margin-top:1rem; display:flex; flex-direction:column; gap:0.85rem; }
    .ps-session-row    { padding:14px 16px; background:#f7f9fc; border:1px solid var(--line); border-radius:12px; }
    .ps-session-header { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px; }
    .ps-session-header strong { font-size:0.9rem; }
    .ps-session-note { margin: 0.4rem 0 0; color: #000000 !important; font-size: 0.83rem; font-weight: 500; line-height: 1.5; }
    .ps-actions        { display:flex; gap:12px; flex-wrap:wrap; margin-top:0.5rem; margin-bottom:1.5rem; }
    .ps-med-table { margin-top:1rem; border-radius:12px; overflow:hidden; border:1px solid var(--line); }
    .ps-med-header { display:grid; grid-template-columns:1.5fr 0.8fr 1.4fr 2fr; background:#f0faf8; padding:10px 14px; font-size:0.72rem; font-weight:700; text-transform:uppercase; letter-spacing:0.08em; color:var(--muted); border-bottom:1px solid var(--line); gap:8px; }
    .ps-med-row  { display:grid; grid-template-columns:1.5fr 0.8fr 1.4fr 2fr; padding:11px 14px; gap:8px; align-items:center; font-size:0.85rem; }
    .ps-med-alt  { background:#f9fbfa; }
    .ps-med-name { font-weight:700; color:var(--ink); }
    .ps-med-dose { color:#ef4444; font-weight:600; }
    .ps-med-freq { color:var(--muted); font-size:0.8rem; }
    .ps-med-purpose { color:var(--ink); font-size:0.82rem; }
    @media (max-width:760px) {
      .ps-med-header { display:none; }
      .ps-med-row { grid-template-columns:1fr 1fr; grid-template-rows:auto auto; }
      .ps-med-purpose { grid-column:1/-1; color:var(--muted); font-size:0.78rem; }
    }

    
    /* Editable input boxes */
    .ps-editable-box { position: relative; background: #ffffff; border-color: #cbd5e1; }
    .ps-box-label { font-size: 0.73rem; font-weight: 800; color: #000000 !important; text-transform: uppercase; letter-spacing: 0.04em; }
    .ps-input-flex { display: flex; align-items: baseline; gap: 6px; margin: 4px 0 2px; }
    .ps-num-box { width: 85px; font-size: 1.35rem; font-weight: 800; color: #0f172a; border: 1.5px solid #cbd5e1; border-radius: 8px; padding: 3px 6px; text-align: center; outline: none; background: #f8fafc; }
    .ps-num-box:focus { border-color: #3b82f6; background: #ffffff; }
    .ps-select-box { font-size: 0.95rem; font-weight: 700; color: #0f172a; border: 1.5px solid #cbd5e1; border-radius: 8px; padding: 5px 8px; outline: none; background: #f8fafc; }
    .ps-select-box:focus { border-color: #10b981; }
    .ps-box-unit { font-size: 0.85rem; font-weight: 700; color: #000000 !important; }
    .ps-box-sub { font-size: 0.72rem; font-weight: 600; color: #000000 !important; }
    .ps-del-btn { background: #ef4444; border: 1px solid #dc2626; color: #ffffff !important; border-radius: 6px; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; font-weight: 900; font-size: 0.85rem; cursor: pointer; transition: all 0.2s; }
    .ps-del-btn:hover { background: #ef4444; color: #ffffff; border-color: #dc2626; }
    .ps-add-panel { margin-top: 14px; background: #f8fafc; border: 1.5px dashed #cbd5e1; border-radius: 12px; padding: 14px 16px; }
    .ps-add-title { font-size: 0.82rem; font-weight: 700; color: #334155; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.05em; }
    .ps-add-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin-bottom: 10px; }
    .ps-add-label { display: flex; flex-direction: column; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #000000 !important; }
    .ps-form-input { border: 1px solid #cbd5e1; border-radius: 8px; padding: 7px 10px; font-size: 0.82rem; color: #0f172a; outline: none; background: #ffffff; }
    .ps-form-input:focus { border-color: #2563eb; }
    .ps-add-submit-btn { background: #10b981; color: #ffffff; border: none; border-radius: 8px; padding: 8px 16px; font-size: 0.8rem; font-weight: 700; cursor: pointer; transition: background 0.2s; }
    .ps-add-submit-btn:hover { background: #059669; }
    .ps-med-action { display: flex; justify-content: center; }

    /* Calendar */
    .ps-calendar-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 18px 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); }
    .ps-cal-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 14px; }
    .ps-cal-nav { display: flex; align-items: center; gap: 12px; }
    .ps-cal-month-title { font-size: 1.05rem; font-weight: 800; color: #0f172a; min-width: 150px; text-align: center; }
    .ps-cal-arrow { background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 8px; padding: 5px 12px; cursor: pointer; font-size: 0.85rem; font-weight: 700; color: #334155; }
    .ps-cal-arrow:hover { background: #e2e8f0; }
    .ps-cal-legend { display: flex; gap: 14px; font-size: 0.75rem; color: #000000 !important; font-weight: 700; }
    .ps-legend-item { display: flex; align-items: center; gap: 5px; }
    .ps-legend-dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; }
    .active-dot { background: #10b981; }
    .today-dot { background: #3b82f6; }
    .ps-cal-weekdays { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; font-size: 0.72rem; font-weight: 800; color: #000000 !important; text-transform: uppercase; padding: 6px 0; border-bottom: 1px solid #cbd5e1; margin-bottom: 6px; }
    .ps-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
    .ps-cal-cell { min-height: 54px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 6px; display: flex; flex-direction: column; justify-content: space-between; cursor: pointer; transition: all 0.2s; }
    .ps-cal-cell:hover:not(.empty) { background: #f1f5f9; border-color: #94a3b8; }
    .ps-cal-cell.empty { background: transparent; border-color: transparent; cursor: default; }
    .ps-cal-cell.has-session { background: #ecfdf5; border-color: #6ee7b7; }
    .ps-cal-cell.is-today { border-color: #3b82f6; box-shadow: 0 0 0 1.5px #3b82f6 inset; }
    .ps-cal-cell.selected { background: #e0f2fe; border-color: #0284c7; }
    .ps-day-num { font-size: 0.82rem; font-weight: 800; color: #000000 !important; }
    .ps-session-indicator { display: flex; align-items: center; gap: 3px; background: #10b981; color: #ffffff; border-radius: 99px; padding: 1px 5px; font-size: 0.65rem; font-weight: 700; width: fit-content; }
    .ps-indicator-dot { width: 4px; height: 4px; border-radius: 50%; background: #ffffff; }
    .ps-indicator-min { font-size: 0.65rem; }
    .ps-cal-detail { margin-top: 14px; background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 12px; padding: 12px 16px; }
    .ps-cal-detail-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px; margin-bottom: 4px; }
    .ps-cal-detail-notes { margin: 0; font-size: 0.82rem; color: #166534; }

/* ═══════════════════════════════════════════
       MUSCLE HEALTH DASHBOARD — LIGHT THEME (BLACK FONT)
    ═══════════════════════════════════════════ */
    .mh-panel {
      background: #ffffff;
      color: #111827;
      border-radius: 20px;
      padding: 28px;
      margin-bottom: 1.4rem;
      border: 1px solid #e2e8f0;
      box-shadow: 0 4px 24px rgba(0,0,0,0.07);
    }

    /* Header */
    .mh-header { display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap; margin-bottom:28px; }
    .mh-header-left { display:flex; align-items:center; gap:14px; }
    .mh-header-icon { width:44px; height:44px; background:rgba(99,102,241,0.12); border:1px solid rgba(99,102,241,0.3); border-radius:12px; display:flex; align-items:center; justify-content:center; color:#6366f1; }
    .mh-title { font-size:1.25rem; font-weight:800; color:#111827; margin:0; }
    .mh-subtitle { font-size:0.78rem; color:#6b7280; margin:3px 0 0; }
    .mh-overall-badge { display:flex; flex-direction:column; align-items:center; padding:12px 20px; border-radius:16px; border:1.5px solid; min-width:90px; }
    .mh-overall-badge.good    { background:#d1fae5; border-color:#6ee7b7; }
    .mh-overall-badge.neutral { background:#fef3c7; border-color:#fcd34d; }
    .mh-overall-badge.warn    { background:#fee2e2; border-color:#fca5a5; }
    .mh-badge-score { font-size:1.6rem; font-weight:900; line-height:1; }
    .mh-overall-badge.good .mh-badge-score { color: #000000 !important; }
    .mh-overall-badge.neutral .mh-badge-score { color: #000000 !important; }
    .mh-overall-badge.warn .mh-badge-score { color: #000000 !important; }
    .mh-badge-label { font-size: 0.72rem; font-weight: 800; color: #000000 !important; text-transform: uppercase; letter-spacing: 0.08em; margin-top: 3px; }

    /* Section label */
    .mh-section-label { font-size:0.78rem; font-weight:700; color:#374151; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:12px; display:block; }
    .mh-section-label-plain { font-size:0.83rem; font-weight:600; color:#111827; margin-bottom:12px; display:block; }

    /* Manual input section */
    .mh-input-section { background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:20px; margin-bottom:28px; }
    .mh-inputs-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:16px; margin-bottom:14px; }
    @media (max-width:760px) { .mh-inputs-grid { grid-template-columns:1fr; } }
    .mh-input-card { background:#ffffff; border:1px solid #e2e8f0; border-radius:12px; padding:14px 16px; display:flex; flex-direction:column; gap:8px; box-shadow:0 1px 4px rgba(0,0,0,0.05); }
    .mh-input-label { display:flex; align-items:center; gap:8px; font-size:0.85rem; font-weight:700; color:#111827; }
    .mh-input-dot { width:10px; height:10px; border-radius:50%; flex-shrink:0; }
    .mh-slider-row { display:flex; align-items:center; gap:10px; }
    .mh-slider { flex:1; height:6px; border-radius:3px; outline:none; cursor:pointer; border:none; -webkit-appearance:none; }
    .mh-slider-green  { accent-color:#10b981; }
    .mh-slider-indigo { accent-color:#818cf8; }
    .mh-slider-amber  { accent-color:#f59e0b; }
    .mh-num-input { width:62px; background:#ffffff; border:1.5px solid #d1d5db; border-radius:8px; padding:6px 10px; color:#111827; font-size:0.9rem; font-weight:700; text-align:center; outline:none; }
    .mh-num-input:focus { border-color:#6366f1; }
    .mh-mini-bar { height:4px; background:#e5e7eb; border-radius:2px; overflow:hidden; }
    .mh-mini-fill { height:100%; border-radius:2px; transition:width 0.3s ease; }

    /* Tick marks */
    .mh-ticks { display:flex; justify-content:space-between; padding:0 2px; }
    .mh-ticks span { font-size:0.6rem; color:#9ca3af; font-weight:500; }

    /* Buttons */
    .mh-btn-row { display:flex; gap:10px; flex-wrap:wrap; margin-top:4px; }
    .mh-save-btn { background:#10b981; border:none; color:#ffffff; border-radius:10px; padding:10px 22px; font-size:0.85rem; font-weight:700; cursor:pointer; transition:all 0.25s; display:flex; align-items:center; gap:6px; box-shadow:0 2px 8px rgba(16,185,129,0.3); }
    .mh-save-btn:hover { background:#059669; transform:translateY(-1px); box-shadow:0 4px 12px rgba(16,185,129,0.4); }
    .mh-save-btn.mh-saved { background:#059669; }
    .mh-reset-btn { background:#ffffff; border:1.5px solid #d1d5db; color:#374151; border-radius:10px; padding:10px 18px; font-size:0.82rem; font-weight:600; cursor:pointer; transition:all 0.2s; }
    .mh-reset-btn:hover { background:#f3f4f6; border-color:#9ca3af; }

    /* Wearing estimate banner */
    .mh-wearing-estimate { display:flex; align-items:center; justify-content:space-between; gap:16px; padding:18px 22px; border-radius:16px; border:1.5px solid; margin-bottom:28px; flex-wrap:wrap; }
    .mh-wearing-estimate.good    { background:#d1fae5; border-color:#6ee7b7; }
    .mh-wearing-estimate.neutral { background:#fef3c7; border-color:#fcd34d; }
    .mh-wearing-estimate.warn    { background:#fee2e2; border-color:#fca5a5; }
    .mh-wear-left { display:flex; align-items:center; gap:14px; }
    .mh-wear-icon { font-size:2rem; }
    .mh-wear-title { font-size:0.95rem; font-weight:800; color:#111827; margin:0 0 2px; }
    .mh-wear-sub   { font-size:0.72rem; color:#374151; margin:0; }
    .mh-wear-right { display:flex; flex-direction:column; align-items:flex-end; gap:2px; }
    .mh-wear-hours { font-size:2.4rem; font-weight:900; line-height:1; color:#111827; }
    .mh-wear-label { font-size:0.72rem; font-weight:600; color:#374151; text-transform:uppercase; letter-spacing:0.06em; }
    .mh-wear-desc { font-size: 0.76rem; font-weight: 600; color: #000000 !important; }

    /* Gauges */
    .mh-gauges { display:grid; grid-template-columns:1fr 1.3fr 1fr; gap:20px; margin-bottom:20px; align-items:center; }
    @media (max-width:760px) { .mh-gauges { grid-template-columns:1fr 1fr; } }
    .mh-gauge-card { display:flex; flex-direction:column; align-items:center; gap:10px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:18px; padding:20px 16px; }
    .mh-gauge-center { background:#eef2ff; border-color:#c7d2fe; }
    .mh-gauge-wrap { position:relative; }
    .mh-gauge-wrap svg { width:120px; height:120px; display:block; }
    .mh-gauge-big svg { width:140px; height:140px; }
    .mh-gauge-name  { font-size:0.88rem; font-weight:700; color:#111827; }
    .mh-gauge-tag   { font-size:0.72rem; font-weight:700; border-radius:20px; padding:3px 10px; }
    .mh-gauge-tag.good { background: #d1fae5; color: #000000 !important; font-weight: 800; border: 1px solid #a7f3d0; }
    .mh-gauge-tag.neutral { background: #fef3c7; color: #000000 !important; font-weight: 800; border: 1px solid #fde68a; }
    .mh-gauge-tag.warn { background: #fee2e2; color: #000000 !important; font-weight: 800; border: 1px solid #fca5a5; }

    /* Flexibility bar */
    .mh-flex-bar-wrap { margin-bottom:28px; }
    .mh-flex-bar-label { display:flex; justify-content:space-between; font-size:0.85rem; font-weight:600; color:#111827; margin-bottom:8px; }
    .mh-flex-bar-track { height:10px; background:#e5e7eb; border-radius:5px; overflow:hidden; }
    .mh-flex-bar-fill  { height:100%; border-radius:5px; transition:width 0.4s ease; }

    /* Stats row */
    .mh-stats-row { display:grid; grid-template-columns:repeat(6,1fr); gap:12px; margin-bottom:28px; }
    @media (max-width:900px) { .mh-stats-row { grid-template-columns:repeat(3,1fr); } }
    @media (max-width:600px) { .mh-stats-row { grid-template-columns:repeat(2,1fr); } }
    .mh-stat-block { background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:14px 10px; display:flex; flex-direction:column; align-items:center; gap:5px; text-align:center; transition:border-color 0.3s; }
    .mh-stat-block.good    { border-color:#6ee7b7; background:#f0fdf4; }
    .mh-stat-block.neutral { border-color:#fcd34d; background:#fffbeb; }
    .mh-stat-block.warn    { border-color:#fca5a5; background:#fff1f2; }
    .mh-stat-icon { font-size:1.2rem; }
    .mh-stat-num  { font-size:1.15rem; font-weight:900; color:#111827; }
    .mh-stat-lbl { font-size: 0.68rem; font-weight: 800; color: #000000 !important; text-transform: uppercase; letter-spacing: 0.06em; }

    /* Chart */
    .mh-chart-section { margin-bottom:24px; }
    .mh-chart-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; flex-wrap:wrap; gap:8px; }
    .mh-chart-delta { font-size:0.78rem; font-weight:700; border-radius:20px; padding:4px 12px; }
    .mh-chart-delta.up   { background:#d1fae5; color:#065f46; }
    .mh-chart-delta.down { background:#fee2e2; color:#991b1b; }
    .mh-chart-box { display:flex; gap:8px; }
    .mh-chart-y { display:flex; flex-direction:column; justify-content:space-between; font-size:0.65rem; color:#9ca3af; padding:4px 0 22px; min-width:28px; text-align:right; }
    .mh-chart-area { flex:1; background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:8px 10px 0; overflow:hidden; }
    .mh-chart-area svg { width:100%; height:110px; display:block; }
    .mh-chart-x { display:flex; justify-content:space-between; padding:6px 0 2px; font-size:0.7rem; color:#374151; font-weight:600; }

    /* Recommendation banner */
    .mh-recommendation { display:flex; align-items:flex-start; gap:14px; padding:16px 20px; border-radius:14px; border:1px solid; margin-top:4px; }
    .mh-recommendation.good    { background:#d1fae5; border-color:#6ee7b7; }
    .mh-recommendation.neutral { background:#fef3c7; border-color:#fcd34d; }
    .mh-recommendation.warn    { background:#fee2e2; border-color:#fca5a5; }
    .mh-rec-icon { font-size:1.6rem; flex-shrink:0; }
    .mh-recommendation strong { display:block; font-size:0.9rem; color:#111827; margin-bottom:4px; }
    .mh-recommendation p { font-size:0.82rem; color:#374151; margin:0; line-height:1.5; }

    /* Training intensity note */
    .mh-training-note { margin-top:12px; padding:10px 14px; border-radius:10px; font-size:0.82rem; color:#111827; }
    .mh-training-note.good    { background:#d1fae5; }
    .mh-training-note.neutral { background:#fef3c7; }
    .mh-training-note.warn    { background:#fee2e2; }


    /* ══════════════════════════════════════════════════════
       DARK THEME STYLES FOR PATIENT STATUS
       Palette:
         - Background: #0F172A
         - Cards:      #1E293B
         - Sidebar:    #111827
         - Primary:    #3B82F6
         - Text:       #FFFFFF
    ══════════════════════════════════════════════════════ */
    :host-context(.dark-theme) .doctor-state-group {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .doc-state-btn {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .doc-state-btn:hover {
      background: rgba(255,255,255,0.15) !important;
      color: #FFFFFF !important;
    }

    /* Muscle Health Panel */
    :host-context(.dark-theme) .mh-panel {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 24px rgba(0,0,0,0.4) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-title,
    :host-context(.dark-theme) .mh-subtitle,
    :host-context(.dark-theme) .mh-section-label,
    :host-context(.dark-theme) .mh-section-label-plain {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-subtitle {
      opacity: 0.85;
    }
    :host-context(.dark-theme) .mh-header-icon {
      background: rgba(59, 130, 246, 0.2) !important;
      border-color: rgba(59, 130, 246, 0.4) !important;
      color: #3B82F6 !important;
    }

    /* Overall Badge */
    :host-context(.dark-theme) .mh-overall-badge.good {
      background: rgba(16, 185, 129, 0.25) !important;
      border-color: #10B981 !important;
    }
    :host-context(.dark-theme) .mh-overall-badge.neutral {
      background: rgba(245, 158, 11, 0.25) !important;
      border-color: #F59E0B !important;
    }
    :host-context(.dark-theme) .mh-overall-badge.warn {
      background: rgba(239, 68, 68, 0.25) !important;
      border-color: #EF4444 !important;
    }
    :host-context(.dark-theme) .mh-badge-score,
    :host-context(.dark-theme) .mh-badge-label {
      color: #FFFFFF !important;
    }

    /* Manual Input Section */
    :host-context(.dark-theme) .mh-input-section {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .mh-input-card {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
      box-shadow: 0 2px 10px rgba(0,0,0,0.25) !important;
    }
    :host-context(.dark-theme) .mh-input-label {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-num-input {
      background: #0F172A !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-num-input:focus {
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .mh-ticks span {
      color: #FFFFFF !important;
      opacity: 0.75;
    }
    :host-context(.dark-theme) .mh-mini-bar {
      background: #334155 !important;
    }
    :host-context(.dark-theme) .mh-reset-btn {
      background: #1E293B !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-reset-btn:hover {
      background: #273549 !important;
      border-color: #3B82F6 !important;
      color: #FFFFFF !important;
    }

    /* Wearing estimate */
    :host-context(.dark-theme) .mh-wearing-estimate {
      background: #0F172A !important;
      border: 1.5px solid #334155 !important;
    }
    :host-context(.dark-theme) .mh-wearing-estimate.good { border-color: #10B981 !important; }
    :host-context(.dark-theme) .mh-wearing-estimate.neutral { border-color: #F59E0B !important; }
    :host-context(.dark-theme) .mh-wearing-estimate.warn { border-color: #EF4444 !important; }
    :host-context(.dark-theme) .mh-wear-title,
    :host-context(.dark-theme) .mh-wear-sub,
    :host-context(.dark-theme) .mh-wear-hours,
    :host-context(.dark-theme) .mh-wear-label,
    :host-context(.dark-theme) .mh-wear-desc {
      color: #FFFFFF !important;
    }

    /* Gauges */
    :host-context(.dark-theme) .mh-gauge-card {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .mh-gauge-center {
      background: #152238 !important;
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .mh-gauge-name {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-gauge-val {
      fill: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-gauge-max {
      fill: #FFFFFF !important;
      opacity: 0.8;
    }
    :host-context(.dark-theme) .mh-gauge-card circle[stroke="#e8f5e9"],
    :host-context(.dark-theme) .mh-gauge-card circle[stroke="#e2e8f0"],
    :host-context(.dark-theme) .mh-gauge-card circle[stroke="#ede9fe"] {
      stroke: #1E293B !important;
    }

    /* Flexibility bar */
    :host-context(.dark-theme) .mh-flex-bar-label span {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-flex-bar-track {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
    }

    /* Stats row */
    :host-context(.dark-theme) .mh-stat-block {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-stat-block:hover {
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .mh-stat-num,
    :host-context(.dark-theme) .mh-stat-lbl {
      color: #FFFFFF !important;
    }

    /* 6-Week Chart */
    :host-context(.dark-theme) .mh-chart-area {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .mh-chart-y span,
    :host-context(.dark-theme) .mh-chart-x span {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-trend-grid {
      stroke: #334155 !important;
    }
    :host-context(.dark-theme) .mh-dot-label {
      fill: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-chart-area circle {
      stroke: #3B82F6 !important;
      fill: #1E293B !important;
    }

    /* Recommendation */
    :host-context(.dark-theme) .mh-recommendation {
      background: #0F172A !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .mh-recommendation.good { border-color: #10B981 !important; }
    :host-context(.dark-theme) .mh-recommendation.neutral { border-color: #F59E0B !important; }
    :host-context(.dark-theme) .mh-recommendation.warn { border-color: #EF4444 !important; }
    :host-context(.dark-theme) .mh-recommendation strong,
    :host-context(.dark-theme) .mh-recommendation p {
      color: #FFFFFF !important;
    }

    /* Panels across Patient Status (Wearing, Recovery, Training, Medicine, Calendar) */
    :host-context(.dark-theme) .ps-panel {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.35) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-inline-card {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-inline-card strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-inline-card span {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .ps-editable-box {
      background: #0F172A !important;
      border-color: #334155 !important;
    }
    :host-context(.dark-theme) .ps-box-label {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-num-box {
      background: #1E293B !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-num-box:focus {
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-select-box {
      background: #1E293B !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-select-box:focus {
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-box-unit,
    :host-context(.dark-theme) .ps-box-sub {
      color: #FFFFFF !important;
      opacity: 0.85;
    }

    /* Training */
    :host-context(.dark-theme) .ps-training-item {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-training-name {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-training-num {
      background: #3B82F6 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-add-panel {
      background: #0F172A !important;
      border: 1.5px dashed #334155 !important;
    }
    :host-context(.dark-theme) .ps-add-title,
    :host-context(.dark-theme) .ps-add-label span {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-form-input {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-form-input:focus {
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-add-submit-btn {
      background: #3B82F6 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-add-submit-btn:hover {
      background: #2563EB !important;
    }
    :host-context(.dark-theme) .mh-training-note {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }

    /* Medicine */
    :host-context(.dark-theme) .ps-med-table {
      border: 1px solid #334155 !important;
      background: #0F172A !important;
    }
    :host-context(.dark-theme) .ps-med-header {
      background: #152238 !important;
      border-bottom: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-med-header span {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-med-row {
      color: #FFFFFF !important;
      border-bottom: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .ps-med-alt {
      background: #1E293B !important;
    }
    :host-context(.dark-theme) .ps-med-name,
    :host-context(.dark-theme) .ps-med-freq,
    :host-context(.dark-theme) .ps-med-purpose {
      color: #FFFFFF !important;
    }

    /* Calendar & Sessions */
    :host-context(.dark-theme) .ps-calendar-card {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-month-title {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-arrow {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-arrow:hover {
      background: #273549 !important;
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-cal-legend,
    :host-context(.dark-theme) .ps-cal-weekdays span {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-weekdays {
      border-bottom: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .ps-cal-cell {
      background: #152238 !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-cell:hover:not(.empty) {
      background: #1E293B !important;
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-cal-cell.has-session {
      background: rgba(59, 130, 246, 0.22) !important;
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-cal-cell.is-today {
      border-color: #3B82F6 !important;
      box-shadow: 0 0 0 1.5px #3B82F6 inset !important;
    }
    :host-context(.dark-theme) .ps-cal-cell.selected {
      background: rgba(59, 130, 246, 0.35) !important;
      border-color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ps-day-num {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-detail {
      background: #152238 !important;
      border: 1.5px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-cal-detail-header strong,
    :host-context(.dark-theme) .ps-cal-detail-notes {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-sessions h3,
    :host-context(.dark-theme) .ps-sessions-title,
    :host-context(.dark-theme) .ps-session-header strong,
    :host-context(.dark-theme) .ps-session-note {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ps-session-row {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .empty-state {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
  `]
})
export class PatientStatusComponent implements OnChanges {
  // Doctor editable metrics
  editWearingHours = 6;
  editTotalWearingDays = 1;
  editRecoveryScore = 50;
  editRecoveryPace = 'Good';

  // Training management
  presetTrainings: string[] = [
    'Wrist Flexion & Extension Drill',
    'Finger Pinch & Grasp Practice',
    'Pronation & Supination Rotation',
    'Dual-Channel Co-contraction Drill',
    'Prosthetic Grip Stability Hold',
    'Fine Motor Relocation Task',
    'Dynamic Force Calibration Training'
  ];
  selectedPresetTraining = '';
  newTrainingName = '';
  newTrainingUrl = '';

  // Medicine management
  presetMedicines = [
    { name: 'Baclofen', dose: '10 mg', frequency: 'Twice daily', purpose: 'Muscle relaxant and antispasticity' },
    { name: 'Gabapentin', dose: '300 mg', frequency: 'Once at night', purpose: 'Phantom limb pain management' },
    { name: 'Vitamin B-Complex', dose: '1 tab', frequency: 'Once daily', purpose: 'Peripheral nerve regeneration' },
    { name: 'Magnesium Glycinate', dose: '400 mg', frequency: 'Before sleep', purpose: 'Muscle twitch prevention & relaxation' },
    { name: 'Ibuprofen', dose: '400 mg', frequency: 'As needed', purpose: 'Stump soreness relief' }
  ];
  selectedPresetMedicine = '';
  newMedName = '';
  newMedDose = '';
  newMedFrequency = 'Once daily';
  newMedPurpose = '';

  // Session Calendar
  calYear = 2026;
  calMonth = 10; // November
  selectedDay: any = null;

  @Input() patient!: Patient;
  @Output() back = new EventEmitter<void>();
  @Output() setView = new EventEmitter<View>();
  @Output() viewHistory = new EventEmitter<void>();

  // Tick marks for sliders
  ticks = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

  // Editable muscle values (manual override)
  editHealth      = 0;
  editStrength    = 0;
  editEndurance   = 0;
  editFlexibility = 0;
  editHealthStatus: Health = 'Stable';

  // Saved state
  savedMessage = false;
  private savedTimer: any;

  // Original values for reset
  private origHealth      = 0;
  private origStrength    = 0;
  private origEndurance   = 0;
  private origFlexibility = 0;
  private origHealthStatus: Health = 'Stable';

  constructor(public svc: AppService) {}

  ngOnChanges(): void {
    if (this.patient) {
      this.editHealth        = this.patient.muscleHealth;
      this.editStrength      = this.patient.muscleStrength;
      this.editEndurance     = this.patient.muscleEndurance;
      this.editFlexibility   = this.patient.muscleFlexibility;
      this.editHealthStatus  = this.patient.health;
      this.editWearingHours  = this.patient.wearingHoursPerDay || 6;
      this.editTotalWearingDays = this.patient.totalWearingDays || 1;
      this.editRecoveryScore = this.patient.recovery;
      this.editRecoveryPace  = this.patient.muscleRecoveryRate || 'Good';

      this.origHealth        = this.patient.muscleHealth;
      this.origStrength      = this.patient.muscleStrength;
      this.origEndurance     = this.patient.muscleEndurance;
      this.origFlexibility   = this.patient.muscleFlexibility;
      this.origHealthStatus  = this.patient.health;
    }
  }

  setHealthStatus(s: Health): void {
    this.editHealthStatus = s;
    if (this.patient) {
      this.patient.health = s;
      this.svc.updatePatient(this.patient.id, { health: s });
    }
  }

  // When the user changes overall health manually, also nudge sub-scores proportionally
  onHealthChange(): void {
    const ratio = this.editHealth / (this.origHealth || 1);
    this.editStrength    = Math.min(100, Math.round(this.origStrength    * ratio));
    this.editEndurance   = Math.min(100, Math.round(this.origEndurance   * ratio));
    this.editFlexibility = Math.min(100, Math.round(this.origFlexibility * ratio));
  }

  // When sub-scores change, recompute overall as weighted average
  recalc(): void {
    this.editHealth = Math.round(this.editStrength * 0.4 + this.editEndurance * 0.35 + this.editFlexibility * 0.25);
  }

  resetToOriginal(): void {
    this.editHealth        = this.origHealth;
    this.editStrength      = this.origStrength;
    this.editEndurance     = this.origEndurance;
    this.editFlexibility   = this.origFlexibility;
    this.editHealthStatus  = this.origHealthStatus;
    if (this.patient) {
      this.patient.health = this.origHealthStatus;
    }
  }

  saveChanges(): void {
    // Persist saved values as new originals
    this.origHealth        = this.editHealth;
    this.origStrength      = this.editStrength;
    this.origEndurance     = this.editEndurance;
    this.origFlexibility   = this.editFlexibility;
    this.origHealthStatus  = this.editHealthStatus;

    if (this.patient) {
      this.patient.muscleHealth = this.editHealth;
      this.patient.muscleStrength = this.editStrength;
      this.patient.muscleEndurance = this.editEndurance;
      this.patient.muscleFlexibility = this.editFlexibility;
      this.patient.health = this.editHealthStatus;
      this.patient.muscleRecoveryRate = this.recoveryPace;
      this.patient.recovery = Math.min(100, Math.round(this.editHealth * 0.95));

      if (this.patient.muscleHistory && this.patient.muscleHistory.length > 0) {
        this.patient.muscleHistory[this.patient.muscleHistory.length - 1].score = this.editHealth;
      }

      this.patient.wearingHoursPerDay = Number(this.editWearingHours) || 6;
      this.patient.totalWearingDays = Number(this.editTotalWearingDays) || 1;

      this.svc.updatePatient(this.patient.id, {
        muscleHealth: this.editHealth,
        muscleStrength: this.editStrength,
        muscleEndurance: this.editEndurance,
        muscleFlexibility: this.editFlexibility,
        health: this.editHealthStatus,
        muscleRecoveryRate: this.recoveryPace,
        recovery: this.patient.recovery,
        wearingHoursPerDay: this.patient.wearingHoursPerDay,
        totalWearingDays: this.patient.totalWearingDays,
        muscleHistory: this.patient.muscleHistory
      });
    }

    // Show saved feedback for 2.5 seconds
    this.savedMessage = true;
    clearTimeout(this.savedTimer);
    this.savedTimer = setTimeout(() => { this.savedMessage = false; }, 2500);
  }

  /* ── Estimated MyoArm wearing hours ── */
  // Formula: Str(40%) + End(35%) + Flex(25%) mapped to 0–8 hrs, min 0.5h
  get estimatedWearingHours(): number {
    const weighted = this.editStrength * 0.4 + this.editEndurance * 0.35 + this.editFlexibility * 0.25;
    const hrs = (weighted / 100) * 8;
    return Math.max(0.5, Math.round(hrs * 2) / 2); // 0.5h increments
  }

  get wearingHoursDesc(): string {
    const h = this.estimatedWearingHours;
    if (h >= 7)   return 'Full day wear recommended';
    if (h >= 5.5) return 'Extended daily sessions';
    if (h >= 4)   return 'Moderate daily use';
    if (h >= 2.5) return 'Short daily sessions';
    if (h >= 1)   return 'Minimal — rest & recovery';
    return 'Rest only — no wearing advised';
  }

  /* ── Computed stats (all reactive to manual inputs) ── */
  get overallScore(): number { return this.editHealth; }

  get overallColor(): string {
    if (this.editHealth >= 80) return '#10b981';
    if (this.editHealth >= 60) return '#f59e0b';
    return '#ef4444';
  }

  get overallClass(): string {
    if (this.editHealth >= 80) return 'good';
    if (this.editHealth >= 60) return 'neutral';
    return 'warn';
  }

  get overallLabel(): string {
    if (this.editHealth >= 85) return 'Excellent';
    if (this.editHealth >= 70) return 'Good';
    if (this.editHealth >= 55) return 'Moderate';
    if (this.editHealth >= 40) return 'Low';
    return 'Critical';
  }

  get recoveryPace(): string {
    if (this.editHealth >= 75) return 'Fast';
    if (this.editHealth >= 55) return 'Moderate';
    return 'Slow';
  }

  get fitnessGoal(): number {
    return Math.min(100, Math.round(this.editHealth * 1.1));
  }

  get intensityLevel(): string {
    if (this.editHealth >= 85) return 'High';
    if (this.editHealth >= 65) return 'Medium';
    if (this.editHealth >= 45) return 'Low';
    return 'Rest';
  }

  get weeklyGain(): number {
    const h = this.patient?.muscleHistory;
    if (!h || h.length < 2) return 0;
    return h[h.length - 1].score - h[h.length - 2].score;
  }

  /* Recommendation */
  get recClass(): string { return this.overallClass; }

  get recIcon(): string {
    if (this.editHealth >= 80) return '🏆';
    if (this.editHealth >= 60) return '💡';
    return '⚠️';
  }

  get recTitle(): string {
    if (this.editHealth >= 85) return 'Outstanding performance — maintain current regimen';
    if (this.editHealth >= 70) return 'Good progress — increase session duration';
    if (this.editHealth >= 55) return 'Moderate — focus on consistency and rest days';
    return 'Needs attention — reduce intensity and consult physician';
  }

  get recText(): string {
    if (this.editHealth >= 85) return `Muscle health at ${this.editHealth}% — all three dimensions are strong. Consider advancing to high-resistance drills and daily-life task simulations.`;
    if (this.editHealth >= 70) return `Muscle health at ${this.editHealth}% — good base. Add 5 extra minutes per session and focus on the weaker dimension (${this.weakestDimension}).`;
    if (this.editHealth >= 55) return `Muscle health at ${this.editHealth}% — keep sessions short (15–20 min). Prioritise ${this.weakestDimension} with gentle exercises and ensure adequate sleep.`;
    return `Muscle health at ${this.editHealth}% — critical range. Limit training to 10 min, avoid high-resistance exercises, and schedule a physician review immediately.`;
  }

  private get weakestDimension(): string {
    const vals = [
      { name: 'Strength',    v: this.editStrength },
      { name: 'Endurance',   v: this.editEndurance },
      { name: 'Flexibility', v: this.editFlexibility },
    ];
    return vals.reduce((a, b) => a.v < b.v ? a : b).name;
  }

  /* ── SVG gauge helpers ── */
  dash(val: number): number   { return Math.round((val / 100) * 314.2); }
  dash58(val: number): number { return Math.round((val / 100) * 364.4); }

  tag(v: number): string {
    if (v >= 85) return 'Excellent';
    if (v >= 70) return 'Good';
    if (v >= 55) return 'Moderate';
    if (v >= 40) return 'Low';
    return 'Critical';
  }

  tagClass(v: number): string {
    if (v >= 70) return 'good';
    if (v >= 50) return 'neutral';
    return 'warn';
  }

  /* ── Chart helpers ── */
  get chartPoints(): { x: number; y: number }[] {
    const h = this.patient?.muscleHistory;
    if (!h || h.length === 0) return [];
    const n = h.length;
    return h.map((pt, i) => ({
      x: Math.round((i / (n - 1)) * 380 + 10),
      y: Math.round(105 - (pt.score / 100) * 100)
    }));
  }

  get chartLine(): string {
    return this.chartPoints.map(p => `${p.x},${p.y}`).join(' ');
  }

  get chartArea(): string {
    const pts = this.chartPoints;
    if (!pts.length) return '';
    return `${pts[0].x},110 ${pts.map(p => `${p.x},${p.y}`).join(' ')} ${pts[pts.length - 1].x},110`;
  }

  /* ── Misc helpers ── */
  getHealthClass(health: string): string { return healthClass(health as any); }

  get wearingPercent(): number {
    return Math.min(100, Math.round((this.patient.wearingHoursPerDay / 8) * 100));
  }

  /* ── Doctor Editable Actions: Wearing time, Recovery, Trainings, Medicines, Calendar ── */
  saveWearingTime(): void {
    if (this.patient) {
      this.patient.wearingHoursPerDay = Number(this.editWearingHours) || 0;
      this.patient.totalWearingDays = Number(this.editTotalWearingDays) || 0;
      this.svc.updatePatient(this.patient.id, {
        wearingHoursPerDay: this.patient.wearingHoursPerDay,
        totalWearingDays: this.patient.totalWearingDays
      });
    }
  }

  saveRecoveryStats(): void {
    if (this.patient) {
      this.patient.recovery = Number(this.editRecoveryScore) || 0;
      this.patient.muscleRecoveryRate = this.editRecoveryPace;
      this.svc.updatePatient(this.patient.id, {
        recovery: this.patient.recovery,
        muscleRecoveryRate: this.patient.muscleRecoveryRate
      });
    }
  }

  onPresetTrainingChange(): void {
    if (this.selectedPresetTraining) {
      this.newTrainingName = this.selectedPresetTraining;
      this.newTrainingUrl = 'https://www.youtube.com/results?search_query=' + encodeURIComponent(this.selectedPresetTraining + ' prosthetic arm');
    }
  }

  addTraining(): void {
    if (!this.newTrainingName.trim()) {
      alert('Please enter or choose an exercise name.');
      return;
    }
    const name = this.newTrainingName.trim();
    const url = this.newTrainingUrl.trim() ||
      ('https://www.youtube.com/results?search_query=' + encodeURIComponent(name + ' prosthetic arm rehabilitation'));
    if (!this.patient.trainingPlan) this.patient.trainingPlan = [];
    this.patient.trainingPlan.push({ name, url });
    this.svc.updatePatient(this.patient.id, { trainingPlan: this.patient.trainingPlan });
    this.newTrainingName = '';
    this.newTrainingUrl = '';
    this.selectedPresetTraining = '';
  }

  deleteTraining(index: number): void {
    if (confirm('Delete this exercise from the recommended training plan?')) {
      this.patient.trainingPlan.splice(index, 1);
      this.svc.updatePatient(this.patient.id, { trainingPlan: this.patient.trainingPlan });
    }
  }

  onPresetMedicineChange(): void {
    const found = this.presetMedicines.find(m => m.name === this.selectedPresetMedicine);
    if (found) {
      this.newMedName = found.name;
      this.newMedDose = found.dose;
      this.newMedFrequency = found.frequency;
      this.newMedPurpose = found.purpose;
    }
  }

  addMedicine(): void {
    if (!this.newMedName.trim()) {
      alert('Please enter medicine name.');
      return;
    }
    if (!this.patient.medicines) this.patient.medicines = [];
    this.patient.medicines.push({
      name: this.newMedName.trim(),
      dose: this.newMedDose.trim() || 'Standard',
      frequency: this.newMedFrequency.trim() || 'Daily',
      purpose: this.newMedPurpose.trim() || 'Clinical support'
    });
    this.svc.updatePatient(this.patient.id, { medicines: this.patient.medicines });
    this.newMedName = '';
    this.newMedDose = '';
    this.newMedFrequency = 'Once daily';
    this.newMedPurpose = '';
    this.selectedPresetMedicine = '';
  }

  deleteMedicine(index: number): void {
    if (confirm('Delete this medication from prescribed medicines?')) {
      this.patient.medicines.splice(index, 1);
      this.svc.updatePatient(this.patient.id, { medicines: this.patient.medicines });
    }
  }

  get calMonthName(): string {
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return months[this.calMonth];
  }

  prevMonth(): void {
    if (this.calMonth === 0) {
      this.calMonth = 11;
      this.calYear--;
    } else {
      this.calMonth--;
    }
  }

  nextMonth(): void {
    if (this.calMonth === 11) {
      this.calMonth = 0;
      this.calYear++;
    } else {
      this.calMonth++;
    }
  }

  get calendarDays(): Array<{ dayNum?: number; date?: string; session?: any; isToday?: boolean }> {
    const days: Array<{ dayNum?: number; date?: string; session?: any; isToday?: boolean }> = [];
    const firstDay = new Date(this.calYear, this.calMonth, 1).getDay();
    const totalDays = new Date(this.calYear, this.calMonth + 1, 0).getDate();
    const monthNames = ['january','february','march','april','may','june','july','august','september','october','november','december'];
    const monthShort = this.calMonthName.slice(0, 3);

    for (let i = 0; i < firstDay; i++) {
      days.push({});
    }

    const today = new Date();
    const isCurrentMonth = today.getFullYear() === this.calYear && today.getMonth() === this.calMonth;
    const todayDate = today.getDate();

    for (let d = 1; d <= totalDays; d++) {
      const session = this.patient?.sessionHistory?.find(s => {
        if (!s.date) return false;
        // Try native Date parsing first (handles ISO and many common formats)
        const parsed = new Date(s.date);
        if (!isNaN(parsed.getTime())) {
          return parsed.getFullYear() === this.calYear &&
                 parsed.getMonth() === this.calMonth &&
                 parsed.getDate() === d;
        }
        // Fallback: string matching for "Nov 10, 2026" format
        const sLower = s.date.toLowerCase();
        const matchMonth = sLower.startsWith(monthShort.toLowerCase()) ||
                           sLower.includes(' ' + monthShort.toLowerCase()) ||
                           sLower.includes(monthNames[this.calMonth]);
        const matchYear = sLower.includes(String(this.calYear));
        // Match exact day: "Nov 10, 2026" -> look for " 10," pattern
        const matchDay = new RegExp('\\b' + d + '\\b').test(sLower);
        return matchMonth && matchYear && matchDay;
      });

      days.push({
        dayNum: d,
        date: `${monthShort} ${d}, ${this.calYear}
    /* ══════════════════════════════════════════════════════
       HIGH CONTRAST ENHANCEMENTS FOR SMALL BOXES & BADGES
       ══════════════════════════════════════════════════════ */
    :host-context(.dark-theme) .doctor-state-title { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .doc-state-btn { color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .mh-badge-score { color: #FFFFFF !important; font-weight: 900; }
    :host-context(.dark-theme) .mh-badge-label { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .mh-gauge-tag { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .mh-gauge-tag.good { background: #064e3b !important; border: 1px solid #059669 !important; color: #FFFFFF !important; }
    :host-context(.dark-theme) .mh-gauge-tag.neutral { background: #78350f !important; border: 1px solid #d97706 !important; color: #FFFFFF !important; }
    :host-context(.dark-theme) .mh-gauge-tag.warn { background: #7f1d1d !important; border: 1px solid #dc2626 !important; color: #FFFFFF !important; }
    :host-context(.dark-theme) .mh-stat-lbl { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .mh-stat-num { color: #FFFFFF !important; font-weight: 900; }
    :host-context(.dark-theme) .mh-wear-label { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .mh-wear-desc { color: #FFFFFF !important; font-weight: 600; }
    :host-context(.dark-theme) .ps-box-label { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .ps-box-unit { color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .ps-box-sub { color: #FFFFFF !important; font-weight: 600; opacity: 1; }
    :host-context(.dark-theme) .ps-add-label { color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .ps-add-label span { color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .ps-cal-legend { color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .ps-cal-legend span { color: #FFFFFF !important; }
    :host-context(.dark-theme) .ps-cal-weekdays { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .ps-cal-weekdays span { color: #FFFFFF !important; }
    :host-context(.dark-theme) .ps-day-num { color: #FFFFFF !important; font-weight: 800; }
    :host-context(.dark-theme) .ps-session-row { background: #152238 !important; border-color: #334155 !important; }
    :host-context(.dark-theme) .ps-session-header strong { color: #FFFFFF !important; }
    :host-context(.dark-theme) .ps-session-note { color: #FFFFFF !important; font-weight: 500; }
    :host-context(.dark-theme) .health-pill.good { background: #064e3b !important; border: 1px solid #059669 !important; color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .health-pill.neutral { background: #78350f !important; border: 1px solid #d97706 !important; color: #FFFFFF !important; font-weight: 700; }
    :host-context(.dark-theme) .health-pill.warn { background: #7f1d1d !important; border: 1px solid #dc2626 !important; color: #FFFFFF !important; font-weight: 700; }
`,
        session: session || null,
        isToday: isCurrentMonth && d === todayDate
      });
    }

    return days;
  }

  get sessionsThisMonthCount(): number {
    return this.calendarDays.filter(d => !!d.session).length;
  }

  selectDay(day: any): void {
    if (day && day.session) {
      this.selectedDay = this.selectedDay?.dayNum === day.dayNum ? null : day;
    }
  }

}
