﻿import { Patient, Appointment, Revenue, Expense } from './models';

export const PATIENTS: Patient[] = [
  {
    id: 'p1', name: 'Adel Imam', initials: 'AI', age: 52, condition: 'Right forearm amputation',
    device: 'NM-2841', battery: 86, signal: 'Strong', recovery: 82, accuracy: 94.8,
    health: 'Improving', lastSession: 'Today, 9:42 AM', minutes: 24, streak: 6,
    note: 'Grip control is progressing well. Continue the current training plan.',
    wearingHoursPerDay: 7.5, totalWearingDays: 45,
    muscleHealth: 78, muscleRecoveryRate: 'Good',
    muscleStrength: 80, muscleEndurance: 75, muscleFlexibility: 72,
    muscleHistory: [
      { week: 'W1', score: 60 }, { week: 'W2', score: 64 }, { week: 'W3', score: 68 },
      { week: 'W4', score: 72 }, { week: 'W5', score: 75 }, { week: 'W6', score: 78 },
    ],
    trainingPlan: [
      { name: 'Grip and release exercises (3x10)', url: 'https://www.youtube.com/results?search_query=Grip%20and%20release%20exercises%20(3x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Wrist rotation drills', url: 'https://www.youtube.com/results?search_query=Wrist%20rotation%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Object pick-up practice', url: 'https://www.youtube.com/results?search_query=Object%20pick-up%20practice%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Fine motor finger control', url: 'https://www.youtube.com/results?search_query=Fine%20motor%20finger%20control%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Ibuprofen', dose: '400 mg', frequency: 'Twice daily after meals', purpose: 'Reduce residual limb inflammation' },
      { name: 'Gabapentin', dose: '300 mg', frequency: 'Three times daily', purpose: 'Phantom limb pain relief' },
      { name: 'Vitamin B12', dose: '1000 mcg', frequency: 'Once daily', purpose: 'Nerve regeneration support' },
    ],
    sessionHistory: [
      { date: 'Today, 9:42 AM', duration: 24, accuracy: 94.8, notes: 'Strong session, improved grip control.' },
      { date: 'Yesterday, 10:00 AM', duration: 28, accuracy: 93.1, notes: 'Slight fatigue noted in last 5 min.' },
      { date: '2 days ago', duration: 20, accuracy: 91.4, notes: 'Good focus on wrist rotation.' },
    ]
  },
  {
    id: 'p2', name: 'Yosra', initials: 'YO', age: 47, condition: 'Left hand prosthesis',
    device: 'NM-2842', battery: 71, signal: 'Strong', recovery: 76, accuracy: 92.1,
    health: 'Stable', lastSession: 'Today, 8:15 AM', minutes: 30, streak: 9,
    note: 'Consistent sessions with steady signal quality.',
    wearingHoursPerDay: 8, totalWearingDays: 62,
    muscleHealth: 72, muscleRecoveryRate: 'Moderate',
    muscleStrength: 70, muscleEndurance: 68, muscleFlexibility: 74,
    muscleHistory: [
      { week: 'W1', score: 55 }, { week: 'W2', score: 58 }, { week: 'W3', score: 62 },
      { week: 'W4', score: 65 }, { week: 'W5', score: 69 }, { week: 'W6', score: 72 },
    ],
    trainingPlan: [
      { name: 'Open-close hand repetitions (4x12)', url: 'https://www.youtube.com/results?search_query=Open-close%20hand%20repetitions%20(4x12)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Light object handling', url: 'https://www.youtube.com/results?search_query=Light%20object%20handling%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Pinch strength training', url: 'https://www.youtube.com/results?search_query=Pinch%20strength%20training%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Mirror therapy exercises', url: 'https://www.youtube.com/results?search_query=Mirror%20therapy%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Twice daily', purpose: 'Neuropathic pain management' },
      { name: 'Calcium + Vitamin D', dose: '500 mg / 400 IU', frequency: 'Once daily', purpose: 'Bone density maintenance' },
      { name: 'Amitriptyline', dose: '10 mg', frequency: 'Once at night', purpose: 'Sleep and pain improvement' },
    ],
    sessionHistory: [
      { date: 'Today, 8:15 AM', duration: 30, accuracy: 92.1, notes: 'Full session completed.' },
      { date: 'Yesterday, 8:30 AM', duration: 30, accuracy: 91.8, notes: 'Consistent performance.' },
      { date: '3 days ago', duration: 25, accuracy: 90.5, notes: 'Minor signal dip at end.' },
    ]
  },
  {
    id: 'p3', name: 'Ahmed El Sakka', initials: 'AE', age: 44, condition: 'Right below-elbow amputation',
    device: 'NM-2843', battery: 18, signal: 'Weak', recovery: 58, accuracy: 85.4,
    health: 'Needs attention', lastSession: 'Yesterday, 4:30 PM', minutes: 12, streak: 2,
    note: 'Low battery and weak signal. Check electrode contact and charge device.',
    wearingHoursPerDay: 4, totalWearingDays: 28,
    muscleHealth: 54, muscleRecoveryRate: 'Slow',
    muscleStrength: 48, muscleEndurance: 52, muscleFlexibility: 55,
    muscleHistory: [
      { week: 'W1', score: 42 }, { week: 'W2', score: 44 }, { week: 'W3', score: 47 },
      { week: 'W4', score: 50 }, { week: 'W5', score: 52 }, { week: 'W6', score: 54 },
    ],
    trainingPlan: [
      { name: 'Basic elbow flexion (2x8)', url: 'https://www.youtube.com/results?search_query=Basic%20elbow%20flexion%20(2x8)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Electrode contact check', url: 'https://www.youtube.com/results?search_query=Electrode%20contact%20check%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Slow grip training', url: 'https://www.youtube.com/results?search_query=Slow%20grip%20training%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Rest and recovery days recommended', url: 'https://www.youtube.com/results?search_query=Rest%20and%20recovery%20days%20recommended%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Tramadol', dose: '50 mg', frequency: 'As needed (max 3x/day)', purpose: 'Post-amputation pain control' },
      { name: 'Zinc Sulfate', dose: '220 mg', frequency: 'Once daily', purpose: 'Wound healing support' },
      { name: 'Gabapentin', dose: '300 mg', frequency: 'Twice daily', purpose: 'Neuropathic pain relief' },
    ],
    sessionHistory: [
      { date: 'Yesterday, 4:30 PM', duration: 12, accuracy: 85.4, notes: 'Weak signal throughout. Device needs charging.' },
      { date: '3 days ago', duration: 18, accuracy: 87.2, notes: 'Better signal. Short session due to fatigue.' },
      { date: '5 days ago', duration: 15, accuracy: 84.0, notes: 'Patient reported discomfort.' },
    ]
  },
  {
    id: 'p4', name: 'Mona Zaki', initials: 'MZ', age: 35, condition: 'Left forearm amputation',
    device: 'NM-2844', battery: 92, signal: 'Strong', recovery: 88, accuracy: 96.3,
    health: 'Improving', lastSession: 'Today, 10:05 AM', minutes: 28, streak: 12,
    note: 'Ahead of schedule. Consider advancing to fine-grip exercises.',
    wearingHoursPerDay: 9, totalWearingDays: 80,
    muscleHealth: 88, muscleRecoveryRate: 'Good',
    muscleStrength: 90, muscleEndurance: 86, muscleFlexibility: 84,
    muscleHistory: [
      { week: 'W1', score: 72 }, { week: 'W2', score: 76 }, { week: 'W3', score: 80 },
      { week: 'W4', score: 83 }, { week: 'W5', score: 86 }, { week: 'W6', score: 88 },
    ],
    trainingPlan: [
      { name: 'Advanced fine-grip exercises', url: 'https://www.youtube.com/results?search_query=Advanced%20fine-grip%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Typing simulation (keyboard tapping)', url: 'https://www.youtube.com/results?search_query=Typing%20simulation%20(keyboard%20tapping)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Two-hand coordination drills', url: 'https://www.youtube.com/results?search_query=Two-hand%20coordination%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Progressive resistance training', url: 'https://www.youtube.com/results?search_query=Progressive%20resistance%20training%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Vitamin E', dose: '400 IU', frequency: 'Once daily', purpose: 'Scar tissue reduction' },
      { name: 'Magnesium Glycinate', dose: '400 mg', frequency: 'Once at night', purpose: 'Muscle recovery and relaxation' },
      { name: 'Omega-3', dose: '1000 mg', frequency: 'Once daily with food', purpose: 'Anti-inflammatory support' },
    ],
    sessionHistory: [
      { date: 'Today, 10:05 AM', duration: 28, accuracy: 96.3, notes: 'Excellent session. Ready for advanced plan.' },
      { date: 'Yesterday, 10:00 AM', duration: 30, accuracy: 95.8, notes: 'Strong performance throughout.' },
      { date: '2 days ago', duration: 30, accuracy: 95.0, notes: 'Consistent. Fine motor improving.' },
    ]
  },
  {
    id: 'p5', name: 'Karim Abdel Aziz', initials: 'KA', age: 39, condition: 'Right hand prosthesis',
    device: 'NM-2845', battery: 64, signal: 'Good', recovery: 69, accuracy: 90.7,
    health: 'Stable', lastSession: 'Yesterday, 11:20 AM', minutes: 22, streak: 4,
    note: 'Stable progress. Recalibration due next week.',
    wearingHoursPerDay: 6, totalWearingDays: 38,
    muscleHealth: 66, muscleRecoveryRate: 'Moderate',
    muscleStrength: 64, muscleEndurance: 62, muscleFlexibility: 68,
    muscleHistory: [
      { week: 'W1', score: 52 }, { week: 'W2', score: 55 }, { week: 'W3', score: 58 },
      { week: 'W4', score: 61 }, { week: 'W5', score: 63 }, { week: 'W6', score: 66 },
    ],
    trainingPlan: [
      { name: 'Grip strength building (3x10)', url: 'https://www.youtube.com/results?search_query=Grip%20strength%20building%20(3x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Wrist supination exercises', url: 'https://www.youtube.com/results?search_query=Wrist%20supination%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Object transfer drills', url: 'https://www.youtube.com/results?search_query=Object%20transfer%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Recalibration session next visit', url: 'https://www.youtube.com/results?search_query=Recalibration%20session%20next%20visit%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '150 mg', frequency: 'Twice daily', purpose: 'Chronic neuropathic pain' },
      { name: 'Aspirin', dose: '100 mg', frequency: 'Once daily', purpose: 'Vascular health maintenance' },
      { name: 'Multivitamin', dose: '1 tablet', frequency: 'Once daily with breakfast', purpose: 'General rehabilitation support' },
    ],
    sessionHistory: [
      { date: 'Yesterday, 11:20 AM', duration: 22, accuracy: 90.7, notes: 'Stable. Recalibration reminder noted.' },
      { date: '2 days ago', duration: 25, accuracy: 89.5, notes: 'Good effort. Slight accuracy drop.' },
      { date: '4 days ago', duration: 20, accuracy: 91.0, notes: 'Consistent with previous session.' },
    ]
  },
  {
    id: 'p6', name: 'Nour El-Sherif', initials: 'NS', age: 29, condition: 'Left forearm amputation',
    device: 'NM-2846', battery: 80, signal: 'Strong', recovery: 74, accuracy: 91.5,
    health: 'Improving', lastSession: 'Today, 11:00 AM', minutes: 26, streak: 7,
    note: 'Excellent motivation. Progressing faster than typical timeline.',
    wearingHoursPerDay: 8, totalWearingDays: 52,
    muscleHealth: 75, muscleRecoveryRate: 'Good',
    muscleStrength: 78, muscleEndurance: 72, muscleFlexibility: 70,
    muscleHistory: [
      { week: 'W1', score: 58 }, { week: 'W2', score: 62 }, { week: 'W3', score: 65 },
      { week: 'W4', score: 68 }, { week: 'W5', score: 72 }, { week: 'W6', score: 75 },
    ],
    trainingPlan: [
      { name: 'Forearm flexion drills (3x12)', url: 'https://www.youtube.com/results?search_query=Forearm%20flexion%20drills%20(3x12)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Object lifting practice', url: 'https://www.youtube.com/results?search_query=Object%20lifting%20practice%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Grip pattern switching', url: 'https://www.youtube.com/results?search_query=Grip%20pattern%20switching%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Endurance sessions 25+ min', url: 'https://www.youtube.com/results?search_query=Endurance%20sessions%2025%2B%20min%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Ibuprofen', dose: '200 mg', frequency: 'Once daily as needed', purpose: 'Mild inflammation control' },
      { name: 'Protein Supplement', dose: '25 g', frequency: 'Post-training', purpose: 'Muscle mass building' },
      { name: 'Vitamin D3', dose: '2000 IU', frequency: 'Once daily', purpose: 'Bone and muscle strength' },
    ],
    sessionHistory: [
      { date: 'Today, 11:00 AM', duration: 26, accuracy: 91.5, notes: 'Great focus and coordination today.' },
      { date: 'Yesterday, 11:30 AM', duration: 24, accuracy: 90.2, notes: 'Improving steadily.' },
      { date: '3 days ago', duration: 22, accuracy: 89.0, notes: 'Slight fatigue mid-session.' },
    ]
  },
  {
    id: 'p7', name: 'Omar Sharif', initials: 'OS', age: 61, condition: 'Shoulder disarticulation',
    device: 'NM-2847', battery: 42, signal: 'Good', recovery: 45, accuracy: 80.3,
    health: 'Needs attention', lastSession: 'Mon, Nov 18 2026', minutes: 15, streak: 1,
    note: 'Complex case. Needs frequent recalibration. Shoulder amplitude is variable.',
    wearingHoursPerDay: 3, totalWearingDays: 20,
    muscleHealth: 42, muscleRecoveryRate: 'Slow',
    muscleStrength: 36, muscleEndurance: 40, muscleFlexibility: 45,
    muscleHistory: [
      { week: 'W1', score: 30 }, { week: 'W2', score: 32 }, { week: 'W3', score: 35 },
      { week: 'W4', score: 38 }, { week: 'W5', score: 40 }, { week: 'W6', score: 42 },
    ],
    trainingPlan: [
      { name: 'Shoulder shrug signal training (2x6)', url: 'https://www.youtube.com/results?search_query=Shoulder%20shrug%20signal%20training%20(2x6)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Myoelectric threshold calibration', url: 'https://www.youtube.com/results?search_query=Myoelectric%20threshold%20calibration%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Short wear periods with breaks', url: 'https://www.youtube.com/results?search_query=Short%20wear%20periods%20with%20breaks%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Pain assessment before each session', url: 'https://www.youtube.com/results?search_query=Pain%20assessment%20before%20each%20session%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Morphine Sulfate', dose: '10 mg', frequency: 'Twice daily (controlled)', purpose: 'Severe shoulder pain management' },
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Three times daily', purpose: 'Neuropathic pain — shoulder disarticulation' },
      { name: 'Omeprazole', dose: '20 mg', frequency: 'Once daily before breakfast', purpose: 'Gastric protection from pain meds' },
    ],
    sessionHistory: [
      { date: 'Mon, Nov 18 2026', duration: 15, accuracy: 80.3, notes: 'Short session due to discomfort.' },
      { date: 'Fri, Nov 14 2026', duration: 18, accuracy: 78.9, notes: 'Calibration needed.' },
      { date: 'Wed, Nov 12 2026', duration: 12, accuracy: 77.5, notes: 'Fatigue limits session length.' },
    ]
  },
  {
    id: 'p8', name: 'Dina El-Wakil', initials: 'DW', age: 33, condition: 'Right hand prosthesis',
    device: 'NM-2848', battery: 95, signal: 'Strong', recovery: 91, accuracy: 97.2,
    health: 'Improving', lastSession: 'Today, 7:50 AM', minutes: 32, streak: 15,
    note: 'Outstanding performance. Ready for advanced fine-motor challenge drills.',
    wearingHoursPerDay: 10, totalWearingDays: 95,
    muscleHealth: 92, muscleRecoveryRate: 'Good',
    muscleStrength: 94, muscleEndurance: 91, muscleFlexibility: 88,
    muscleHistory: [
      { week: 'W1', score: 78 }, { week: 'W2', score: 82 }, { week: 'W3', score: 85 },
      { week: 'W4', score: 88 }, { week: 'W5', score: 90 }, { week: 'W6', score: 92 },
    ],
    trainingPlan: [
      { name: 'Fine motor challenge drills', url: 'https://www.youtube.com/results?search_query=Fine%20motor%20challenge%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Writing and drawing exercises', url: 'https://www.youtube.com/results?search_query=Writing%20and%20drawing%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Speed and accuracy tests', url: 'https://www.youtube.com/results?search_query=Speed%20and%20accuracy%20tests%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Daily life task simulations', url: 'https://www.youtube.com/results?search_query=Daily%20life%20task%20simulations%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Collagen Peptides', dose: '10 g', frequency: 'Once daily', purpose: 'Connective tissue and tendon support' },
      { name: 'Vitamin C', dose: '500 mg', frequency: 'Once daily', purpose: 'Collagen synthesis and immunity' },
      { name: 'Iron Supplement', dose: '325 mg', frequency: 'Once daily with vitamin C', purpose: 'Energy and oxygen transport' },
    ],
    sessionHistory: [
      { date: 'Today, 7:50 AM', duration: 32, accuracy: 97.2, notes: 'Best accuracy yet. Device fully optimised.' },
      { date: 'Yesterday, 8:00 AM', duration: 30, accuracy: 96.8, notes: 'Consistent high performance.' },
      { date: '2 days ago', duration: 30, accuracy: 96.1, notes: 'Excellent control.' },
    ]
  },
  {
    id: 'p9', name: 'Hossam Habib', initials: 'HH', age: 55, condition: 'Transradial amputation',
    device: 'NM-2849', battery: 55, signal: 'Good', recovery: 63, accuracy: 87.9,
    health: 'Stable', lastSession: 'Tue, Nov 19 2026', minutes: 20, streak: 3,
    note: 'Steady improvement. Needs consistency in daily wearing schedule.',
    wearingHoursPerDay: 5, totalWearingDays: 35,
    muscleHealth: 60, muscleRecoveryRate: 'Moderate',
    muscleStrength: 58, muscleEndurance: 55, muscleFlexibility: 62,
    muscleHistory: [
      { week: 'W1', score: 45 }, { week: 'W2', score: 48 }, { week: 'W3', score: 52 },
      { week: 'W4', score: 55 }, { week: 'W5', score: 58 }, { week: 'W6', score: 60 },
    ],
    trainingPlan: [
      { name: 'Transradial flexion-extension (3x10)', url: 'https://www.youtube.com/results?search_query=Transradial%20flexion-extension%20(3x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Grip force modulation', url: 'https://www.youtube.com/results?search_query=Grip%20force%20modulation%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Two-finger pinch exercises', url: 'https://www.youtube.com/results?search_query=Two-finger%20pinch%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Wearing schedule adherence', url: 'https://www.youtube.com/results?search_query=Wearing%20schedule%20adherence%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Gabapentin', dose: '300 mg', frequency: 'Twice daily', purpose: 'Transradial nerve pain' },
      { name: 'Aspirin', dose: '100 mg', frequency: 'Once daily', purpose: 'Cardiovascular protection' },
      { name: 'Zinc + Selenium', dose: '25 mg / 100 mcg', frequency: 'Once daily', purpose: 'Immune and nerve support' },
    ],
    sessionHistory: [
      { date: 'Tue, Nov 19 2026', duration: 20, accuracy: 87.9, notes: 'Steady session, good compliance.' },
      { date: 'Sun, Nov 17 2026', duration: 18, accuracy: 86.4, notes: 'Slight drop in signal mid-session.' },
      { date: 'Thu, Nov 13 2026', duration: 22, accuracy: 88.2, notes: 'Good range of motion.' },
    ]
  },
  {
    id: 'p10', name: 'Layla Hassan', initials: 'LH', age: 27, condition: 'Left hand prosthesis',
    device: 'NM-2850', battery: 78, signal: 'Strong', recovery: 85, accuracy: 95.1,
    health: 'Improving', lastSession: 'Today, 9:00 AM', minutes: 29, streak: 10,
    note: 'Motivated young patient with excellent compliance and fast adaptation.',
    wearingHoursPerDay: 9, totalWearingDays: 70,
    muscleHealth: 83, muscleRecoveryRate: 'Good',
    muscleStrength: 82, muscleEndurance: 79, muscleFlexibility: 76,
    muscleHistory: [
      { week: 'W1', score: 65 }, { week: 'W2', score: 68 }, { week: 'W3', score: 72 },
      { week: 'W4', score: 75 }, { week: 'W5', score: 78 }, { week: 'W6', score: 81 },
    ],
    trainingPlan: [
      { name: 'Bilateral coordination drills', url: 'https://www.youtube.com/results?search_query=Bilateral%20coordination%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Speed grip exercises (4x15)', url: 'https://www.youtube.com/results?search_query=Speed%20grip%20exercises%20(4x15)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Daily ADL practice', url: 'https://www.youtube.com/results?search_query=Daily%20ADL%20practice%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Advance to level 3 control mode', url: 'https://www.youtube.com/results?search_query=Advance%20to%20level%203%20control%20mode%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Once daily at night', purpose: 'Neuropathic pain — dominant hand' },
      { name: 'Vitamin B Complex', dose: '1 tablet', frequency: 'Once daily', purpose: 'Peripheral nerve health' },
      { name: 'Omega-3', dose: '1000 mg', frequency: 'Once daily', purpose: 'Inflammation control' },
    ],
    sessionHistory: [
      { date: 'Today, 9:00 AM', duration: 29, accuracy: 95.1, notes: 'Smooth session with high accuracy.' },
      { date: 'Yesterday, 9:15 AM', duration: 28, accuracy: 94.3, notes: 'Coordinated bilateral movements.' },
      { date: '2 days ago', duration: 27, accuracy: 93.8, notes: 'Near-perfect grip patterns.' },
    ]
  },
  {
    id: 'p11', name: 'Tarek Nour', initials: 'TN', age: 48, condition: 'Right forearm amputation',
    device: 'NM-2851', battery: 30, signal: 'Weak', recovery: 50, accuracy: 83.6,
    health: 'Needs attention', lastSession: 'Sun, Nov 17 2026', minutes: 14, streak: 1,
    note: 'Signal consistently weak. Electrode repositioning required.',
    wearingHoursPerDay: 3.5, totalWearingDays: 18,
    muscleHealth: 48, muscleRecoveryRate: 'Slow',
    muscleStrength: 55, muscleEndurance: 50, muscleFlexibility: 58,
    muscleHistory: [
      { week: 'W1', score: 40 }, { week: 'W2', score: 43 }, { week: 'W3', score: 47 },
      { week: 'W4', score: 50 }, { week: 'W5', score: 53 }, { week: 'W6', score: 56 },
    ],
    trainingPlan: [
      { name: 'Electrode placement optimisation', url: 'https://www.youtube.com/results?search_query=Electrode%20placement%20optimisation%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Low-intensity grip training (2x8)', url: 'https://www.youtube.com/results?search_query=Low-intensity%20grip%20training%20(2x8)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Signal monitoring during session', url: 'https://www.youtube.com/results?search_query=Signal%20monitoring%20during%20session%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Increase wearing time gradually', url: 'https://www.youtube.com/results?search_query=Increase%20wearing%20time%20gradually%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Tramadol', dose: '50 mg', frequency: 'As needed (max 2x/day)', purpose: 'Acute pain management' },
      { name: 'Melatonin', dose: '3 mg', frequency: 'Once at bedtime', purpose: 'Sleep disruption from phantom pain' },
      { name: 'Magnesium', dose: '400 mg', frequency: 'Once daily', purpose: 'Muscle cramp prevention' },
    ],
    sessionHistory: [
      { date: 'Sun, Nov 17 2026', duration: 14, accuracy: 83.6, notes: 'Weak signal. Electrodes repositioned mid-session.' },
      { date: 'Thu, Nov 13 2026', duration: 16, accuracy: 82.1, notes: 'Patient tires quickly. Fatigue monitored.' },
      { date: 'Mon, Nov 10 2026', duration: 12, accuracy: 80.5, notes: 'Initial calibration session.' },
    ]
  },
  {
    id: 'p12', name: 'Rania Farid', initials: 'RF', age: 41, condition: 'Left forearm amputation',
    device: 'NM-2852', battery: 88, signal: 'Strong', recovery: 79, accuracy: 93.4,
    health: 'Stable', lastSession: 'Fri, Nov 14 2026', minutes: 25, streak: 5,
    note: 'Well-adapted patient. Continue current plan with added complexity.',
    wearingHoursPerDay: 7, totalWearingDays: 55,
    muscleHealth: 76, muscleRecoveryRate: 'Good',
    muscleStrength: 44, muscleEndurance: 42, muscleFlexibility: 48,
    muscleHistory: [
      { week: 'W1', score: 32 }, { week: 'W2', score: 35 }, { week: 'W3', score: 38 },
      { week: 'W4', score: 41 }, { week: 'W5', score: 44 }, { week: 'W6', score: 46 },
    ],
    trainingPlan: [
      { name: 'Complex object manipulation', url: 'https://www.youtube.com/results?search_query=Complex%20object%20manipulation%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Wrist pronation-supination drills', url: 'https://www.youtube.com/results?search_query=Wrist%20pronation-supination%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Grip endurance sets (4x20)', url: 'https://www.youtube.com/results?search_query=Grip%20endurance%20sets%20(4x20)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Introduce control mode 2', url: 'https://www.youtube.com/results?search_query=Introduce%20control%20mode%202%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '150 mg', frequency: 'Twice daily', purpose: 'Chronic phantom pain' },
      { name: 'Amitriptyline', dose: '25 mg', frequency: 'Once at night', purpose: 'Depression and pain dual management' },
      { name: 'Calcium Carbonate', dose: '500 mg', frequency: 'Twice daily', purpose: 'Bone density support' },
    ],
    sessionHistory: [
      { date: 'Fri, Nov 14 2026', duration: 25, accuracy: 93.4, notes: 'Confident and focused session.' },
      { date: 'Tue, Nov 11 2026', duration: 24, accuracy: 92.6, notes: 'Good muscle response.' },
      { date: 'Sat, Nov 8 2026', duration: 23, accuracy: 91.9, notes: 'Steady improvement noted.' },
    ]
  },
  {
    id: 'p13', name: 'Sherif Ramzy', initials: 'SR', age: 36, condition: 'Right below-elbow amputation',
    device: 'NM-2853', battery: 67, signal: 'Good', recovery: 72, accuracy: 90.0,
    health: 'Stable', lastSession: 'Mon, Nov 18 2026', minutes: 23, streak: 6,
    note: 'Progressing on schedule. Device signal is consistent.',
    wearingHoursPerDay: 6.5, totalWearingDays: 44,
    muscleHealth: 69, muscleRecoveryRate: 'Moderate',
    muscleStrength: 76, muscleEndurance: 74, muscleFlexibility: 71,
    muscleHistory: [
      { week: 'W1', score: 60 }, { week: 'W2', score: 63 }, { week: 'W3', score: 67 },
      { week: 'W4', score: 70 }, { week: 'W5', score: 73 }, { week: 'W6', score: 75 },
    ],
    trainingPlan: [
      { name: 'Below-elbow flex-extend (3x10)', url: 'https://www.youtube.com/results?search_query=Below-elbow%20flex-extend%20(3x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Tripod grip training', url: 'https://www.youtube.com/results?search_query=Tripod%20grip%20training%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Signal threshold fine-tuning', url: 'https://www.youtube.com/results?search_query=Signal%20threshold%20fine-tuning%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'ADL integration drills', url: 'https://www.youtube.com/results?search_query=ADL%20integration%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Ibuprofen', dose: '400 mg', frequency: 'As needed (max 3x/day)', purpose: 'Post-session inflammation' },
      { name: 'Vitamin D3', dose: '1000 IU', frequency: 'Once daily', purpose: 'Bone and nerve health' },
      { name: 'Creatine Monohydrate', dose: '5 g', frequency: 'Daily with water', purpose: 'Muscle endurance during training' },
    ],
    sessionHistory: [
      { date: 'Mon, Nov 18 2026', duration: 23, accuracy: 90.0, notes: 'On-track. Device stable.' },
      { date: 'Fri, Nov 14 2026', duration: 22, accuracy: 89.3, notes: 'Good signal quality.' },
      { date: 'Tue, Nov 11 2026', duration: 21, accuracy: 88.7, notes: 'Consistent performance.' },
    ]
  },
  {
    id: 'p14', name: 'Ghada Adel', initials: 'GA', age: 44, condition: 'Bilateral hand prosthesis',
    device: 'NM-2854', battery: 73, signal: 'Good', recovery: 60, accuracy: 88.5,
    health: 'Stable', lastSession: 'Tue, Nov 19 2026', minutes: 20, streak: 4,
    note: 'Complex bilateral case. Good attitude and compliance.',
    wearingHoursPerDay: 6, totalWearingDays: 40,
    muscleHealth: 62, muscleRecoveryRate: 'Moderate',
    muscleStrength: 56, muscleEndurance: 58, muscleFlexibility: 60,
    muscleHistory: [
      { week: 'W1', score: 44 }, { week: 'W2', score: 48 }, { week: 'W3', score: 52 },
      { week: 'W4', score: 55 }, { week: 'W5', score: 58 }, { week: 'W6', score: 62 },
    ],
    trainingPlan: [
      { name: 'Bilateral synchrony drills', url: 'https://www.youtube.com/results?search_query=Bilateral%20synchrony%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Independent hand control exercises', url: 'https://www.youtube.com/results?search_query=Independent%20hand%20control%20exercises%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Object transfer between hands', url: 'https://www.youtube.com/results?search_query=Object%20transfer%20between%20hands%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Fatigue management protocol', url: 'https://www.youtube.com/results?search_query=Fatigue%20management%20protocol%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Morphine SR', dose: '15 mg', frequency: 'Twice daily (controlled)', purpose: 'Bilateral amputation pain' },
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Three times daily', purpose: 'Bilateral phantom pain' },
      { name: 'Omeprazole', dose: '20 mg', frequency: 'Once daily', purpose: 'Gastric protection' },
    ],
    sessionHistory: [
      { date: 'Tue, Nov 19 2026', duration: 20, accuracy: 88.5, notes: 'Good bilateral coordination today.' },
      { date: 'Sat, Nov 15 2026', duration: 18, accuracy: 87.1, notes: 'Left side slightly weaker.' },
      { date: 'Wed, Nov 12 2026', duration: 19, accuracy: 86.8, notes: 'Session cut short by fatigue.' },
    ]
  },
  {
    id: 'p15', name: 'Khaled Saleh', initials: 'KS', age: 50, condition: 'Transradial amputation',
    device: 'NM-2855', battery: 58, signal: 'Good', recovery: 66, accuracy: 89.2,
    health: 'Stable', lastSession: 'Mon, Nov 18 2026', minutes: 21, streak: 5,
    note: 'Consistent wearer. Steady progress toward full daily integration.',
    wearingHoursPerDay: 7, totalWearingDays: 48,
    muscleHealth: 65, muscleRecoveryRate: 'Moderate',
    muscleStrength: 62, muscleEndurance: 60, muscleFlexibility: 66,
    muscleHistory: [
      { week: 'W1', score: 50 }, { week: 'W2', score: 53 }, { week: 'W3', score: 56 },
      { week: 'W4', score: 59 }, { week: 'W5', score: 62 }, { week: 'W6', score: 65 },
    ],
    trainingPlan: [
      { name: 'Transradial EMG training (3x10)', url: 'https://www.youtube.com/results?search_query=Transradial%20EMG%20training%20(3x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Precision grip tasks', url: 'https://www.youtube.com/results?search_query=Precision%20grip%20tasks%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Daily wearing compliance tracking', url: 'https://www.youtube.com/results?search_query=Daily%20wearing%20compliance%20tracking%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Progressive session length increase', url: 'https://www.youtube.com/results?search_query=Progressive%20session%20length%20increase%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Gabapentin', dose: '300 mg', frequency: 'Twice daily', purpose: 'Transradial nerve pain' },
      { name: 'Aspirin', dose: '100 mg', frequency: 'Once daily', purpose: 'Cardiovascular maintenance' },
      { name: 'Vitamin B12', dose: '500 mcg', frequency: 'Once daily', purpose: 'Nerve conduction support' },
    ],
    sessionHistory: [
      { date: 'Mon, Nov 18 2026', duration: 21, accuracy: 89.2, notes: 'Consistent and focused.' },
      { date: 'Thu, Nov 13 2026', duration: 20, accuracy: 88.5, notes: 'Good EMG response.' },
      { date: 'Mon, Nov 10 2026', duration: 19, accuracy: 87.9, notes: 'Improving compliance.' },
    ]
  },
  {
    id: 'p16', name: 'Mariam Youssef', initials: 'MY', age: 23, condition: 'Left hand prosthesis',
    device: 'NM-2856', battery: 99, signal: 'Strong', recovery: 93, accuracy: 97.8,
    health: 'Improving', lastSession: 'Today, 8:30 AM', minutes: 35, streak: 20,
    note: 'Exceptional patient. Near-full functional recovery. Consider discharge planning.',
    wearingHoursPerDay: 11, totalWearingDays: 110,
    muscleHealth: 95, muscleRecoveryRate: 'Good',
    muscleStrength: 97, muscleEndurance: 94, muscleFlexibility: 92,
    muscleHistory: [
      { week: 'W1', score: 82 }, { week: 'W2', score: 86 }, { week: 'W3', score: 89 },
      { week: 'W4', score: 91 }, { week: 'W5', score: 93 }, { week: 'W6', score: 95 },
    ],
    trainingPlan: [
      { name: 'Advanced ADL full simulation', url: 'https://www.youtube.com/results?search_query=Advanced%20ADL%20full%20simulation%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'High-speed grip switching', url: 'https://www.youtube.com/results?search_query=High-speed%20grip%20switching%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Community integration tasks', url: 'https://www.youtube.com/results?search_query=Community%20integration%20tasks%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Discharge readiness assessment', url: 'https://www.youtube.com/results?search_query=Discharge%20readiness%20assessment%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Protein Supplement', dose: '30 g', frequency: 'Post-training', purpose: 'Muscle maintenance at advanced stage' },
      { name: 'Vitamin C', dose: '1000 mg', frequency: 'Once daily', purpose: 'Immune support and tissue repair' },
      { name: 'Zinc', dose: '15 mg', frequency: 'Once daily', purpose: 'Cellular recovery and healing' },
    ],
    sessionHistory: [
      { date: 'Today, 8:30 AM', duration: 35, accuracy: 97.8, notes: 'Near-perfect session. Discharge planning discussed.' },
      { date: 'Yesterday, 8:30 AM', duration: 34, accuracy: 97.5, notes: 'Excellent control and speed.' },
      { date: '2 days ago', duration: 33, accuracy: 97.1, notes: 'Outstanding compliance and adaptation.' },
    ]
  },
  {
    id: 'p17', name: 'Samy El-Adl', initials: 'SE', age: 58, condition: 'Shoulder disarticulation',
    device: 'NM-2857', battery: 25, signal: 'Weak', recovery: 38, accuracy: 76.4,
    health: 'Needs attention', lastSession: 'Sat, Nov 15 2026', minutes: 10, streak: 1,
    note: 'Difficult signal acquisition. Needs specialist review for socket fit.',
    wearingHoursPerDay: 2, totalWearingDays: 12,
    muscleHealth: 35, muscleRecoveryRate: 'Slow',
    muscleStrength: 30, muscleEndurance: 32, muscleFlexibility: 38,
    muscleHistory: [
      { week: 'W1', score: 25 }, { week: 'W2', score: 27 }, { week: 'W3', score: 29 },
      { week: 'W4', score: 31 }, { week: 'W5', score: 33 }, { week: 'W6', score: 35 },
    ],
    trainingPlan: [
      { name: 'Socket comfort assessment', url: 'https://www.youtube.com/results?search_query=Socket%20comfort%20assessment%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Minimal resistance signal training', url: 'https://www.youtube.com/results?search_query=Minimal%20resistance%20signal%20training%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Physio referral for shoulder mobility', url: 'https://www.youtube.com/results?search_query=Physio%20referral%20for%20shoulder%20mobility%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Weekly monitoring appointments', url: 'https://www.youtube.com/results?search_query=Weekly%20monitoring%20appointments%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '150 mg', frequency: 'Three times daily', purpose: 'Severe shoulder disarticulation pain' },
      { name: 'Amitriptyline', dose: '25 mg', frequency: 'Once at night', purpose: 'Chronic pain and sleep' },
      { name: 'Omeprazole', dose: '20 mg', frequency: 'Once daily before meals', purpose: 'Stomach protection from opioids' },
    ],
    sessionHistory: [
      { date: 'Sat, Nov 15 2026', duration: 10, accuracy: 76.4, notes: 'Very short session. Socket discomfort reported.' },
      { date: 'Tue, Nov 11 2026', duration: 12, accuracy: 75.2, notes: 'Signal highly variable.' },
      { date: 'Fri, Nov 7 2026', duration: 8, accuracy: 73.8, notes: 'First session. Difficult fitting.' },
    ]
  },
  {
    id: 'p18', name: 'Farida Osman', initials: 'FO', age: 31, condition: 'Right forearm amputation',
    device: 'NM-2858', battery: 84, signal: 'Strong', recovery: 81, accuracy: 94.0,
    health: 'Improving', lastSession: 'Tue, Nov 19 2026', minutes: 27, streak: 8,
    note: 'Strong progress. Transitioning to independent home training.',
    wearingHoursPerDay: 8.5, totalWearingDays: 60,
    muscleHealth: 80, muscleRecoveryRate: 'Good',
    muscleStrength: 82, muscleEndurance: 78, muscleFlexibility: 76,
    muscleHistory: [
      { week: 'W1', score: 65 }, { week: 'W2', score: 68 }, { week: 'W3', score: 72 },
      { week: 'W4', score: 75 }, { week: 'W5', score: 77 }, { week: 'W6', score: 80 },
    ],
    trainingPlan: [
      { name: 'Home training programme setup', url: 'https://www.youtube.com/results?search_query=Home%20training%20programme%20setup%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Self-monitoring checklist', url: 'https://www.youtube.com/results?search_query=Self-monitoring%20checklist%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Grip pattern variety (5 patterns)', url: 'https://www.youtube.com/results?search_query=Grip%20pattern%20variety%20(5%20patterns)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Monthly clinic check-in schedule', url: 'https://www.youtube.com/results?search_query=Monthly%20clinic%20check-in%20schedule%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Ibuprofen', dose: '200 mg', frequency: 'As needed', purpose: 'Mild inflammation post-session' },
      { name: 'Magnesium Glycinate', dose: '400 mg', frequency: 'Once at night', purpose: 'Muscle relaxation and recovery' },
      { name: 'Omega-3', dose: '1000 mg', frequency: 'Once daily', purpose: 'General anti-inflammatory' },
    ],
    sessionHistory: [
      { date: 'Tue, Nov 19 2026', duration: 27, accuracy: 94.0, notes: 'Ready for home training phase.' },
      { date: 'Sat, Nov 15 2026', duration: 26, accuracy: 93.2, notes: 'High confidence and accuracy.' },
      { date: 'Wed, Nov 12 2026', duration: 25, accuracy: 92.5, notes: 'Smooth session.' },
    ]
  },
  {
    id: 'p19', name: 'Walid Mounir', initials: 'WM', age: 45, condition: 'Left forearm amputation',
    device: 'NM-2859', battery: 50, signal: 'Good', recovery: 55, accuracy: 86.7,
    health: 'Stable', lastSession: 'Mon, Nov 17 2026', minutes: 18, streak: 3,
    note: 'Moderate progress. Needs encouragement and consistency.',
    wearingHoursPerDay: 4.5, totalWearingDays: 25,
    muscleHealth: 55, muscleRecoveryRate: 'Moderate',
    muscleStrength: 52, muscleEndurance: 50, muscleFlexibility: 55,
    muscleHistory: [
      { week: 'W1', score: 40 }, { week: 'W2', score: 43 }, { week: 'W3', score: 46 },
      { week: 'W4', score: 49 }, { week: 'W5', score: 52 }, { week: 'W6', score: 54 },
    ],
    trainingPlan: [
      { name: 'Basic forearm activation (2x10)', url: 'https://www.youtube.com/results?search_query=Basic%20forearm%20activation%20(2x10)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Motivational goal-setting session', url: 'https://www.youtube.com/results?search_query=Motivational%20goal-setting%20session%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Simple grip-release drills', url: 'https://www.youtube.com/results?search_query=Simple%20grip-release%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Increase daily wearing by 30 min/week', url: 'https://www.youtube.com/results?search_query=Increase%20daily%20wearing%20by%2030%20min%2Fweek%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Once at night', purpose: 'Phantom pain management' },
      { name: 'Vitamin B Complex', dose: '1 tablet', frequency: 'Once daily', purpose: 'Peripheral nerve health' },
      { name: 'Iron Supplement', dose: '325 mg', frequency: 'Once daily', purpose: 'Fatigue and energy' },
    ],
    sessionHistory: [
      { date: 'Mon, Nov 17 2026', duration: 18, accuracy: 86.7, notes: 'Patient engaged. Motivation improving.' },
      { date: 'Thu, Nov 13 2026', duration: 16, accuracy: 85.4, notes: 'Shorter session but positive attitude.' },
      { date: 'Mon, Nov 10 2026', duration: 15, accuracy: 84.8, notes: 'Needs encouragement at start.' },
    ]
  },
  {
    id: 'p20', name: 'Iman Saad', initials: 'IS', age: 38, condition: 'Right hand prosthesis',
    device: 'NM-2860', battery: 76, signal: 'Strong', recovery: 77, accuracy: 92.8,
    health: 'Improving', lastSession: 'Today, 10:30 AM', minutes: 25, streak: 9,
    note: 'Well-adapted. Daily tasks integration going smoothly.',
    wearingHoursPerDay: 8, totalWearingDays: 65,
    muscleHealth: 74, muscleRecoveryRate: 'Good',
    muscleStrength: 60, muscleEndurance: 58, muscleFlexibility: 63,
    muscleHistory: [
      { week: 'W1', score: 46 }, { week: 'W2', score: 50 }, { week: 'W3', score: 54 },
      { week: 'W4', score: 57 }, { week: 'W5', score: 60 }, { week: 'W6', score: 62 },
    ],
    trainingPlan: [
      { name: 'Daily task simulation (cooking, writing)', url: 'https://www.youtube.com/results?search_query=Daily%20task%20simulation%20(cooking%2C%20writing)%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Grip speed improvement drills', url: 'https://www.youtube.com/results?search_query=Grip%20speed%20improvement%20drills%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Control mode 2 practice', url: 'https://www.youtube.com/results?search_query=Control%20mode%202%20practice%20prosthetic%20arm%20rehabilitation%20exercise' },
      { name: 'Weekly accuracy benchmarks', url: 'https://www.youtube.com/results?search_query=Weekly%20accuracy%20benchmarks%20prosthetic%20arm%20rehabilitation%20exercise' },
    ],
    medicines: [
      { name: 'Pregabalin', dose: '75 mg', frequency: 'Twice daily', purpose: 'Bilateral phantom limb pain' },
      { name: 'Melatonin', dose: '5 mg', frequency: 'Once at bedtime', purpose: 'Pain-induced sleep disorder' },
      { name: 'Zinc + Magnesium', dose: '25 mg / 400 mg', frequency: 'Once daily', purpose: 'Bilateral limb recovery support' },
    ],
    sessionHistory: [
      { date: 'Today, 10:30 AM', duration: 25, accuracy: 92.8, notes: 'Daily tasks integrated well.' },
      { date: 'Yesterday, 10:45 AM', duration: 24, accuracy: 92.0, notes: 'Smooth and confident.' },
      { date: '3 days ago', duration: 23, accuracy: 91.3, notes: 'Good progress in speed.' },
    ]
  },
];

export const APPOINTMENTS: Appointment[] = [
  { id: 'a1', patientId: 'p1', patientName: 'Adel Imam', patientInitials: 'AI', date: 'Mon, Nov 4 2026', time: '9:00 AM', type: 'Progress Review', status: 'Completed', notes: 'Review grip training progress and adjust plan.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a2', patientId: 'p2', patientName: 'Yosra', patientInitials: 'YO', date: 'Mon, Nov 4 2026', time: '11:00 AM', type: 'Routine Check-up', status: 'Completed', notes: 'Monthly routine check and signal calibration.', fee: 300, paymentStatus: 'Paid' },
  { id: 'a3', patientId: 'p3', patientName: 'Ahmed El Sakka', patientInitials: 'AE', date: 'Tue, Nov 5 2026', time: '10:00 AM', type: 'Device Maintenance', status: 'Completed', notes: 'Charge device, check electrode contact, recalibrate.', fee: 500, paymentStatus: 'Paid' },
  { id: 'a4', patientId: 'p4', patientName: 'Mona Zaki', patientInitials: 'MZ', date: 'Tue, Nov 5 2026', time: '2:00 PM', type: 'Advanced Training', status: 'Completed', notes: 'Introduce fine-grip and two-hand coordination drills.', fee: 400, paymentStatus: 'Paid' },
  { id: 'a5', patientId: 'p5', patientName: 'Karim Abdel Aziz', patientInitials: 'KA', date: 'Wed, Nov 6 2026', time: '9:30 AM', type: 'Recalibration', status: 'Completed', notes: 'Full device recalibration session.', fee: 250, paymentStatus: 'Paid' },
  { id: 'a6', patientId: 'p1', patientName: 'Adel Imam', patientInitials: 'AI', date: 'Thu, Nov 20 2026', time: '9:42 AM', type: 'Training Session', status: 'Completed', notes: 'Grip control session completed successfully.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a7', patientId: 'p2', patientName: 'Yosra', patientInitials: 'YO', date: 'Thu, Nov 20 2026', time: '8:15 AM', type: 'Training Session', status: 'Completed', notes: 'Full 30-minute session completed.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a8', patientId: 'p6', patientName: 'Nour El-Sherif', patientInitials: 'NS', date: 'Thu, Nov 20 2026', time: '11:00 AM', type: 'Progress Review', status: 'Scheduled', notes: 'Monthly progress review and plan update.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a9', patientId: 'p8', patientName: 'Dina El-Wakil', patientInitials: 'DW', date: 'Thu, Nov 20 2026', time: '7:50 AM', type: 'Training Session', status: 'Completed', notes: 'Advanced fine-motor challenge drills.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a10', patientId: 'p16', patientName: 'Mariam Youssef', patientInitials: 'MY', date: 'Thu, Nov 20 2026', time: '8:30 AM', type: 'Advanced Training', status: 'Completed', notes: 'ADL full simulation session. Discharge plan discussed.', fee: 400, paymentStatus: 'Paid' },
  { id: 'a11', patientId: 'p20', patientName: 'Iman Saad', patientInitials: 'IS', date: 'Thu, Nov 20 2026', time: '10:30 AM', type: 'Training Session', status: 'Scheduled', notes: 'Daily task integration session.', fee: 350, paymentStatus: 'Pending' },
  { id: 'a12', patientId: 'p7', patientName: 'Omar Sharif', patientInitials: 'OS', date: 'Mon, Nov 17 2026', time: '10:00 AM', type: 'Recalibration', status: 'Completed', notes: 'Shoulder amplitude calibration and comfort review.', fee: 250, paymentStatus: 'Paid' },
  { id: 'a13', patientId: 'p11', patientName: 'Tarek Nour', patientInitials: 'TN', date: 'Mon, Nov 17 2026', time: '11:30 AM', type: 'Device Maintenance', status: 'Completed', notes: 'Electrode repositioning and signal check.', fee: 500, paymentStatus: 'Paid' },
  { id: 'a14', patientId: 'p19', patientName: 'Walid Mounir', patientInitials: 'WM', date: 'Mon, Nov 17 2026', time: '2:00 PM', type: 'Training Session', status: 'Completed', notes: 'Basic forearm activation and motivational session.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a15', patientId: 'p9', patientName: 'Hossam Habib', patientInitials: 'HH', date: 'Tue, Nov 18 2026', time: '9:00 AM', type: 'Routine Check-up', status: 'Completed', notes: 'Monthly routine check. Wearing schedule reviewed.', fee: 300, paymentStatus: 'Paid' },
  { id: 'a16', patientId: 'p13', patientName: 'Sherif Ramzy', patientInitials: 'SR', date: 'Tue, Nov 18 2026', time: '10:30 AM', type: 'Training Session', status: 'Completed', notes: 'ADL integration drills. Device stable.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a17', patientId: 'p15', patientName: 'Khaled Saleh', patientInitials: 'KS', date: 'Tue, Nov 18 2026', time: '1:00 PM', type: 'Progress Review', status: 'Completed', notes: 'EMG training progress assessment.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a18', patientId: 'p14', patientName: 'Ghada Adel', patientInitials: 'GA', date: 'Wed, Nov 19 2026', time: '9:30 AM', type: 'Training Session', status: 'Completed', notes: 'Bilateral synchrony drills completed.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a19', patientId: 'p18', patientName: 'Farida Osman', patientInitials: 'FO', date: 'Wed, Nov 19 2026', time: '11:00 AM', type: 'Training Session', status: 'Completed', notes: 'Home training programme finalised.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a20', patientId: 'p10', patientName: 'Layla Hassan', patientInitials: 'LH', date: 'Thu, Nov 20 2026', time: '9:00 AM', type: 'Training Session', status: 'Completed', notes: 'Bilateral coordination drills. Excellent session.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a21', patientId: 'p6', patientName: 'Nour El-Sherif', patientInitials: 'NS', date: 'Fri, Nov 7 2026', time: '10:00 AM', type: 'Initial Assessment', status: 'Completed', notes: 'First assessment. Device fitted and calibrated.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a22', patientId: 'p12', patientName: 'Rania Farid', patientInitials: 'RF', date: 'Sat, Nov 8 2026', time: '9:00 AM', type: 'Training Session', status: 'Completed', notes: 'Wrist pronation-supination drills.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a23', patientId: 'p17', patientName: 'Samy El-Adl', patientInitials: 'SE', date: 'Sun, Nov 9 2026', time: '11:00 AM', type: 'Initial Assessment', status: 'Completed', notes: 'First assessment. Socket fitting review required.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a24', patientId: 'p11', patientName: 'Tarek Nour', patientInitials: 'TN', date: 'Mon, Nov 10 2026', time: '10:00 AM', type: 'Device Maintenance', status: 'Completed', notes: 'Initial calibration and electrode check.', fee: 500, paymentStatus: 'Paid' },
  { id: 'a25', patientId: 'p19', patientName: 'Walid Mounir', patientInitials: 'WM', date: 'Mon, Nov 10 2026', time: '2:30 PM', type: 'Training Session', status: 'Completed', notes: 'Basic forearm activation session.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a26', patientId: 'p7', patientName: 'Omar Sharif', patientInitials: 'OS', date: 'Tue, Nov 11 2026', time: '9:00 AM', type: 'Routine Check-up', status: 'Completed', notes: 'Shoulder comfort and signal quality review.', fee: 300, paymentStatus: 'Paid' },
  { id: 'a27', patientId: 'p17', patientName: 'Samy El-Adl', patientInitials: 'SE', date: 'Tue, Nov 11 2026', time: '11:00 AM', type: 'Device Maintenance', status: 'Completed', notes: 'Signal threshold calibration attempt.', fee: 500, paymentStatus: 'Pending' },
  { id: 'a28', patientId: 'p12', patientName: 'Rania Farid', patientInitials: 'RF', date: 'Tue, Nov 11 2026', time: '1:00 PM', type: 'Training Session', status: 'Completed', notes: 'Grip endurance sets.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a29', patientId: 'p14', patientName: 'Ghada Adel', patientInitials: 'GA', date: 'Wed, Nov 12 2026', time: '10:00 AM', type: 'Routine Check-up', status: 'Completed', notes: 'Bilateral device check and fatigue assessment.', fee: 300, paymentStatus: 'Paid' },
  { id: 'a30', patientId: 'p18', patientName: 'Farida Osman', patientInitials: 'FO', date: 'Wed, Nov 12 2026', time: '11:30 AM', type: 'Training Session', status: 'Completed', notes: 'Grip pattern variety session.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a31', patientId: 'p9', patientName: 'Hossam Habib', patientInitials: 'HH', date: 'Thu, Nov 13 2026', time: '9:30 AM', type: 'Training Session', status: 'Completed', notes: 'Two-finger pinch exercises. Good range of motion.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a32', patientId: 'p11', patientName: 'Tarek Nour', patientInitials: 'TN', date: 'Thu, Nov 13 2026', time: '11:00 AM', type: 'Routine Check-up', status: 'Completed', notes: 'Signal check. Patient tires quickly.', fee: 300, paymentStatus: 'Paid' },
  { id: 'a33', patientId: 'p15', patientName: 'Khaled Saleh', patientInitials: 'KS', date: 'Thu, Nov 13 2026', time: '2:00 PM', type: 'Training Session', status: 'Completed', notes: 'Precision grip tasks completed.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a34', patientId: 'p12', patientName: 'Rania Farid', patientInitials: 'RF', date: 'Fri, Nov 14 2026', time: '9:00 AM', type: 'Progress Review', status: 'Completed', notes: 'Positive progress review. Plan advanced.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a35', patientId: 'p17', patientName: 'Samy El-Adl', patientInitials: 'SE', date: 'Sat, Nov 15 2026', time: '10:00 AM', type: 'Device Maintenance', status: 'Completed', notes: 'Socket discomfort review. Physio referral made.', fee: 500, paymentStatus: 'Paid' },
  { id: 'a36', patientId: 'p18', patientName: 'Farida Osman', patientInitials: 'FO', date: 'Sat, Nov 15 2026', time: '11:30 AM', type: 'Training Session', status: 'Completed', notes: 'High confidence session. Home training prep.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a37', patientId: 'p14', patientName: 'Ghada Adel', patientInitials: 'GA', date: 'Sat, Nov 15 2026', time: '2:00 PM', type: 'Training Session', status: 'Cancelled', notes: 'Cancelled due to patient illness.', fee: 350, paymentStatus: 'Pending' },
  { id: 'a38', patientId: 'p5', patientName: 'Karim Abdel Aziz', patientInitials: 'KA', date: 'Thu, Nov 20 2026', time: '3:00 PM', type: 'Recalibration', status: 'Scheduled', notes: 'Full recalibration due this week.', fee: 250, paymentStatus: 'Pending' },
  { id: 'a39', patientId: 'p3', patientName: 'Ahmed El Sakka', patientInitials: 'AE', date: 'Thu, Nov 20 2026', time: '4:00 PM', type: 'Device Maintenance', status: 'Scheduled', notes: 'Battery charge and electrode contact check.', fee: 500, paymentStatus: 'Pending' },
  { id: 'a40', patientId: 'p4', patientName: 'Mona Zaki', patientInitials: 'MZ', date: 'Fri, Nov 21 2026', time: '10:00 AM', type: 'Advanced Training', status: 'Scheduled', notes: 'Next level fine-grip plan introduction.', fee: 400, paymentStatus: 'Pending' },
  { id: 'a41', patientId: 'p10', patientName: 'Layla Hassan', patientInitials: 'LH', date: 'Fri, Nov 21 2026', time: '11:00 AM', type: 'Training Session', status: 'Scheduled', notes: 'ADL practice and level 3 control mode.', fee: 350, paymentStatus: 'Paid' },
  { id: 'a42', patientId: 'p16', patientName: 'Mariam Youssef', patientInitials: 'MY', date: 'Sat, Nov 22 2026', time: '9:00 AM', type: 'Progress Review', status: 'Scheduled', notes: 'Discharge readiness final review.', fee: 350, paymentStatus: 'Paid' },
];

export const REVENUES: Revenue[] = [
  { id: 'r1', patientName: 'Adel Imam', date: 'Thu, Nov 20 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r2', patientName: 'Yosra', date: 'Thu, Nov 20 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r3', patientName: 'Ahmed El Sakka', date: 'Tue, Nov 5 2026', amount: 500, type: 'Device maintenance', status: 'Paid' },
  { id: 'r4', patientName: 'Mona Zaki', date: 'Thu, Nov 20 2026', amount: 400, type: 'Advanced training', status: 'Paid' },
  { id: 'r5', patientName: 'Karim Abdel Aziz', date: 'Wed, Nov 6 2026', amount: 250, type: 'Recalibration', status: 'Paid' },
  { id: 'r6', patientName: 'Adel Imam', date: 'Mon, Nov 4 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r7', patientName: 'Yosra', date: 'Mon, Nov 4 2026', amount: 300, type: 'Routine check-up', status: 'Paid' },
  { id: 'r8', patientName: 'Nour El-Sherif', date: 'Thu, Nov 20 2026', amount: 350, type: 'Progress review', status: 'Paid' },
  { id: 'r9', patientName: 'Dina El-Wakil', date: 'Thu, Nov 20 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r10', patientName: 'Mariam Youssef', date: 'Thu, Nov 20 2026', amount: 400, type: 'Advanced training', status: 'Paid' },
  { id: 'r11', patientName: 'Omar Sharif', date: 'Mon, Nov 17 2026', amount: 250, type: 'Recalibration', status: 'Paid' },
  { id: 'r12', patientName: 'Tarek Nour', date: 'Mon, Nov 17 2026', amount: 500, type: 'Device maintenance', status: 'Paid' },
  { id: 'r13', patientName: 'Walid Mounir', date: 'Mon, Nov 17 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r14', patientName: 'Hossam Habib', date: 'Tue, Nov 18 2026', amount: 300, type: 'Routine check-up', status: 'Paid' },
  { id: 'r15', patientName: 'Sherif Ramzy', date: 'Tue, Nov 18 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r16', patientName: 'Khaled Saleh', date: 'Tue, Nov 18 2026', amount: 350, type: 'Progress review', status: 'Paid' },
  { id: 'r17', patientName: 'Ghada Adel', date: 'Wed, Nov 19 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r18', patientName: 'Farida Osman', date: 'Wed, Nov 19 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r19', patientName: 'Layla Hassan', date: 'Thu, Nov 20 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r20', patientName: 'Rania Farid', date: 'Fri, Nov 14 2026', amount: 350, type: 'Progress review', status: 'Paid' },
  { id: 'r21', patientName: 'Samy El-Adl', date: 'Sat, Nov 15 2026', amount: 500, type: 'Device maintenance', status: 'Paid' },
  { id: 'r22', patientName: 'Farida Osman', date: 'Sat, Nov 15 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r23', patientName: 'Hossam Habib', date: 'Thu, Nov 13 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r24', patientName: 'Khaled Saleh', date: 'Thu, Nov 13 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r25', patientName: 'Rania Farid', date: 'Tue, Nov 11 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r26', patientName: 'Nour El-Sherif', date: 'Fri, Nov 7 2026', amount: 350, type: 'Initial assessment', status: 'Paid' },
  { id: 'r27', patientName: 'Rania Farid', date: 'Sat, Nov 8 2026', amount: 350, type: 'Session fee', status: 'Paid' },
  { id: 'r28', patientName: 'Samy El-Adl', date: 'Sun, Nov 9 2026', amount: 350, type: 'Initial assessment', status: 'Paid' },
];

export const EXPENSES: Expense[] = [
  { id: 'e1', description: 'Electrode gel packs (x20)', date: 'Thu, Nov 20 2026', amount: 120, category: 'Supplies' },
  { id: 'e2', description: 'Clinic electricity bill', date: 'Nov 1 2026', amount: 280, category: 'Utilities' },
  { id: 'e3', description: 'MYOWARE sensor calibration kit', date: 'Oct 30 2026', amount: 450, category: 'Equipment' },
  { id: 'e4', description: 'Disposable gloves (x100)', date: 'Oct 29 2026', amount: 60, category: 'Supplies' },
  { id: 'e5', description: 'Cleaning staff', date: 'Nov 2 2026', amount: 150, category: 'Staff' },
  { id: 'e6', description: 'Prosthetic socket liners (x5)', date: 'Nov 7 2026', amount: 320, category: 'Equipment' },
  { id: 'e7', description: 'Clinic internet & phone bill', date: 'Nov 10 2026', amount: 95, category: 'Utilities' },
  { id: 'e8', description: 'EMG electrode pads (x50)', date: 'Nov 12 2026', amount: 180, category: 'Supplies' },
  { id: 'e9', description: 'Medical waste disposal', date: 'Nov 15 2026', amount: 85, category: 'Supplies' },
  { id: 'e10', description: 'Physio consultant fee (Nov)', date: 'Nov 18 2026', amount: 500, category: 'Staff' },
  { id: 'e11', description: 'Software licence renewal (MYO system)', date: 'Nov 19 2026', amount: 240, category: 'Equipment' },
  { id: 'e12', description: 'Printer paper & stationery', date: 'Nov 20 2026', amount: 45, category: 'Supplies' },
];







