import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Patient, DeviceSettings, FeedbackPattern, PowerMode, getSafetyIssues, MAX_SAFE_INTENSITY } from '../models';

@Component({
  selector: 'app-devices',
  template: `
    <section class="page-heading">
      <div>
        <p class="eyebrow">Patient configuration</p>
        <h1>Device management</h1>
        <p>Safely adjust haptic feedback and MYOWARE 2.0 monitoring settings for {{patient.name}}.</p>
      </div>
      <div class="save-indicator" aria-live="polite">
        <app-icon name="check" [size]="17"></app-icon>{{saved ? 'Settings saved' : 'Saving\u2026'}}
      </div>
    </section>
    <app-safety-warning [settings]="settings"></app-safety-warning>
    <div class="device-settings-grid">

      <section class="panel settings-panel">
        <div class="settings-title">
          <div class="metric-icon violet"><app-icon name="target"></app-icon></div>
          <div><h2>Signal calibration</h2><p>Set the activation threshold for movement detection.</p></div>
        </div>
        <div class="range-block">
          <div class="range-label">
            <label for="threshold">Activation threshold</label>
            <strong>{{settings.threshold}}%</strong>
          </div>
          <input id="threshold" type="range" min="10" max="90"
                 [value]="settings.threshold"
                 (input)="update({threshold: +asInput($event).value})"
                 [style.--value]="((settings.threshold - 10) / 0.8) + '%'" />
          <div class="range-ends"><span>More sensitive</span><span>Less sensitive</span></div>
        </div>
        <div class="calibration-box">
          <div><app-icon name="check" [size]="16"></app-icon></div>
          <span><strong>Calibration is current</strong>Last calibrated today at 9:42 AM</span>
          <a href="https://myoware.com/products/technical-specifications/" target="_blank" rel="noopener noreferrer">Recalibrate</a>
        </div>
      </section>
    </div>

    <section class="panel hardware-safety-panel" [class.limit-exceeded]="hasHardwareSafetyIssues">
      <div class="hardware-safety-header">
        <div>
          <div class="metric-icon mint"><app-icon name="device"></app-icon></div>
          <span><h2>MYOWARE 2.0 hardware safeguards</h2><p>Manufacturer operating limits and body-connected setup checks.</p></span>
        </div>
        <a href="https://myoware.com/products/technical-specifications/" target="_blank" rel="noreferrer">Official specifications <app-icon name="arrow" [size]="14"></app-icon></a>
      </div>
      <div class="hardware-safety-grid">
        <label>
          <span>Supply voltage</span>
          <div class="voltage-control">
            <input type="number" min="2" max="6" step=".01"
                   [value]="settings.supplyVoltage"
                   (input)="update({supplyVoltage: +asInput($event).value})" />
            <b>V</b>
          </div>
          <small>Allowed: 2.27\u20135.47 V &middot; Typical: 3.3 V or 5 V</small>
        </label>
        <label>
          <span>Power connection</span>
          <select class="select-control" [value]="settings.powerMode" (change)="onPowerModeChange($event)">
            <option value="laptop-usb">Laptop USB</option>
            <option value="battery">Battery</option>
          </select>
          <small>Body-connected grid power requires USB isolation.</small>
        </label>
      </div>
      <p class="hardware-safety-note">Hardware specifications support setup monitoring and do not replace clinical judgment or the manufacturer's full instructions.</p>
    </section>
  `
})
export class DevicesComponent {
  @Input() patient!: Patient;
  @Input() settings!: DeviceSettings;
  @Output() settingsChange = new EventEmitter<Partial<DeviceSettings>>();

  saved = true;
  private saveTimer: any = null;

  get overSafetyLimit(): boolean {
    return this.settings.intensity > MAX_SAFE_INTENSITY;
  }

  get hasHardwareSafetyIssues(): boolean {
    return getSafetyIssues(this.settings).some(issue => issue.id !== 'intensity');
  }

  update(changes: Partial<DeviceSettings>): void {
    this.saved = false;
    this.settingsChange.emit(changes);
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => this.saved = true, 350);
  }

  onPatternChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as FeedbackPattern;
    this.update({ pattern: val });
  }

  onPowerModeChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as PowerMode;
    this.update({ powerMode: val });
  }

  asCheckbox(event: Event): HTMLInputElement {
    return event.target as HTMLInputElement;
  }

  asInput(event: Event): HTMLInputElement {
    return event.target as HTMLInputElement;
  }

  asSelect(event: Event): HTMLSelectElement {
    return event.target as HTMLSelectElement;
  }
}
