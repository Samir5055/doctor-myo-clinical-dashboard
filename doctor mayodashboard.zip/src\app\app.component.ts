import { Component } from '@angular/core';
import { AppService } from './app.service';
import { View } from './models';

@Component({
  selector: 'app-root',
  template: `
    <!-- Disney+ Style Profile Picker -->
    <app-profile-picker
      *ngIf="svc.showPicker"
      (profileSelected)="onProfileSelected($event)">
    </app-profile-picker>

    <!-- Main Dashboard Shell -->
    <div *ngIf="!svc.showPicker" class="app-shell" [class.collapsed]="svc.collapsed" [class.sec-mode]="svc.role === 'secretary'" [class.role-animating]="isSwitchingRole" [class.dark-theme]="svc.role === 'doctor' && svc.darkMode">
      <app-sidebar
        [view]="svc.role === 'secretary' ? svc.secretaryTab : svc.view"
        [open]="svc.menuOpen"
        [role]="svc.role"
        (viewChange)="onViewChange($event)"
        (closeEvent)="svc.closeMenu()"
        (collapseEvent)="svc.collapse()">
      </app-sidebar>
      <button *ngIf="svc.menuOpen"
              class="sidebar-backdrop"
              (click)="svc.closeMenu()"
              aria-label="Close menu"></button>
      <div class="main-area">
        <app-page-header (openMenu)="svc.openMenu()"></app-page-header>
        <main class="content" [class.sec-mode]="svc.role === 'secretary'">
          <!-- Secretary Dashboard -->
          <app-secretary-dashboard
            *ngIf="svc.role === 'secretary'"
            [activeTab]="svc.secretaryTab"
            (tabChange)="svc.setSecretaryTab($event)">
          </app-secretary-dashboard>

          <!-- Doctor Views -->
          <ng-container *ngIf="svc.role === 'doctor'">
            <app-overview
              *ngIf="svc.view === 'overview'"
              [connected]="svc.connected"
              [settings]="svc.getCurrentDeviceSettings()"
              (setView)="svc.setView($event)">
            </app-overview>
            <app-live-signal
              *ngIf="svc.view === 'signal'"
              [connected]="svc.connected"
              (toggleConnected)="svc.toggleConnected()"
              (setView)="svc.setView($event)">
            </app-live-signal>
            <ng-container *ngIf="svc.view === 'patients'">
              <app-patient-history
                *ngIf="svc.detail && showHistory"
                [patient]="svc.getCurrentPatient()"
                (back)="showHistory = false">
              </app-patient-history>
              <app-patient-status
                *ngIf="svc.detail && !showHistory"
                [patient]="svc.getCurrentPatient()"
                (back)="svc.setDetail(false)"
                (setView)="svc.setView($event)"
                (viewHistory)="showHistory = true">
              </app-patient-status>
              <app-patients
                *ngIf="!svc.detail"
                (selectPatient)="onSelectPatient($event)">
              </app-patients>
            </ng-container>
            <app-appointments *ngIf="svc.view === 'appointments'"></app-appointments>
          </ng-container>
        </main>
      </div>
    </div>
  `
})
export class AppComponent {
  showHistory = false;
  isSwitchingRole = false;
  constructor(public svc: AppService) {
    let lastRole = svc.role;
    this.svc.role$.subscribe(r => {
      if (r !== lastRole) {
        lastRole = r;
        this.isSwitchingRole = true;
        setTimeout(() => this.isSwitchingRole = false, 650);
      }
    });
  }

  onProfileSelected(role: 'doctor' | 'secretary'): void {
    this.svc.selectProfile(role);
  }

  onViewChange(v: View): void {
    if (this.svc.role === 'secretary') {
      if (v === 'wallet' || v === 'appointments') {
        this.svc.setSecretaryTab(v as any);
      }
    }
    this.svc.setView(v);
  }

  onSelectPatient(id: string): void {
    this.svc.setPatientId(id);
    this.svc.setDetail(true);
    this.showHistory = false;
  }
}
