export type View = 'overview' | 'signal' | 'patients' | 'appointments' | 'wallet';
export type Gesture = 'clench' | 'spread';
export type Health = 'Stable' | 'Improving' | 'Needs attention';
export type FeedbackPattern = 'Adaptive pulse' | 'Single pulse' | 'Continuous';
export type PowerMode = 'battery' | 'isolated-usb' | 'direct-usb';

export interface DeviceSettings {
  hapticsEnabled: boolean;
  intensity: number;
  threshold: number;
  pattern: FeedbackPattern;
  supplyVoltage: number;
  powerMode: PowerMode;
}

export interface SafetyIssue {
  id: string;
  title: string;
  detail: string;
}

export interface Patient {
  id: string;
  name: string;
  initials: string;
  age: number;
  condition: string;
  device: string;
  battery: number;
  signal: string;
  recovery: number;
  accuracy: number;
  health: Health;
  lastSession: string;
  minutes: number;
  streak: number;
  note: string;
  // Extended fields
  wearingHoursPerDay: number;
  totalWearingDays: number;
  muscleHealth: number;        // 0-100 overall score
  muscleRecoveryRate: string;  // e.g. "Good", "Moderate", "Slow"
  muscleStrength: number;      // 0-100
  muscleEndurance: number;     // 0-100
  muscleFlexibility: number;   // 0-100
  muscleHistory: { week: string; score: number }[]; // weekly trend
  trainingPlan: { name: string; url: string }[]; // list of recommended exercises with YouTube links
  medicines: { name: string; dose: string; frequency: string; purpose: string }[];
  sessionHistory: SessionRecord[];
}

export interface SessionRecord {
  date: string;
  duration: number; // minutes
  accuracy: number;
  notes: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientInitials: string;
  date: string;
  time: string;
  type: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  notes: string;
  fee: number;
  paymentStatus?: 'Paid' | 'Pending';
}

export type DashboardRole = 'doctor' | 'secretary';

export interface Revenue {
  id: string;
  patientName: string;
  date: string;
  amount: number;
  type: string; // e.g. "Session fee", "Device maintenance", "Consultation"
  status: 'Paid' | 'Pending';
}

export interface Expense {
  id: string;
  description: string;
  date: string;
  amount: number;
  category: string; // e.g. "Supplies", "Equipment", "Utilities", "Staff"
}

export const DEFAULT_DEVICE_SETTINGS: DeviceSettings = {
  hapticsEnabled: true,
  intensity: 68,
  threshold: 42,
  pattern: 'Adaptive pulse',
  supplyVoltage: 3.3,
  powerMode: 'battery',
};

export const MAX_SAFE_INTENSITY = 85;
export const MIN_SUPPLY_VOLTAGE = 2.27;
export const MAX_SUPPLY_VOLTAGE = 5.47;
export const DEVICE_SETTINGS_STORAGE_KEY = 'myoarm-device-settings';

export function getSafetyIssues(settings: DeviceSettings): SafetyIssue[] {
  const issues: SafetyIssue[] = [];
  if (settings.intensity > MAX_SAFE_INTENSITY) {
    issues.push({
      id: 'intensity',
      title: 'Clinic intensity policy exceeded',
      detail: `Feedback intensity is ${settings.intensity}%, above the clinic maximum of ${MAX_SAFE_INTENSITY}%.`,
    });
  }
  if (settings.supplyVoltage < MIN_SUPPLY_VOLTAGE || settings.supplyVoltage > MAX_SUPPLY_VOLTAGE) {
    issues.push({
      id: 'voltage',
      title: 'Supply voltage outside MYOWARE 2.0 limits',
      detail: `${settings.supplyVoltage.toFixed(2)} V is outside the manufacturer range of ${MIN_SUPPLY_VOLTAGE}–${MAX_SUPPLY_VOLTAGE} V.`,
    });
  }
  if (settings.powerMode === 'direct-usb') {
    issues.push({
      id: 'isolation',
      title: 'Electrical isolation required',
      detail: 'Do not use a direct grid-powered USB connection while the sensor is attached to the body. Use a USB isolator or battery power.',
    });
  }
  return issues;
}

export function healthClass(h: Health): string {
  return h === 'Needs attention' ? 'warn' : h === 'Improving' ? 'good' : 'neutral';
}
