import { Component, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-picker',
  template: `
    <div class="picker-overlay"
         [class.fade-out]="fadingOut"
         [class.hover-doctor]="hovered === 'doctor'"
         [class.hover-secretary]="hovered === 'secretary'">

      <div class="picker-content" [class.ready]="ready">

        <!-- Title only — no icon, no subtitle -->
        <h1 class="logo-text">MYOArm Clinic</h1>

        <div class="profiles-row">

          <!-- Doctor Card -->
          <button class="profile-card doctor"
                  (click)="select('doctor')"
                  (mouseenter)="hovered = 'doctor'"
                  (mouseleave)="hovered = null"
                  [class.selected]="selecting === 'doctor'">
            <div class="avatar-ring doctor-ring">
              <div class="profile-avatar">
                <img src="assets/doctor-profile.jpg" alt="Dr. Ahmed" />
              </div>
            </div>
            <div class="profile-name">Dr. Ahmed</div>
            <div class="profile-role">MYO Device Specialist</div>
          </button>

          <!-- Secretary Card -->
          <button class="profile-card secretary"
                  (click)="select('secretary')"
                  (mouseenter)="hovered = 'secretary'"
                  (mouseleave)="hovered = null"
                  [class.selected]="selecting === 'secretary'">
            <div class="avatar-ring secretary-ring">
              <div class="profile-avatar secretary-bg">
                <img src="assets/secretary-profile.png" alt="Ms. Sara" />
              </div>
            </div>
            <div class="profile-name">Ms. Sara</div>
            <div class="profile-role">Clinic Secretary</div>
          </button>

        </div>
      </div>
    </div>
  `,
  styles: [`
    /* ── Base overlay ──────────────────────────────────── */
    .picker-overlay {
      position: fixed;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: overlayIn 0.5s ease both;

      /* default: deep dark navy */
      background:
        radial-gradient(ellipse 80% 70% at 30% 40%, #0d2a4a 0%, transparent 65%),
        radial-gradient(ellipse 70% 60% at 70% 60%, #07192b 0%, transparent 65%),
        #060f1a;

      /* smooth color-shift transitions */
      transition:
        background 0.6s cubic-bezier(0.4,0,0.2,1),
        opacity 0.55s ease,
        transform 0.55s ease;
    }

    /* Hovered on Doctor → sky-blue shift */
    .picker-overlay.hover-doctor {
      background:
        radial-gradient(ellipse 100% 90% at 30% 40%, #083d6b 0%, transparent 60%),
        radial-gradient(ellipse 80% 70% at 70% 65%, #032a52 0%, transparent 65%),
        radial-gradient(ellipse 60% 50% at 50% 50%, #0a3f70 0%, transparent 70%),
        #04182e;
    }

    /* Hovered on Secretary → warm brown shift */
    .picker-overlay.hover-secretary {
      background:
        radial-gradient(ellipse 100% 90% at 70% 40%, #4a1e06 0%, transparent 60%),
        radial-gradient(ellipse 80% 70% at 30% 65%, #2e1205 0%, transparent 65%),
        radial-gradient(ellipse 60% 50% at 50% 50%, #3d1808 0%, transparent 70%),
        #1a0a02;
    }

    .picker-overlay.fade-out {
      opacity: 0;
      transform: scale(1.04);
      pointer-events: none;
    }

    @keyframes overlayIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }

    /* ── Content wrapper ───────────────────────────────── */
    .picker-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0;
      opacity: 0;
      transform: translateY(28px);
      transition: opacity 0.5s ease 0.1s, transform 0.5s ease 0.1s;
    }
    .picker-content.ready {
      opacity: 1;
      transform: translateY(0);
    }

    /* ── Big title ─────────────────────────────────────── */
    .logo-text {
      font-size: clamp(2.6rem, 6vw, 4.2rem);
      font-weight: 900;
      color: #fff;
      letter-spacing: 1.5px;
      margin: 0 0 52px;
      text-align: center;
      line-height: 1.1;
      /* glow shifts with hover — controlled via overlay class on parent */
      text-shadow:
        0 0 32px rgba(56, 189, 248, 0.45),
        0 2px 8px rgba(0,0,0,0.5);
      transition: text-shadow 0.6s ease;
    }
    .hover-doctor   .logo-text { text-shadow: 0 0 48px rgba(56,189,248,0.75), 0 2px 8px rgba(0,0,0,0.5); }
    .hover-secretary .logo-text { text-shadow: 0 0 48px rgba(194,145,106,0.80), 0 2px 8px rgba(0,0,0,0.5); }

    /* ── Cards row ─────────────────────────────────────── */
    .profiles-row {
      display: flex;
      gap: 64px;
      justify-content: center;
      align-items: flex-start;
      flex-wrap: wrap;
    }

    .profile-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
      outline: none;
      transition: transform 0.22s cubic-bezier(.34,1.56,.64,1);
    }
    .profile-card:hover         { transform: scale(1.09) translateY(-8px); }
    .profile-card.selected      { transform: scale(0.95); }

    /* ── Avatar ring (rounded square, Disney+ style) ──── */
    .avatar-ring {
      border-radius: 18px;
      padding: 4px;
      transition: box-shadow 0.35s ease;
      margin-bottom: 20px;
    }
    .doctor-ring {
      background: linear-gradient(135deg, #38bdf8, #0ea5e9);
      box-shadow: 0 0 0 0px rgba(56,189,248,0.3);
    }
    .profile-card:hover .doctor-ring {
      box-shadow: 0 0 0 10px rgba(56,189,248,0.18), 0 0 50px rgba(56,189,248,0.55);
    }
    .secretary-ring {
      background: linear-gradient(135deg, #c2916a, #8b4513);
      box-shadow: 0 0 0 0px rgba(194,145,106,0.3);
    }
    .profile-card:hover .secretary-ring {
      box-shadow: 0 0 0 10px rgba(194,145,106,0.20), 0 0 50px rgba(194,145,106,0.60);
    }

    /* ── Avatar square ─────────────────────────────────── */
    .profile-avatar {
      width: 160px;
      height: 160px;
      border-radius: 14px;
      overflow: hidden;
      background: #29b6f6;
    }
    /* Secretary: brown background, contain icon (it has white bg originally) */
    .profile-avatar.secretary-bg {
      background: #6b3010;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .profile-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .profile-avatar.secretary-bg img {
      object-fit: contain;
      width: 88%;
      height: 88%;
    }

    /* ── Labels ────────────────────────────────────────── */
    .profile-name {
      color: #fff;
      font-size: 1.18rem;
      font-weight: 700;
      letter-spacing: 0.3px;
    }
    .profile-role {
      color: rgba(255,255,255,0.42);
      font-size: 0.82rem;
      margin-top: 5px;
      letter-spacing: 0.5px;
    }

    /* ── Stagger entrance animations ───────────────────── */
    .profiles-row .profile-card:nth-child(1) {
      animation: cardPop 0.5s cubic-bezier(.34,1.56,.64,1) 0.28s both;
    }
    .profiles-row .profile-card:nth-child(2) {
      animation: cardPop 0.5s cubic-bezier(.34,1.56,.64,1) 0.44s both;
    }
    @keyframes cardPop {
      from { opacity: 0; transform: scale(0.7) translateY(22px); }
      to   { opacity: 1; transform: scale(1)   translateY(0); }
    }
  `]
})
export class ProfilePickerComponent implements OnInit {
  @Output() profileSelected = new EventEmitter<'doctor' | 'secretary'>();

  ready = false;
  fadingOut = false;
  selecting: 'doctor' | 'secretary' | null = null;
  hovered: 'doctor' | 'secretary' | null = null;

  ngOnInit(): void {
    setTimeout(() => { this.ready = true; }, 50);
  }

  select(role: 'doctor' | 'secretary'): void {
    if (this.fadingOut) return;
    this.selecting = role;
    this.fadingOut = true;
    setTimeout(() => {
      this.profileSelected.emit(role);
    }, 520);
  }
}
