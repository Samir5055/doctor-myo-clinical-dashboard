import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, OnChanges, SimpleChanges, NgZone } from '@angular/core';
import { Gesture } from '../models';

@Component({
  selector: 'app-signal-chart',
  template: `
    <section class="panel chart-panel scope">
      <div class="scope-head">
        <div>
          <div class="live-label" [class.offline]="!connected">
            <i></i> {{!connected ? 'DISCONNECTED' : paused ? 'PAUSED' : 'STREAMING'}}
          </div>
          <h2>Surface EMG &middot; Channel 1</h2>
          <p>Left quadriceps (vastus lateralis)</p>
        </div>
        <button class="scope-button" (click)="togglePause()" [disabled]="!connected">
          {{!connected ? 'Offline' : paused ? 'Resume' : 'Pause'}}
        </button>
      </div>
      <div class="scope-chips">
        <span>Sample rate <b>{{connected ? '1000' : '0'}} Hz</b></span>
        <span>Gain <b>x{{connected ? '200' : '0'}}</b></span>
        <span>Filter <b>{{connected ? '20\u2013450' : '0'}} Hz</b></span>
        <span>Window <b>{{connected ? '8' : '0'}} s</b></span>
      </div>
      <div class="scope-plot">
        <div class="scope-disconnected" *ngIf="!connected">Signal disconnected</div>
        <div class="y-ticks">
          <span *ngFor="let t of yTickValues">{{t}}</span>
        </div>
        <svg viewBox="0 0 800 240" preserveAspectRatio="none" role="img" aria-label="Live EMG waveform">
          <defs>
            <linearGradient id="signalFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#2dd4bf" stop-opacity=".35"/>
              <stop offset="100%" stop-color="#2dd4bf" stop-opacity="0"/>
            </linearGradient>
          </defs>
          <line *ngFor="let g of hGridLines" x1="0" x2="800" [attr.y1]="g" [attr.y2]="g" class="scope-grid"/>
          <line *ngFor="let g of vGridLines" y1="0" y2="240" [attr.x1]="g" [attr.x2]="g" class="scope-grid"/>
          <line x1="0" x2="800" [attr.y1]="yVal(thresholdValue)" [attr.y2]="yVal(thresholdValue)" class="scope-threshold"/>
          <polygon [attr.points]="polygonPoints" fill="url(#signalFill)"/>
          <polyline [attr.points]="linePoints" fill="none" stroke="#5eead4" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
        </svg>
        <span class="threshold-tag">Activation threshold {{thresholdValue.toFixed(1)}} mV</span>
        <div class="x-ticks"><span>-8 s</span><span>-6 s</span><span>-4 s</span><span>-2 s</span><span>Now</span></div>
      </div>
      <div class="scope-readout">
        <div><span>Current</span><b>{{current.toFixed(2)}} mV</b></div>
        <div><span>RMS</span><b>{{rms.toFixed(2)}} mV</b></div>
        <div><span>Peak</span><b>{{peak.toFixed(2)}} mV</b></div>
        <div><span>Baseline noise</span><b>{{connected ? '0.08' : '0.00'}} mV</b></div>
      </div>
    </section>
  `
})
export class SignalChartComponent implements OnInit, OnDestroy, OnChanges {
  @Input() connected = true;
  @Output() gestureChange = new EventEmitter<Gesture>();
  @Output() movementChange = new EventEmitter<boolean>();
  @Output() placementChange = new EventEmitter<boolean>();

  values: number[] = [];
  paused = false;
  private timerId: any = null;

  current = 0;
  peak = 0;
  rms = 0;
  thresholdValue = 2.5;
  linePoints = '';
  polygonPoints = '';

  yTickValues = ['4.0', '3.0', '2.0', '1.0', '0.0'];
  hGridLines = [0, 60, 120, 180, 240];
  vGridLines = [0, 160, 320, 480, 640, 800];

  constructor(private ngZone: NgZone) {}

  ngOnInit(): void {
    this.values = Array.from({ length: 160 }, (_, i) => 1.2 + Math.sin(i / 4) * 0.5 + Math.random() * 0.3);
    this.updateComputedValues();
    this.startTimer();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['connected']) {
      this.stopTimer();
      if (this.connected && !this.paused) {
        this.startTimer();
      }
      this.updateComputedValues();
    }
  }

  ngOnDestroy(): void {
    this.stopTimer();
  }

  togglePause(): void {
    this.paused = !this.paused;
    if (this.paused) {
      this.stopTimer();
    } else {
      this.startTimer();
    }
  }

  private startTimer(): void {
    if (this.paused || !this.connected) return;
    this.stopTimer();
    this.ngZone.runOutsideAngular(() => {
      this.timerId = setInterval(() => {
        const t = Date.now() / 260;
        const burst = Math.sin(t) > 0.6 ? Math.abs(Math.sin(t * 5)) * 1.8 : 0;
        this.values = [...this.values.slice(1), Math.max(0.05, 0.9 + Math.sin(t) * 0.4 + burst + Math.random() * 0.25)];
        this.ngZone.run(() => this.updateComputedValues());
      }, 60);
    });
  }

  private stopTimer(): void {
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  private updateComputedValues(): void {
    const signalValues = this.connected ? this.values : this.values.map(() => 0);
    this.thresholdValue = this.connected ? 2.5 : 0;
    this.current = signalValues[signalValues.length - 1];
    this.peak = Math.max(...signalValues);
    this.rms = Math.sqrt(signalValues.reduce((a, v) => a + v * v, 0) / signalValues.length);

    const points = signalValues.map((v, i) => `${(i / (signalValues.length - 1)) * 800},${this.yVal(v)}`).join(' ');
    this.linePoints = points;
    this.polygonPoints = `0,240 ${points} 800,240`;

    const gesture: Gesture = this.current > 1.45 ? 'clench' : 'spread';
    const moving = this.current > 1;
    const placementCentered = this.current > 0.12 && this.current < 3.6;
    this.gestureChange.emit(gesture);
    this.movementChange.emit(this.connected && moving);
    this.placementChange.emit(this.connected && placementCentered);
  }

  yVal(v: number): number {
    return 240 - (v / 4) * 240;
  }
}
