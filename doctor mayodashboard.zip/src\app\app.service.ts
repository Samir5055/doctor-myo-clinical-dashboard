import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { View, DeviceSettings, DEFAULT_DEVICE_SETTINGS, DEVICE_SETTINGS_STORAGE_KEY, Patient } from './models';
import { PATIENTS } from './data';

@Injectable({ providedIn: 'root' })
export class AppService {
  private viewSubject = new BehaviorSubject<View>('overview');
  private menuOpenSubject = new BehaviorSubject<boolean>(false);
  private collapsedSubject = new BehaviorSubject<boolean>(false);
  private patientIdSubject = new BehaviorSubject<string>(PATIENTS[0].id);
  private detailSubject = new BehaviorSubject<boolean>(false);
  private connectedSubject = new BehaviorSubject<boolean>(true);
  private roleSubject = new BehaviorSubject<'doctor' | 'secretary'>('doctor');
  role$ = this.roleSubject.asObservable();
  get role(): 'doctor' | 'secretary' { return this.roleSubject.value; }
  setRole(r: 'doctor' | 'secretary'): void { this.roleSubject.next(r); }

  private patientsSubject = new BehaviorSubject<Patient[]>(PATIENTS);
  patients$ = this.patientsSubject.asObservable();
  get patients(): Patient[] { return this.patientsSubject.value; }

  private darkModeSubject = new BehaviorSubject<boolean>(
    typeof localStorage !== 'undefined' ? localStorage.getItem('myo_dark_mode') === 'true' : false
  );
  darkMode$ = this.darkModeSubject.asObservable();
  get darkMode(): boolean { return this.darkModeSubject.value; }
  setDarkMode(val: boolean): void {
    this.darkModeSubject.next(val);
    try {
      localStorage.setItem('myo_dark_mode', String(val));
      if (typeof document !== 'undefined') {
        if (val && this.role === 'doctor') {
          document.body.classList.add('dark-theme');
        } else {
          document.body.classList.remove('dark-theme');
        }
      }
    } catch {}
  }
  toggleDarkMode(): void {
    this.setDarkMode(!this.darkMode);
  }

  private showPickerSubject = new BehaviorSubject<boolean>(true);
  showPicker$ = this.showPickerSubject.asObservable();
  get showPicker(): boolean { return this.showPickerSubject.value; }
  selectProfile(r: 'doctor' | 'secretary'): void {
    this.roleSubject.next(r);
    this.showPickerSubject.next(false);
    if (typeof document !== 'undefined') {
      if (r === 'doctor' && this.darkMode) {
        document.body.classList.add('dark-theme');
      } else {
        document.body.classList.remove('dark-theme');
      }
    }
  }

  signOut(): void {
    this.showPickerSubject.next(true);
  }
  private secretaryTabSubject = new BehaviorSubject<'appointments' | 'wallet'>('appointments');
  secretaryTab$ = this.secretaryTabSubject.asObservable();
  get secretaryTab(): 'appointments' | 'wallet' { return this.secretaryTabSubject.value; }
  setSecretaryTab(t: 'appointments' | 'wallet'): void { this.secretaryTabSubject.next(t); }
  private deviceSettingsSubject: BehaviorSubject<Record<string, DeviceSettings>>;

  view$ = this.viewSubject.asObservable();
  menuOpen$ = this.menuOpenSubject.asObservable();
  collapsed$ = this.collapsedSubject.asObservable();
  patientId$ = this.patientIdSubject.asObservable();
  detail$ = this.detailSubject.asObservable();
  connected$ = this.connectedSubject.asObservable();
  deviceSettings$;

  constructor() {
    let initialSettings: Record<string, DeviceSettings>;
    try {
      const stored = JSON.parse(localStorage.getItem(DEVICE_SETTINGS_STORAGE_KEY) ?? '{}') as Record<string, Partial<DeviceSettings>>;
      initialSettings = Object.fromEntries(PATIENTS.map(item => [item.id, { ...DEFAULT_DEVICE_SETTINGS, ...stored[item.id] }]));
    } catch {
      initialSettings = Object.fromEntries(PATIENTS.map(item => [item.id, { ...DEFAULT_DEVICE_SETTINGS }]));
    }
    this.deviceSettingsSubject = new BehaviorSubject(initialSettings);
    this.deviceSettings$ = this.deviceSettingsSubject.asObservable();
  }

  get view(): View { return this.viewSubject.value; }
  get menuOpen(): boolean { return this.menuOpenSubject.value; }
  get collapsed(): boolean { return this.collapsedSubject.value; }
  get patientId(): string { return this.patientIdSubject.value; }
  get detail(): boolean { return this.detailSubject.value; }
  get connected(): boolean { return this.connectedSubject.value; }
  get deviceSettings(): Record<string, DeviceSettings> { return this.deviceSettingsSubject.value; }

  setView(v: View): void {
    if (v === 'patients') this.detailSubject.next(false);
    if (v === 'wallet') this.secretaryTabSubject.next('wallet');
    if (v === 'appointments') this.secretaryTabSubject.next('appointments');
    this.viewSubject.next(v);
  }

  openMenu(): void {
    this.menuOpenSubject.next(!this.menuOpen);
  }

  closeMenu(): void { this.menuOpenSubject.next(false); }
  collapse(): void { this.collapsedSubject.next(true); }
  setPatientId(id: string): void { this.patientIdSubject.next(id); }
  setDetail(v: boolean): void { this.detailSubject.next(v); }
  toggleConnected(): void { this.connectedSubject.next(!this.connected); }

  getCurrentPatient(): Patient {
    return this.patients.find(p => p.id === this.patientId) ?? this.patients[0] ?? PATIENTS[0];
  }

  addPatient(p: Patient): void {
    if (!PATIENTS.some(item => item.id === p.id)) {
      PATIENTS.unshift(p);
    }
    this.patientsSubject.next([...PATIENTS]);
    const current = this.deviceSettingsSubject.value;
    if (!current[p.id]) {
      this.deviceSettingsSubject.next({
        ...current,
        [p.id]: { ...DEFAULT_DEVICE_SETTINGS }
      });
    }
  }

  updatePatient(id: string, changes: Partial<Patient>): void {
    const idx = PATIENTS.findIndex(p => p.id === id);
    if (idx !== -1) {
      PATIENTS[idx] = { ...PATIENTS[idx], ...changes };
      this.patientsSubject.next([...PATIENTS]);
    }
  }

  getCurrentDeviceSettings(): DeviceSettings {
    const patient = this.getCurrentPatient();
    return this.deviceSettings[patient.id] ?? DEFAULT_DEVICE_SETTINGS;
  }

  updateDeviceSettings(changes: Partial<DeviceSettings>): void {
    const patient = this.getCurrentPatient();
    const current = this.deviceSettings;
    const updated = {
      ...current,
      [patient.id]: { ...(current[patient.id] ?? DEFAULT_DEVICE_SETTINGS), ...changes },
    };
    this.deviceSettingsSubject.next(updated);
    localStorage.setItem(DEVICE_SETTINGS_STORAGE_KEY, JSON.stringify(updated));
  }
}
