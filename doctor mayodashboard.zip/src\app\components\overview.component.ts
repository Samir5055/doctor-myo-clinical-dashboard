import { Component, Input, Output, EventEmitter } from '@angular/core';
import { View, DeviceSettings } from '../models';
import { APPOINTMENTS } from '../data';

@Component({
  selector: 'app-overview',
  template: `
    <section class="page-heading overview-heading-glass">
      <div>
        <p class="eyebrow">Clinical dashboard</p>
        <h1>Good morning, Dr. Ahmed</h1>
        <p>Here's a concise overview of today's clinical activity.</p>
      </div>
      <div class="overview-header-arm" aria-hidden="true">
        <img src="assets/dashboard-arm.png" alt="" />
      </div>
    </section>
    <div class="metrics-grid three">
      <app-metric-card icon="signal" label="Live signal"
        [value]="connected ? 'Active' : 'Offline'"
        [detail]="connected ? 'View live signal' : 'No active signal'"
        tone="amber" [clickable]="true" (cardClick)="setView.emit('signal')">
      </app-metric-card>
      <app-metric-card icon="target" label="Patients this month"
        [value]="monthCount.toString()" detail="View all patients"
        tone="violet" [clickable]="true" (cardClick)="setView.emit('patients')">
      </app-metric-card>
      <app-metric-card icon="clock" label="Today's appointments"
        value="2" detail="View appointments"
        tone="blue" [clickable]="true" (cardClick)="setView.emit('appointments')">
      </app-metric-card>
    </div>
    <app-safety-warning [settings]="settings" [showReview]="true" (reviewClick)="setView.emit('signal')"></app-safety-warning>
    <div class="overview-illustration overview-illustration-solo" aria-hidden="true">
      <img class="scene-person" src="assets/patient-prosthesis.png" alt="" />
    </div>
  `
})
export class OverviewComponent {
  @Input() connected = true;
  @Input() settings!: DeviceSettings;
  @Output() setView = new EventEmitter<View>();

  get monthCount(): number {
    const ids = new Set(
      APPOINTMENTS
        .filter(a => a.date.includes('Nov') && a.date.includes('2026'))
        .map(a => a.patientId)
    );
    return ids.size;
  }
}
