import { Component, Output, EventEmitter, HostListener, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { PATIENTS, APPOINTMENTS } from '../data';
import { View } from '../models';

export interface SearchResult {
  icon: string;      // emoji
  title: string;
  subtitle: string;
  action: () => void;
}

@Component({
  selector: 'app-page-header',
  template: `
    <header class="topbar">
      <button class="icon-button mobile-menu" (click)="openMenu.emit()" aria-label="Toggle options">
        <app-icon name="menu"></app-icon>
      </button>

      <!-- ── Search & Actions Bar ─────────────────────── -->
      <div class="topbar-search-group">
        <div class="topbar-search-wrap" [class.search-active]="searchOpen">
          <div class="search-box" [class.has-results]="results.length > 0 && searchOpen">
            <span class="search-icon-left">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                   stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              </svg>
            </span>
            <input
              #searchInput
              class="search-input"
              type="text"
              [placeholder]="svc.role === 'doctor' ? 'Search patients, views, appointments…' : 'Search appointments, wallet, patients…'"
              [(ngModel)]="query"
              (input)="onSearch()"
              (focus)="searchOpen = true"
              (keydown.escape)="clearSearch()"
              (keydown.enter)="onEnter()"
              autocomplete="off"
            />
            <button *ngIf="query" class="search-clear" (click)="clearSearch()" aria-label="Clear search">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                   stroke-width="2.5" stroke-linecap="round">
                <path d="m6 6 12 12M18 6 6 18"/>
              </svg>
            </button>
          </div>

          <!-- Results dropdown -->
          <div class="search-dropdown" *ngIf="searchOpen && results.length > 0">
            <div class="search-result-item"
                 *ngFor="let r of results; let i = index"
                 [class.search-result-focused]="i === focusedIndex"
                 (click)="execute(r)"
                 (mouseenter)="focusedIndex = i">
              <span class="search-result-icon">{{r.icon}}</span>
              <div class="search-result-text">
                <strong>{{r.title}}</strong>
                <span>{{r.subtitle}}</span>
              </div>
            </div>
          </div>

          <!-- No results -->
          <div class="search-dropdown search-empty" *ngIf="searchOpen && query.length > 1 && results.length === 0">
            <span>No results for "<strong>{{query}}</strong>"</span>
          </div>
        </div>

        <!-- ── Dark Theme Toggle Button (Next to Search Bar) ── -->
        <button
          *ngIf="svc.role === 'doctor'"
          class="theme-toggle-btn"
          [class.active-dark]="svc.darkMode"
          (click)="svc.toggleDarkMode()"
          [title]="svc.darkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme'"
          aria-label="Toggle dark theme">
          <span class="theme-toggle-icon">
            <svg *ngIf="!svc.darkMode" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
            </svg>
            <svg *ngIf="svc.darkMode" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="5"/>
              <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
            </svg>
          </span>
          <span class="theme-toggle-label">{{ svc.darkMode ? 'Light Theme' : 'Dark Theme' }}</span>
        </button>
      </div>

      <!-- ── Profile pill ─────────────────────────────── -->
      <div class="top-profile">
        <div class="topbar-avatar" [class.topbar-avatar-sec]="svc.role === 'secretary'">
          <img
            [src]="svc.role === 'doctor' ? 'assets/doctor-profile.jpg' : 'assets/secretary-profile.png'"
            [alt]="svc.role === 'doctor' ? 'Dr. Ahmed' : 'Ms. Sara'"
          />
        </div>
        <div class="topbar-profile-text">
          <strong>{{svc.role === 'doctor' ? 'Dr. Ahmed' : 'Ms. Sara'}}</strong>
          <span>{{svc.role === 'doctor' ? 'MYO Device Specialist' : 'Clinic Secretary'}}</span>
        </div>
      </div>
    </header>
  `,
  styles: [`
    /* ── Search wrap & Theme Toggle ─────────── */
    .topbar-search-group {
      display: flex;
      align-items: center;
      gap: 12px;
      flex: 1;
      max-width: 620px;
      margin: 0 20px;
    }
    .topbar-search-wrap {
      position: relative;
      flex: 1;
      margin: 0;
    }
    .theme-toggle-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      height: 40px;
      padding: 0 14px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.65);
      border: 1.5px solid rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(16px);
      color: #1e293b;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      white-space: nowrap;
      flex-shrink: 0;
      user-select: none;
    }
    .theme-toggle-btn:hover {
      background: #ffffff;
      border-color: #3b82f6;
      color: #3b82f6;
      box-shadow: 0 4px 14px rgba(59, 130, 246, 0.2);
      transform: translateY(-1px);
    }
    .theme-toggle-btn.active-dark {
      background: #1e293b;
      border-color: #334155;
      color: #ffffff;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    .theme-toggle-btn.active-dark:hover {
      background: #273549;
      border-color: #3b82f6;
      color: #3b82f6;
      box-shadow: 0 0 14px rgba(59, 130, 246, 0.35);
    }
    .theme-toggle-icon {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .theme-toggle-btn:not(.active-dark) .theme-toggle-icon {
      color: #3b82f6;
    }
    .theme-toggle-btn.active-dark .theme-toggle-icon {
      color: #fbbf24;
    }

    .search-box {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 0 12px;
      height: 40px;
      border-radius: 999px;
      background: rgba(255,255,255,0.55);
      border: 1.5px solid rgba(255,255,255,0.75);
      backdrop-filter: blur(16px);
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.90), 0 2px 10px rgba(0,0,0,0.06);
      transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
    }
    .search-box:focus-within {
      background: rgba(255,255,255,0.80);
      border-color: rgba(56,189,248,0.60);
      box-shadow: inset 0 1px 0 #fff, 0 0 0 3px rgba(56,189,248,0.14), 0 4px 16px rgba(0,0,0,0.08);
    }
    .sec-mode .search-box:focus-within {
      border-color: rgba(194,145,106,0.60);
      box-shadow: inset 0 1px 0 #fff, 0 0 0 3px rgba(194,145,106,0.14), 0 4px 16px rgba(0,0,0,0.08);
    }
    .search-box.has-results {
      border-radius: 18px 18px 0 0;
      border-bottom-color: rgba(0,0,0,0.06);
    }
    .search-icon-left { color: #8fa3b1; display: flex; align-items: center; flex: 0 0 auto; }
    .search-input {
      flex: 1; border: 0; background: transparent; outline: none;
      font: inherit; font-size: 13.5px; color: #162033;
      min-width: 0;
    }
    .search-input::placeholder { color: #9eaebf; }
    .search-clear {
      display: flex; align-items: center; padding: 0;
      border: 0; background: transparent; color: #9eaebf; cursor: pointer;
      flex: 0 0 auto;
    }
    .search-clear:hover { color: #445566; }

    /* ── Dropdown ──────────────────────────────── */
    .search-dropdown {
      position: absolute;
      top: 100%; left: 0; right: 0;
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(24px) saturate(180%);
      border: 1.5px solid rgba(255,255,255,0.80);
      border-top: 1px solid rgba(0,0,0,0.06);
      border-radius: 0 0 20px 20px;
      box-shadow: 0 16px 40px rgba(0,0,0,0.13), 0 2px 8px rgba(0,0,0,0.07);
      overflow: hidden;
      z-index: 200;
      animation: ddSlide .15s cubic-bezier(.34,1.56,.64,1) both;
    }
    @keyframes ddSlide {
      from { opacity: 0; transform: translateY(-6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .search-result-item {
      display: flex; align-items: center; gap: 12px;
      padding: 11px 16px; cursor: pointer;
      border-bottom: 1px solid rgba(0,0,0,0.04);
      transition: background .12s;
    }
    .search-result-item:last-child { border-bottom: 0; }
    .search-result-item:hover,
    .search-result-focused { background: rgba(56,189,248,0.08); }
    .search-result-icon { font-size: 1.3rem; flex: 0 0 auto; }
    .search-result-text { display: flex; flex-direction: column; gap: 1px; min-width: 0; }
    .search-result-text strong { font-size: 13px; color: #162033; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .search-result-text span  { font-size: 11px; color: #6b7a8d; }

    .search-empty {
      padding: 14px 18px;
      font-size: 13px; color: #8fa3b1;
      border-radius: 0 0 20px 20px;
    }

    /* ── Avatar ────────────────────────────────── */
    .topbar-avatar {
      width: 40px; height: 40px; border-radius: 50%;
      overflow: hidden; flex: 0 0 auto;
      border: 2.5px solid #38bdf8;
      box-shadow: 0 0 0 2px rgba(56,189,248,0.25);
      background: #1a2a3a;
    }
    .topbar-avatar-sec {
      border-color: #c2916a;
      box-shadow: 0 0 0 2px rgba(194,145,106,0.25);
      background: #8b4513;
    }
    .topbar-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .topbar-avatar-sec img { object-fit: contain; width: 85%; height: 85%; margin: auto; }
    .topbar-profile-text strong { display: block; font-size: 14px; white-space: nowrap; }
    .topbar-profile-text span { display: block; color: #6b7a8d; font-size: 12px; margin-top: 2px; }

    @media (max-width: 680px) {
      .theme-toggle-label { display: none; }
      .theme-toggle-btn { padding: 0 10px; }
      .topbar-search-group { margin: 0 10px; }
    }
    @media (max-width: 600px) {
      .topbar-search-wrap { max-width: none; }
      .topbar-profile-text { display: none; }
    }
  `]
})
export class PageHeaderComponent implements OnInit {
  @Output() openMenu = new EventEmitter<void>();

  query = '';
  results: SearchResult[] = [];
  searchOpen = false;
  focusedIndex = 0;

  /** All searchable items — built once and filtered on query */
  private allItems: SearchResult[] = [];

  constructor(public svc: AppService) {}

  ngOnInit(): void {
    this.buildIndex();
  }

  private buildIndex(): void {
    // ── Doctor views ───────────────────────────────────────────────
    const doctorViews: SearchResult[] = [
      { icon: '🏠', title: 'Overview',          subtitle: 'Dashboard home',          action: () => this.go('overview') },
      { icon: '📡', title: 'Live Signal',        subtitle: 'Real-time EMG signal',   action: () => this.go('signal') },
      { icon: '👥', title: 'Patients',           subtitle: 'View all patients',       action: () => this.go('patients') },
      { icon: '📅', title: 'Appointments',       subtitle: 'Doctor appointments',     action: () => this.go('appointments') },
    ];

    // ── Secretary views ────────────────────────────────────────────
    const secViews: SearchResult[] = [
      { icon: '📅', title: 'Appointments',    subtitle: 'Manage appointments',     action: () => this.goSec('appointments') },
      { icon: '💰', title: 'Clinic Wallet',   subtitle: 'Revenue & expenses',      action: () => this.goSec('wallet') },
    ];

    // ── Patients ───────────────────────────────────────────────────
    const patientItems: SearchResult[] = PATIENTS.map(p => ({
      icon: '🧑‍⚕️',
      title: p.name,
      subtitle: `Patient · ${p.condition}`,
      action: () => {
        this.svc.setPatientId(p.id);
        this.svc.setDetail(true);
        this.go('patients');
      }
    }));

    // ── Appointments ───────────────────────────────────────────────
    const apptItems: SearchResult[] = APPOINTMENTS.map(a => ({
      icon: '📋',
      title: `${a.patientName} — ${a.type}`,
      subtitle: `${a.date} · ${a.time} · ${a.status}`,
      action: () => this.go('appointments')
    }));

    this.allItems = [...doctorViews, ...secViews, ...patientItems, ...apptItems];
  }

  onSearch(): void {
    const q = this.query.trim().toLowerCase();
    if (q.length < 1) {
      this.results = [];
      return;
    }
    this.results = this.allItems
      .filter(r => r.title.toLowerCase().includes(q) || r.subtitle.toLowerCase().includes(q))
      .slice(0, 8);
    this.focusedIndex = 0;
  }

  onEnter(): void {
    if (this.results[this.focusedIndex]) {
      this.execute(this.results[this.focusedIndex]);
    }
  }

  execute(r: SearchResult): void {
    r.action();
    this.clearSearch();
  }

  clearSearch(): void {
    this.query = '';
    this.results = [];
    this.searchOpen = false;
  }

  private go(view: View): void {
    if (this.svc.role !== 'doctor') this.svc.setRole('doctor');
    this.svc.setView(view);
  }

  private goSec(tab: 'appointments' | 'wallet'): void {
    if (this.svc.role !== 'secretary') this.svc.setRole('secretary');
    this.svc.setSecretaryTab(tab);
  }

  @HostListener('document:click', ['$event'])
  onDocClick(e: MouseEvent): void {
    const target = e.target as HTMLElement;
    if (!target.closest('.topbar-search-wrap')) {
      this.searchOpen = false;
    }
  }
}
