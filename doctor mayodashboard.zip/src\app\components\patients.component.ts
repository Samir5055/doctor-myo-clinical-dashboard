import { Component, Output, EventEmitter } from '@angular/core';
import { Patient, healthClass } from '../models';
import { APPOINTMENTS, PATIENTS } from '../data';
import { AppService } from '../app.service';

@Component({
  selector: 'app-patients',
  template: `
    <section class="page-heading">
      <div>
        <p class="eyebrow">Patient directory</p>
        <h1>Patients</h1>
        <p>Select a patient to review their status, device and recovery progress.</p>
      </div>
      <input class="select-control patient-search"
             placeholder="Search patients"
             [(ngModel)]="query"
             aria-label="Search patients" />
    </section>

    <!-- ── Patient Visit Analytics & Chart Panel ────────────────── -->
    <section class="panel pt-analytics-panel">
      <!-- Header -->
      <div class="pt-analytics-header">
        <div class="pt-analytics-title-wrap">
          <div class="pt-analytics-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="20" x2="18" y2="10"/>
              <line x1="12" y1="20" x2="12" y2="4"/>
              <line x1="6" y1="20" x2="6" y2="14"/>
            </svg>
          </div>
          <div>
            <h2 class="pt-analytics-title">Patient Visit Statistics & Chart</h2>
            <p class="pt-analytics-subtitle">Comparative patient visit volume and reach across time periods</p>
          </div>
        </div>
        <div class="pt-analytics-pills">
          <span class="pt-pill pt-pill-blue">Today: <strong>{{todayCount}}</strong></span>
          <span class="pt-pill pt-pill-indigo">Week: <strong>{{weekCount}}</strong></span>
          <span class="pt-pill pt-pill-emerald">Month: <strong>{{monthCount}}</strong></span>
          <span class="pt-pill pt-pill-amber">Year: <strong>{{yearCount}}</strong></span>
        </div>
      </div>

      <!-- ① Stat Cards Grid -->
      <div class="pt-stats-grid">
        <!-- Today -->
        <div class="pt-stat-box pt-stat-blue">
          <div class="pt-stat-top">
            <span class="pt-stat-tag">Today</span>
            <div class="pt-stat-badge-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                <line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/>
                <line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
            </div>
          </div>
          <strong class="pt-stat-value">{{todayCount}}</strong>
          <span class="pt-stat-subtext">patients visited</span>
          <div class="pt-stat-bar-track">
            <div class="pt-stat-bar-fill pt-fill-blue" [style.width.%]="barPct(todayCount)"></div>
          </div>
        </div>

        <!-- This Week -->
        <div class="pt-stat-box pt-stat-indigo">
          <div class="pt-stat-top">
            <span class="pt-stat-tag">This Week</span>
            <div class="pt-stat-badge-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
              </svg>
            </div>
          </div>
          <strong class="pt-stat-value">{{weekCount}}</strong>
          <span class="pt-stat-subtext">patients visited</span>
          <div class="pt-stat-bar-track">
            <div class="pt-stat-bar-fill pt-fill-indigo" [style.width.%]="barPct(weekCount)"></div>
          </div>
        </div>

        <!-- This Month -->
        <div class="pt-stat-box pt-stat-emerald">
          <div class="pt-stat-top">
            <span class="pt-stat-tag">This Month</span>
            <div class="pt-stat-badge-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
            </div>
          </div>
          <strong class="pt-stat-value">{{monthCount}}</strong>
          <span class="pt-stat-subtext">unique patients</span>
          <div class="pt-stat-bar-track">
            <div class="pt-stat-bar-fill pt-fill-emerald" [style.width.%]="barPct(monthCount)"></div>
          </div>
        </div>

        <!-- This Year -->
        <div class="pt-stat-box pt-stat-amber">
          <div class="pt-stat-top">
            <span class="pt-stat-tag">This Year</span>
            <div class="pt-stat-badge-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="20" x2="18" y2="10"/>
                <line x1="12" y1="20" x2="12" y2="4"/>
                <line x1="6" y1="20" x2="6" y2="14"/>
              </svg>
            </div>
          </div>
          <strong class="pt-stat-value">{{yearCount}}</strong>
          <span class="pt-stat-subtext">total patients</span>
          <div class="pt-stat-bar-track">
            <div class="pt-stat-bar-fill pt-fill-amber" style="width:100%"></div>
          </div>
        </div>
      </div>

      <!-- ② Visual SVG Bar Chart -->
      <div class="pt-chart-container">
        <div class="pt-chart-title-row">
          <span class="pt-chart-heading">📊 Patient Volume Comparison</span>
          <span class="pt-chart-legend">
            <span class="pt-dot-legend" style="background:#0284c7"></span> Today ({{todayCount}})
            <span class="pt-dot-legend" style="background:#4f46e5;margin-left:12px"></span> Week ({{weekCount}})
            <span class="pt-dot-legend" style="background:#059669;margin-left:12px"></span> Month ({{monthCount}})
            <span class="pt-dot-legend" style="background:#d97706;margin-left:12px"></span> Year ({{yearCount}})
          </span>
        </div>

        <div class="pt-chart-wrap">
          <svg viewBox="0 0 680 230" preserveAspectRatio="xMidYMid meet" class="pt-svg-chart">
            <defs>
              <linearGradient id="barGradToday" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#38bdf8"/>
                <stop offset="100%" stop-color="#0284c7"/>
              </linearGradient>
              <linearGradient id="barGradWeek" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#818cf8"/>
                <stop offset="100%" stop-color="#4f46e5"/>
              </linearGradient>
              <linearGradient id="barGradMonth" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#34d399"/>
                <stop offset="100%" stop-color="#059669"/>
              </linearGradient>
              <linearGradient id="barGradYear" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#fbbf24"/>
                <stop offset="100%" stop-color="#d97706"/>
              </linearGradient>
              <filter id="badgeShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" flood-opacity="0.12"/>
              </filter>
            </defs>

            <!-- Horizontal grid lines & Y labels -->
            <line x1="45" y1="35" x2="655" y2="35" class="pt-grid-line" stroke="#e2e8f0" stroke-dasharray="4 4"/>
            <text x="36" y="39" text-anchor="end" font-size="11" font-weight="600" class="pt-chart-text" fill="#64748b">20</text>

            <line x1="45" y1="72" x2="655" y2="72" class="pt-grid-line" stroke="#e2e8f0" stroke-dasharray="4 4"/>
            <text x="36" y="76" text-anchor="end" font-size="11" font-weight="600" class="pt-chart-text" fill="#64748b">15</text>

            <line x1="45" y1="110" x2="655" y2="110" class="pt-grid-line" stroke="#e2e8f0" stroke-dasharray="4 4"/>
            <text x="36" y="114" text-anchor="end" font-size="11" font-weight="600" class="pt-chart-text" fill="#64748b">10</text>

            <line x1="45" y1="147" x2="655" y2="147" class="pt-grid-line" stroke="#e2e8f0" stroke-dasharray="4 4"/>
            <text x="36" y="151" text-anchor="end" font-size="11" font-weight="600" class="pt-chart-text" fill="#64748b">5</text>

            <!-- Baseline 0 -->
            <line x1="45" y1="185" x2="655" y2="185" class="pt-baseline" stroke="#cbd5e1" stroke-width="1.5"/>
            <text x="36" y="189" text-anchor="end" font-size="11" font-weight="600" class="pt-chart-text" fill="#64748b">0</text>

            <!-- Trend curve connecting bar tops -->
            <path [attr.d]="chartTrendPath" class="pt-trend-line" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="5 5" opacity="0.6"/>

            <!-- Bars -->
            <g *ngFor="let b of chartBars">
              <!-- Background track for the bar -->
              <rect [attr.x]="b.x" y="35" width="56" height="150" rx="10" class="pt-bar-track-bg" fill="#f1f5f9" opacity="0.6"/>

              <!-- Colored bar with gradient -->
              <rect [attr.x]="b.x" [attr.y]="b.y" width="56" [attr.height]="b.height" rx="10"
                    [attr.fill]="'url(#' + b.gradientId + ')'"
                    style="transition: all 0.5s cubic-bezier(0.4,0,0.2,1);"/>

              <!-- Value Badge Pill on top of bar -->
              <g [attr.transform]="'translate(' + (b.x + 28) + ',' + (b.y - 14) + ')'" filter="url(#badgeShadow)">
                <rect x="-22" y="-12" width="44" height="22" rx="11" [attr.fill]="b.badgeBg" [attr.stroke]="b.color" stroke-width="1.5"/>
                <text x="0" y="3" text-anchor="middle" font-size="12" font-weight="800" [attr.fill]="b.badgeColor">{{b.count}}</text>
              </g>

              <!-- X-axis Labels below baseline -->
              <text [attr.x]="b.x + 28" y="204" text-anchor="middle" font-size="12" font-weight="700" class="pt-xaxis-label" fill="#111827">
                {{b.label}}
              </text>
              <text [attr.x]="b.x + 28" y="219" text-anchor="middle" font-size="10" font-weight="500" class="pt-xaxis-sub" fill="#64748b">
                {{b.sub}}
              </text>
            </g>
          </svg>
        </div>
      </div>
    </section>

    <!-- ── Patient Grid ──────────────────────────────── -->
    <div class="patient-grid">
      <button *ngFor="let p of filteredPatients"
              class="patient-card"
              (click)="selectPatient.emit(p.id)">
        <div class="patient-card-top">
          <div class="patient-avatar">{{p.initials}}</div>
          <div>
            <strong>{{p.name}}</strong>
            <small>{{p.age}} yrs &middot; {{p.condition}}</small>
          </div>
        </div>
        <div class="patient-card-meta">
          <span class="health-pill" [ngClass]="getHealthClass(p.health)">{{p.health}}</span>
          <span>Recovery <b>{{p.recovery}}%</b></span>
        </div>
        <div class="progress"><i [style.width.%]="p.recovery"></i></div>
        <small class="patient-last">Last session: {{p.lastSession}}</small>
      </button>
      <p class="empty-state" *ngIf="filteredPatients.length === 0">No patients match your search.</p>
    </div>
  `,
  styles: [`
    /* ══════════════════════════════════════════════════════
       ANALYTICS & CHART PANEL
    ══════════════════════════════════════════════════════ */
    .pt-analytics-panel {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 20px;
      padding: 24px;
      margin-bottom: 28px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    }

    .pt-analytics-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 20px;
    }

    .pt-analytics-title-wrap {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .pt-analytics-icon {
      width: 44px;
      height: 44px;
      background: rgba(2, 132, 199, 0.1);
      border: 1px solid rgba(2, 132, 199, 0.2);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #0284c7;
    }

    .pt-analytics-title {
      font-size: 1.25rem;
      font-weight: 800;
      color: #111827;
      margin: 0;
    }

    .pt-analytics-subtitle {
      font-size: 0.8rem;
      color: #64748b;
      margin: 2px 0 0;
    }

    .pt-analytics-pills {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .pt-pill {
      font-size: 0.75rem;
      padding: 5px 12px;
      border-radius: 99px;
      font-weight: 600;
    }
    .pt-pill-blue    { background: #e0f2fe; color: #000000 !important; border: 1px solid #bae6fd; font-weight: 700; }
    .pt-pill-indigo  { background: #e0e7ff; color: #000000 !important; border: 1px solid #c7d2fe; font-weight: 700; }
    .pt-pill-emerald { background: #d1fae5; color: #000000 !important; border: 1px solid #a7f3d0; font-weight: 700; }
    .pt-pill-amber   { background: #fef3c7; color: #000000 !important; border: 1px solid #fde68a; font-weight: 700; }
    .pt-pill strong  { color: #000000 !important; }

    /* Stats Grid */
    .pt-stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 14px;
      margin-bottom: 20px;
    }
    @media (max-width: 860px) {
      .pt-stats-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 480px) {
      .pt-stats-grid { grid-template-columns: 1fr; }
    }

    .pt-stat-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 14px;
      padding: 16px 18px;
      display: flex;
      flex-direction: column;
      gap: 4px;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .pt-stat-box:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }
    .pt-stat-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .pt-stat-tag {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: #111827;
    }
    .pt-stat-badge-icon {
      width: 28px;
      height: 28px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .pt-stat-blue .pt-stat-badge-icon    { background: #e0f2fe; color: #0284c7; }
    .pt-stat-indigo .pt-stat-badge-icon  { background: #e0e7ff; color: #4f46e5; }
    .pt-stat-emerald .pt-stat-badge-icon { background: #d1fae5; color: #059669; }
    .pt-stat-amber .pt-stat-badge-icon   { background: #fef3c7; color: #d97706; }

    .pt-stat-value {
      font-size: 2rem;
      font-weight: 900;
      line-height: 1.1;
      color: #111827;
      margin-top: 2px;
    }
    .pt-stat-subtext {
      font-size: 0.72rem;
      font-weight: 700;
      color: #000000;
    }
    .pt-stat-bar-track {
      height: 4px;
      background: #e2e8f0;
      border-radius: 99px;
      overflow: hidden;
      margin-top: 8px;
    }
    .pt-stat-bar-fill {
      height: 100%;
      border-radius: 99px;
      transition: width 0.4s ease;
    }
    .pt-fill-blue    { background: linear-gradient(90deg, #38bdf8, #0284c7); }
    .pt-fill-indigo  { background: linear-gradient(90deg, #818cf8, #4f46e5); }
    .pt-fill-emerald { background: linear-gradient(90deg, #34d399, #059669); }
    .pt-fill-amber   { background: linear-gradient(90deg, #fbbf24, #d97706); }

    /* Chart Container */
    .pt-chart-container {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 18px 20px 10px;
    }

    .pt-chart-title-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 12px;
    }

    .pt-chart-heading {
      font-size: 0.85rem;
      font-weight: 700;
      color: #111827;
    }

    .pt-chart-legend {
      font-size: 0.72rem;
      font-weight: 600;
      color: #64748b;
      display: flex;
      align-items: center;
    }

    .pt-dot-legend {
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      margin-right: 4px;
    }

    .pt-chart-wrap {
      width: 100%;
      overflow-x: auto;
    }

    .pt-svg-chart {
      width: 100%;
      height: auto;
      max-height: 250px;
      display: block;
    }


    /* ══════════════════════════════════════════════════════
       DARK THEME FOR PATIENT VISIT STATS & CHART
    ══════════════════════════════════════════════════════ */
    :host-context(.dark-theme) .pt-analytics-panel {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 24px rgba(0,0,0,0.4) !important;
    }
    :host-context(.dark-theme) .pt-analytics-icon {
      background: rgba(59, 130, 246, 0.2) !important;
      border: 1px solid rgba(59, 130, 246, 0.4) !important;
      color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .pt-analytics-title {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-analytics-subtitle {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .pt-pill {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-pill-blue {
      background: rgba(59, 130, 246, 0.25) !important;
      border: 1px solid rgba(59, 130, 246, 0.5) !important;
    }
    :host-context(.dark-theme) .pt-pill-indigo {
      background: rgba(99, 102, 241, 0.25) !important;
      border: 1px solid rgba(99, 102, 241, 0.5) !important;
    }
    :host-context(.dark-theme) .pt-pill-emerald {
      background: rgba(16, 185, 129, 0.25) !important;
      border: 1px solid rgba(16, 185, 129, 0.5) !important;
    }
    :host-context(.dark-theme) .pt-pill-amber {
      background: rgba(245, 158, 11, 0.25) !important;
      border: 1px solid rgba(245, 158, 11, 0.5) !important;
    }
    :host-context(.dark-theme) .pt-stat-box {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3) !important;
    }
    :host-context(.dark-theme) .pt-stat-box:hover {
      border-color: #3B82F6 !important;
      box-shadow: 0 4px 16px rgba(59, 130, 246, 0.25) !important;
      transform: translateY(-2px);
    }
    :host-context(.dark-theme) .pt-stat-tag,
    :host-context(.dark-theme) .pt-stat-value,
    :host-context(.dark-theme) .pt-stat-subtext {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-stat-subtext {
      opacity: 0.85;
    }
    :host-context(.dark-theme) .pt-stat-bar-track {
      background: #1E293B !important;
      border: 1px solid rgba(255,255,255,0.06);
    }
    :host-context(.dark-theme) .pt-stat-blue .pt-stat-badge-icon {
      background: rgba(59, 130, 246, 0.25) !important;
      color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .pt-stat-indigo .pt-stat-badge-icon {
      background: rgba(99, 102, 241, 0.25) !important;
      color: #818CF8 !important;
    }
    :host-context(.dark-theme) .pt-stat-emerald .pt-stat-badge-icon {
      background: rgba(16, 185, 129, 0.25) !important;
      color: #34D399 !important;
    }
    :host-context(.dark-theme) .pt-stat-amber .pt-stat-badge-icon {
      background: rgba(245, 158, 11, 0.25) !important;
      color: #FBBF24 !important;
    }
    :host-context(.dark-theme) .pt-chart-container {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.05) !important;
    }
    :host-context(.dark-theme) .pt-chart-heading,
    :host-context(.dark-theme) .pt-chart-legend {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-grid-line {
      stroke: #334155 !important;
    }
    :host-context(.dark-theme) .pt-chart-text {
      fill: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-baseline {
      stroke: #475569 !important;
    }
    :host-context(.dark-theme) .pt-trend-line {
      stroke: #64748B !important;
    }
    :host-context(.dark-theme) .pt-bar-track-bg {
      fill: #1E293B !important;
      opacity: 0.6 !important;
    }
    :host-context(.dark-theme) .pt-xaxis-label {
      fill: #FFFFFF !important;
    }
    :host-context(.dark-theme) .pt-xaxis-sub {
      fill: #FFFFFF !important;
      opacity: 0.85;
    }
  `]
})
export class PatientsComponent {
  @Output() selectPatient = new EventEmitter<string>();

  query = '';
  constructor(public svc: AppService) {}

  get patients(): Patient[] {
    return this.svc?.patients ?? PATIENTS;
  }
  private appointments = APPOINTMENTS;

  get filteredPatients(): Patient[] {
    return this.patients.filter(p => p.name.toLowerCase().includes(this.query.toLowerCase()));
  }

  getHealthClass(health: string): string {
    return healthClass(health as any);
  }

  barPct(val: number): number {
    const max = this.yearCount || 20;
    return Math.min(100, Math.round((val / max) * 100));
  }

  get todayCount(): number {
    const ids = new Set(
      this.appointments
        .filter(a => a.date.includes('Nov 20') && a.date.includes('2026'))
        .map(a => a.patientId)
    );
    return ids.size;
  }

  get weekCount(): number {
    const ids = new Set(
      this.appointments
        .filter(a => {
          const d = a.date;
          return d.includes('2026') && d.includes('Nov') && (
            d.includes('Nov 17') || d.includes('Nov 18') ||
            d.includes('Nov 19') || d.includes('Nov 20')
          );
        })
        .map(a => a.patientId)
    );
    return ids.size;
  }

  get monthCount(): number {
    const ids = new Set(
      this.appointments
        .filter(a => a.date.includes('Nov') && a.date.includes('2026'))
        .map(a => a.patientId)
    );
    return ids.size;
  }

  get yearCount(): number {
    const ids = new Set(
      this.appointments
        .filter(a => a.date.includes('2026'))
        .map(a => a.patientId)
    );
    return ids.size;
  }

  get chartBars() {
    const max = Math.max(20, this.yearCount, this.monthCount, this.weekCount, this.todayCount);
    const baseHeight = 150;
    const baseY = 185;
    const isDark = !!this.svc?.darkMode;

    return [
      {
        label: 'Today',
        sub: 'patients visited',
        count: this.todayCount,
        height: Math.round((this.todayCount / max) * baseHeight),
        y: Math.round(baseY - (this.todayCount / max) * baseHeight),
        x: 82,
        gradientId: 'barGradToday',
        color: '#0284c7',
        badgeBg: isDark ? '#1e293b' : '#e0f2fe',
        badgeColor: isDark ? '#ffffff' : '#000000'
      },
      {
        label: 'This Week',
        sub: 'patients visited',
        count: this.weekCount,
        height: Math.round((this.weekCount / max) * baseHeight),
        y: Math.round(baseY - (this.weekCount / max) * baseHeight),
        x: 232,
        gradientId: 'barGradWeek',
        color: '#4f46e5',
        badgeBg: isDark ? '#1e293b' : '#e0e7ff',
        badgeColor: isDark ? '#ffffff' : '#000000'
      },
      {
        label: 'This Month',
        sub: 'unique patients',
        count: this.monthCount,
        height: Math.round((this.monthCount / max) * baseHeight),
        y: Math.round(baseY - (this.monthCount / max) * baseHeight),
        x: 382,
        gradientId: 'barGradMonth',
        color: '#059669',
        badgeBg: isDark ? '#1e293b' : '#d1fae5',
        badgeColor: isDark ? '#ffffff' : '#000000'
      },
      {
        label: 'This Year',
        sub: 'total patients',
        count: this.yearCount,
        height: Math.round((this.yearCount / max) * baseHeight),
        y: Math.round(baseY - (this.yearCount / max) * baseHeight),
        x: 532,
        gradientId: 'barGradYear',
        color: '#d97706',
        badgeBg: isDark ? '#1e293b' : '#fef3c7',
        badgeColor: isDark ? '#ffffff' : '#000000'
      }
    ];
  }

  get chartTrendPath(): string {
    const bars = this.chartBars;
    const p0 = { x: bars[0].x + 28, y: bars[0].y };
    const p1 = { x: bars[1].x + 28, y: bars[1].y };
    const p2 = { x: bars[2].x + 28, y: bars[2].y };
    const p3 = { x: bars[3].x + 28, y: bars[3].y };

    return `M ${p0.x} ${p0.y} C ${(p0.x + p1.x)/2} ${p0.y}, ${(p0.x + p1.x)/2} ${p1.y}, ${p1.x} ${p1.y} ` +
           `C ${(p1.x + p2.x)/2} ${p1.y}, ${(p1.x + p2.x)/2} ${p2.y}, ${p2.x} ${p2.y} ` +
           `L ${p3.x} ${p3.y}`;
  }
}
