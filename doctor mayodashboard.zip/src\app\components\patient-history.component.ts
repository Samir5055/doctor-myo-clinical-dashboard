import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Patient } from '../models';

@Component({
  selector: 'app-patient-history',
  template: `
    <section class="page-heading">
      <div>
        <button class="text-button back-link" (click)="back.emit()">
          <span style="transform: rotate(180deg); display: flex"><app-icon name="arrow" [size]="15"></app-icon></span>Back to patient
        </button>
        <p class="eyebrow">Patient history</p>
        <h1>{{patient.name}}</h1>
        <p>{{patient.age}} years · {{patient.condition}}</p>
      </div>
      <span class="health-pill large" [ngClass]="healthClass">{{patient.health}}</span>
    </section>

    <!-- MYO Arm Wearing Time -->
    <section class="panel" style="margin-bottom: 1.5rem;">
      <div class="panel-header">
        <div class="metric-icon blue"><app-icon name="clock"></app-icon></div>
        <div><h2>MYO Arm Wearing Time</h2><p>Daily usage and total wearing history</p></div>
      </div>
      <div class="metrics-grid" style="margin-top:1rem;">
        <div class="metric-card-inline">
          <strong>{{patient.wearingHoursPerDay}} hrs</strong>
          <span>Average per day</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.totalWearingDays}} days</strong>
          <span>Total wearing days</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.streak}} days</strong>
          <span>Current streak</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.minutes}} min</strong>
          <span>Last session duration</span>
        </div>
      </div>
      <div class="progress-block" style="margin-top:1.2rem;">
        <div class="range-label">
          <label>Daily goal progress (target: 8 hrs)</label>
          <strong>{{wearingPercent}}%</strong>
        </div>
        <div class="progress"><i [style.width.%]="wearingPercent"></i></div>
      </div>
    </section>

    <!-- Muscle Health -->
    <section class="panel" style="margin-bottom: 1.5rem;">
      <div class="panel-header">
        <div class="metric-icon violet"><app-icon name="activity"></app-icon></div>
        <div><h2>Muscle Health</h2><p>Current muscle condition and strength indicators</p></div>
      </div>
      <div class="metrics-grid" style="margin-top:1rem;">
        <div class="metric-card-inline">
          <strong>{{patient.muscleHealth}}%</strong>
          <span>Muscle health score</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.muscleRecoveryRate}}</strong>
          <span>Recovery rate</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.accuracy}}%</strong>
          <span>Signal accuracy</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.signal}}</strong>
          <span>Signal quality</span>
        </div>
      </div>
      <div class="progress-block" style="margin-top:1.2rem;">
        <div class="range-label">
          <label>Muscle health score</label>
          <strong [class.over-limit]="patient.muscleHealth < 60">{{patient.muscleHealth}}%</strong>
        </div>
        <div class="progress"><i [style.width.%]="patient.muscleHealth"></i></div>
      </div>
    </section>

    <!-- Muscle Recovery -->
    <section class="panel" style="margin-bottom: 1.5rem;">
      <div class="panel-header">
        <div class="metric-icon mint"><app-icon name="trend"></app-icon></div>
        <div><h2>Muscle Recovery</h2><p>Overall recovery progress and trajectory</p></div>
      </div>
      <div class="metrics-grid" style="margin-top:1rem;">
        <div class="metric-card-inline">
          <strong>{{patient.recovery}}%</strong>
          <span>Recovery score</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.muscleRecoveryRate}}</strong>
          <span>Recovery pace</span>
        </div>
        <div class="metric-card-inline">
          <strong>{{patient.health}}</strong>
          <span>Overall health status</span>
        </div>
      </div>
      <div class="progress-block" style="margin-top:1.2rem;">
        <div class="range-label">
          <label>Recovery progress</label>
          <strong>{{patient.recovery}}%</strong>
        </div>
        <div class="progress"><i [style.width.%]="patient.recovery"></i></div>
      </div>
    </section>

    <!-- Training Plan -->
    <section class="panel" style="margin-bottom: 1.5rem;">
      <div class="panel-header">
        <div class="metric-icon amber"><app-icon name="target"></app-icon></div>
        <div><h2>Recommended Training</h2><p>Current exercise plan for this patient</p></div>
      </div>
      <ul class="training-list" style="margin-top:1rem; padding:0; list-style:none; display:flex; flex-direction:column; gap:0.6rem;">
        <li *ngFor="let item of patient.trainingPlan; let i = index" class="training-item">
          <span class="training-num">{{i + 1}}</span>
          <span>{{item}}</span>
        </li>
      </ul>
    </section>

    <!-- Session History -->
    <section class="panel">
      <div class="panel-header">
        <div><h2>Session History</h2><p>Past training records</p></div>
      </div>
      <div class="status-list" style="margin-top:1rem; display:flex; flex-direction:column; gap:0.8rem;">
        <div *ngFor="let s of patient.sessionHistory" class="session-record">
          <div class="session-record-header">
            <strong>{{s.date}}</strong>
            <span class="health-pill neutral">{{s.duration}} min · {{s.accuracy}}% accuracy</span>
          </div>
          <p style="margin:0.3rem 0 0; color: var(--muted); font-size:0.85rem;">{{s.notes}}</p>
        </div>
      </div>
    </section>
  `
})
export class PatientHistoryComponent {
  @Input() patient!: Patient;
  @Output() back = new EventEmitter<void>();

  get healthClass(): string {
    return this.patient.health === 'Needs attention' ? 'warn' : this.patient.health === 'Improving' ? 'good' : 'neutral';
  }

  get wearingPercent(): number {
    return Math.min(100, Math.round((this.patient.wearingHoursPerDay / 8) * 100));
  }
}
