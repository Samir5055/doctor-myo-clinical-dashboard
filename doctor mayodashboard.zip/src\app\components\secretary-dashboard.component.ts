﻿import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Appointment, Revenue, Expense, Patient, Health } from '../models';
import { APPOINTMENTS, REVENUES, EXPENSES, PATIENTS } from '../data';
import { AppService } from '../app.service';

@Component({
  selector: 'app-secretary-dashboard',
  template: `
    <!-- Hero Header -->
    <section class="sec-heading">
      <div>
        <p class="eyebrow" style="color:#c2916a;">Secretary Portal</p>
        <h1 style="color:#3b1f0e;">Good morning, Sara</h1>
        <p style="color:#7a4f35;">Manage appointments, patient fees, and clinic wallet.</p>
      </div>
      <div class="sec-summary-row">
        <div class="sec-kpi">
          <strong style="color:#3b1f0e;">{{todayAppointments.length}}</strong>
          <span>Today's appts</span>
        </div>
        <div class="sec-kpi">
          <strong style="color:#3b1f0e;">{{monthPatients}}</strong>
          <span>Patients this month</span>
        </div>
        <div class="sec-kpi">
          <strong style="color:#2d6a4f;">L.E. {{totalIncome}}</strong>
          <span>Total Income</span>
        </div>
        <div class="sec-kpi">
          <strong style="color:#b86a0c;">L.E. {{totalExpenses}}</strong>
          <span>Total Expenses</span>
        </div>
      </div>
    </section>

    <!-- Secretary Options Tabs: Appointments & Clinic Wallet -->
    <div class="sec-tabs">
      <button *ngFor="let t of tabs"
              class="sec-tab"
              [class.active]="activeTab === t.id"
              (click)="selectTab(t.id)">
        <app-icon [name]="t.icon" [size]="16" style="margin-right:6px; vertical-align:middle;"></app-icon>
        {{t.label}}
      </button>
    </div>

    <!-- ========================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================
         1. APPOINTMENTS TAB
         ======================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================== -->
    <ng-container *ngIf="activeTab === 'appointments'">
      <section class="sec-panel">
        <div class="sec-panel-header">
          <div>
            <h2>Patient Appointment & Registration</h2>
            <p>Schedule appointments for existing patients or register new patients directly into the clinic directory</p>
          </div>
          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="sec-primary-btn" (click)="toggleRegisterPatientForm()" style="background:#2d6a4f; border-color:#2d6a4f;">
              {{showRegisterPatientForm ? '✕ Close Form' : '➕ Register New Patient'}}
            </button>
            <button class="sec-primary-btn" (click)="toggleAddForm()">
              {{showAddForm ? '✕ Close Form' : '+ New Appointment'}}
            </button>
          </div>
        </div>

        <!-- Dedicated Register New Patient Form -->
        <div class="sec-form" *ngIf="showRegisterPatientForm" style="background: rgba(240, 253, 244, 0.98); border: 2px solid #86efac; border-radius: 16px; padding: 24px; margin-bottom: 24px;">
          <div class="form-header-bar" style="margin-bottom: 18px;">
            <div>
              <h3 class="sec-form-title" style="margin:0; color:#14532d; font-size:1.15rem;">➕ Register New Patient</h3>
              <p style="margin:4px 0 0; font-size:0.8rem; color:#166534;">
                This patient will be added directly to the Doctor's Patient Directory for status tracking, signal monitoring, and muscle health analysis.
              </p>
            </div>
          </div>

          <div *ngIf="registerSuccessMsg" style="background:#dcfce7; border:1px solid #86efac; color:#166534; padding:12px 16px; border-radius:10px; font-weight:700; font-size:0.88rem; margin-bottom:16px;">
            {{registerSuccessMsg}}
          </div>

          <div class="sec-form-grid">
            <label class="sec-label">
              <span>Full Name *</span>
              <input class="sec-input" [(ngModel)]="directPatient.name" placeholder="e.g. Tamer Hosny" />
            </label>
            <label class="sec-label">
              <span>Age</span>
              <input class="sec-input" type="number" [(ngModel)]="directPatient.age" placeholder="e.g. 42" />
            </label>
            <label class="sec-label" style="grid-column: 1 / -1;">
              <span>Medical Condition / Amputation / Prosthesis Need *</span>
              <input class="sec-input" [(ngModel)]="directPatient.condition" placeholder="e.g. Right forearm amputation" />
            </label>
            <label class="sec-label">
              <span>Initial Clinical State</span>
              <select class="sec-input" [(ngModel)]="directPatient.health">
                <option value="Stable">🟡 Stable</option>
                <option value="Improving">🟢 Improving</option>
                <option value="Needs attention">🔴 Needs attention</option>
              </select>
            </label>
            <label class="sec-label">
              <span>Initial Wearing Hours (per day)</span>
              <input class="sec-input" type="number" step="0.5" min="1" max="14" [(ngModel)]="directPatient.wearingHoursPerDay" placeholder="e.g. 6" />
            </label>
            <label class="sec-label">
              <span>Initial Muscle Health Score (0-100)</span>
              <input class="sec-input" type="number" min="0" max="100" [(ngModel)]="directPatient.muscleHealth" placeholder="e.g. 70" />
            </label>
            <label class="sec-label">
              <span>Initial Strength (0-100)</span>
              <input class="sec-input" type="number" min="0" max="100" [(ngModel)]="directPatient.muscleStrength" placeholder="e.g. 65" />
            </label>
            <label class="sec-label">
              <span>Initial Endurance (0-100)</span>
              <input class="sec-input" type="number" min="0" max="100" [(ngModel)]="directPatient.muscleEndurance" placeholder="e.g. 60" />
            </label>
            <label class="sec-label">
              <span>Initial Flexibility (0-100)</span>
              <input class="sec-input" type="number" min="0" max="100" [(ngModel)]="directPatient.muscleFlexibility" placeholder="e.g. 65" />
            </label>
            <label class="sec-label" style="grid-column: 1 / -1;">
              <span>Notes / Clinical Background</span>
              <textarea class="sec-input" [(ngModel)]="directPatient.notes" rows="2" placeholder="e.g. Referred for MYOWARE 2.0 myoelectric prosthesis assessment."></textarea>
            </label>
          </div>

          <div class="sec-form-actions" style="margin-top:18px; display:flex; gap:12px; justify-content:flex-end;">
            <button type="button" class="sec-cancel-btn" (click)="toggleRegisterPatientForm()">Cancel</button>
            <button type="button" class="sec-submit-btn" style="background:#16a34a; border-color:#16a34a; color:#fff; font-weight:700; padding:10px 20px; border-radius:10px;" (click)="submitDirectPatient()">
              ✅ Register & Add to Doctor's Directory
            </button>
          </div>
        </div>

        <!-- Professional Add Appointment Form -->
        <div class="sec-form" *ngIf="showAddForm" style="background: rgba(255, 248, 242, 0.98);">
          <div class="form-header-bar">
            <h3 class="sec-form-title" style="margin:0;">Schedule Patient Appointment</h3>
            <!-- Segmented Toggle: Existing Patient vs New Patient -->
            <div class="patient-mode-toggle">
              <button type="button"
                      class="mode-toggle-btn"
                      [class.active]="patientMode === 'existing'"
                      (click)="setPatientMode('existing')">
                <span class="mode-icon">👤</span> Existing Patient
              </button>
              <button type="button"
                      class="mode-toggle-btn"
                      [class.active]="patientMode === 'new'"
                      (click)="setPatientMode('new')">
                <span class="mode-icon">✨</span> New Patient
              </button>
            </div>
          </div>

          <!-- OPTION A: Existing Registered Patient Selection -->
          <div class="patient-mode-section" *ngIf="patientMode === 'existing'">
            <div class="sec-form-grid" style="grid-template-columns: 1fr;">
              <label class="sec-label">
                <span>Select from Registered Patients ({{patientList.length}} available)</span>
                <select class="sec-input" [(ngModel)]="selectedExistingPatientId" (change)="onSelectExistingPatient()">
                  <option value="" disabled>-- Choose a registered patient --</option>
                  <option *ngFor="let p of patientList" [value]="p.id">
                    {{p.name}} — {{p.age}} yrs
                  </option>
                </select>
              </label>
            </div>

            <!-- Preview Card for Selected Existing Patient -->
            <div class="patient-selected-card" *ngIf="selectedPatient">
              <div class="sec-avatar" style="width:42px; height:42px; font-size:0.9rem;">
                {{selectedPatient.initials}}
              </div>
              <div class="patient-selected-info">
                <strong>{{selectedPatient.name}}</strong>
                <small>{{selectedPatient.age}} yrs &middot; {{selectedPatient.condition}}</small>
              </div>
              <div class="patient-selected-meta" style="margin-left:auto; display:flex; align-items:center; gap:10px;">
                <span class="health-pill" [class.good]="selectedPatient.health === 'Improving'" [class.neutral]="selectedPatient.health === 'Stable'" [class.warn]="selectedPatient.health === 'Needs attention'">
                  {{selectedPatient.health}}
                </span>
                <span style="font-size:0.75rem; color:#7a4f35; font-weight:700;">Recovery: {{selectedPatient.recovery}}%</span>
              </div>
            </div>
          </div>

          <!-- OPTION B: New Patient Registration -->
          <div class="patient-mode-section" *ngIf="patientMode === 'new'">
            <div class="new-patient-banner">
              <strong>✨ New Patient Registration</strong>
              <p>Fill out the details below. This patient will be automatically added to the clinic directory.</p>
            </div>
            <div class="sec-form-grid">
              <label class="sec-label">
                <span>Patient Full Name *</span>
                <input class="sec-input" [(ngModel)]="newPatientData.name" placeholder="e.g. Amr Diab" />
              </label>
              <label class="sec-label">
                <span>Age</span>
                <input class="sec-input" type="number" [(ngModel)]="newPatientData.age" placeholder="e.g. 45" />
              </label>
              <label class="sec-label">
                <span>Medical Condition / Prosthesis Need *</span>
                <input class="sec-input" [(ngModel)]="newPatientData.condition" placeholder="e.g. Right forearm amputation" />
              </label>
              <label class="sec-label">
                <span>Contact Phone</span>
                <input class="sec-input" [(ngModel)]="newPatientData.phone" placeholder="e.g. +20 100 123 4567" />
              </label>
            </div>
          </div>

          <!-- Common Appointment Details: Date, Time, Type, Fee, Status, Notes -->
          <h4 style="margin:16px 0 10px; color:#3b1f0e; font-size:0.85rem; text-transform:uppercase; letter-spacing:.05em;">
            Appointment Schedule & Pricing
          </h4>
          <div class="sec-form-grid">
            <label class="sec-label">
              <span>Appointment Date *</span>
              <input class="sec-input" type="date" [(ngModel)]="newAppt.date" [min]="todayDateStr" />
            </label>
            <label class="sec-label">
              <span>Time Slot *</span>
              <input class="sec-input" [(ngModel)]="newAppt.time" placeholder="e.g. 10:30 AM" />
            </label>
            <label class="sec-label">
              <span>Appointment Type</span>
              <select class="sec-input" [(ngModel)]="newAppt.type" (change)="onAppointmentTypeChange()">
                <option value="Training Session">Training Session (L.E. 350)</option>
                <option value="Progress Review">Progress Review (L.E. 300)</option>
                <option value="Device Maintenance">Device Maintenance (L.E. 500)</option>
                <option value="Routine Check-up">Routine Check-up (L.E. 250)</option>
                <option value="Recalibration">Recalibration (L.E. 250)</option>
                <option value="Advanced Training">Advanced Training (L.E. 400)</option>
                <option value="Initial Evaluation & Assessment">Initial Evaluation (L.E. 350)</option>
              </select>
            </label>
            <label class="sec-label">
              <span>Appointment Fee / Money (L.E.) *</span>
              <input class="sec-input" type="number" [(ngModel)]="newAppt.fee" placeholder="350" />
            </label>
            <label class="sec-label">
              <span>Payment Status</span>
              <select class="sec-input" [(ngModel)]="newAppt.paymentStatus">
                <option value="Paid">Paid (Add directly to Clinic Wallet)</option>
                <option value="Pending">Pending (Pay upon visit)</option>
              </select>
            </label>
            <label class="sec-label">
              <span>Session Objective / Clinical Notes</span>
              <input class="sec-input" [(ngModel)]="newAppt.notes" placeholder="e.g. Wrist rotation practice, electrode check..." />
            </label>
          </div>

          <div class="sec-form-actions" style="margin-top:18px;">
            <button class="sec-primary-btn" (click)="addAppointment()">
              ✓ Confirm & Add to Schedule
            </button>
            <button class="sec-ghost-btn" (click)="showAddForm = false">Cancel</button>
          </div>
        </div>

        <!-- Appointment Search & Filters -->
        <div class="appt-controls-bar">
          <div class="appt-search-box">
            <input class="sec-input"
                   [(ngModel)]="searchQuery"
                   placeholder="Search appointments by patient name, type, date..." />
          </div>
          <div class="appt-status-filters">
            <button class="wallet-filter-btn" [class.active]="filterStatus === 'all'" (click)="filterStatus = 'all'">
              All ({{appointments.length}})
            </button>
            <button class="wallet-filter-btn" [class.active]="filterStatus === 'Scheduled'" (click)="filterStatus = 'Scheduled'">
              Scheduled
            </button>
            <button class="wallet-filter-btn" [class.active]="filterStatus === 'Completed'" (click)="filterStatus = 'Completed'">
              Completed
            </button>
            <button class="wallet-filter-btn" [class.active]="filterStatus === 'Cancelled'" (click)="filterStatus = 'Cancelled'">
              Cancelled
            </button>
          </div>
        </div>

        <!-- Appointments Table with Money / Fee & Patient Badges -->
        <div class="sec-table-head appt-cols-with-fee">
          <span>Patient</span>
          <span>Date & Time</span>
          <span>Type</span>
          <span>Fee / Money</span>
          <span>Status</span>
          <span>Notes</span>
          <span>Actions</span>
        </div>
        <div class="sec-table-body">
          <div *ngFor="let a of filteredAppointments" class="sec-row appt-cols-with-fee">
            <!-- Patient -->
            <div class="sec-cell sec-patient-cell">
              <div class="sec-avatar">{{a.patientInitials || a.patientName[0]}}</div>
              <div>
                <strong>{{a.patientName}}</strong>
                
              </div>
            </div>

            <!-- Date & Time -->
            <div class="sec-cell">
              <span class="sec-date">{{a.date}}</span>
              <span class="sec-time">{{a.time}}</span>
            </div>

            <!-- Type -->
            <div class="sec-cell">
              <span class="sec-type-badge">{{a.type}}</span>
            </div>

            <!-- Money / Fee -->
            <div class="sec-cell">
              <div class="fee-display">
                <strong class="fee-amount">L.E. {{a.fee || 350}}</strong>
                <span class="fee-status-tag" [class.paid]="a.paymentStatus === 'Paid'" [class.pending]="a.paymentStatus === 'Pending'">
                  {{a.paymentStatus || (a.status === 'Completed' ? 'Paid' : 'Pending')}}
                </span>
              </div>
            </div>

            <!-- Status -->
            <div class="sec-cell">
              <span class="sec-status-pill"
                [class.scheduled]="a.status==='Scheduled'"
                [class.completed]="a.status==='Completed'"
                [class.cancelled]="a.status==='Cancelled'">
                {{a.status}}
              </span>
            </div>

            <!-- Notes -->
            <div class="sec-cell sec-notes">{{a.notes}}</div>

            <!-- Actions -->
            <div class="sec-cell sec-actions">
              <button class="sec-action-btn reschedule" *ngIf="a.status==='Scheduled'" (click)="reschedule(a)">Reschedule</button>
              <button class="sec-action-btn cancel-btn" *ngIf="a.status==='Scheduled'" (click)="cancelAppt(a)">Cancel</button>
              <button class="sec-action-btn pay-btn" *ngIf="a.status==='Scheduled' && a.paymentStatus==='Pending'" (click)="markPaid(a)">Mark Paid</button>
              <button class="sec-action-btn restore-btn" *ngIf="a.status==='Cancelled'" (click)="restoreAppt(a)">
                &#8635; Restore
              </button>
              <span class="sec-done-label" *ngIf="a.status==='Completed'">—</span>
            </div>
          </div>

          <div class="sec-row" *ngIf="filteredAppointments.length === 0" style="padding:28px; text-align:center; color:#7a4f35;">
            No appointments match your search filter.
          </div>
        </div>
      </section>
    </ng-container>

    <!-- ========================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================
         2. CLINIC WALLET TAB (New Option)
         ======================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================================== -->
    <ng-container *ngIf="activeTab === 'wallet'">
      <!-- Luxury Glassy Brown Clinic Wallet Card -->
      <section class="clinic-wallet-banner">
        <div class="wallet-card-chip">
          <div class="card-logo">
            <span class="card-chip-gold"></span>
            <span class="card-wifi">)))</span>
          </div>
          <div class="card-title">MYO CLINIC BUSINESS WALLET</div>
          <div class="card-balance-box">
            <small>CURRENT WALLET BALANCE</small>
            <div class="card-balance-number">L.E. {{walletBalance}}</div>
          </div>
          <div class="card-footer-info">
            <div>
              <span>WALLET HOLDER</span>
              <strong>Sara (Clinic Secretary)</strong>
            </div>
            <div>
              <span>ACCOUNT NO.</span>
              <strong>MYO-7741-CLINIC-WALLET</strong>
            </div>
            <div>
              <span>STATUS</span>
              <strong style="color:#5eead4;">ACTIVE</strong>
            </div>
          </div>
        </div>

        <div class="wallet-quick-actions">
          <h3>Wallet Actions</h3>
          <p>Instantly deposit incoming cash or register operational spending</p>
          <div class="wallet-action-buttons">
            <button class="sec-primary-btn" (click)="showDepositForm = !showDepositForm; showExpenseForm = false">
              <app-icon name="trend" [size]="15" style="margin-right:6px;"></app-icon>
              {{showDepositForm ? 'Close Deposit' : '+ Add Money / Deposit'}}
            </button>
            <button class="sec-ghost-btn" (click)="showExpenseForm = !showExpenseForm; showDepositForm = false">
              <app-icon name="target" [size]="15" style="margin-right:6px;"></app-icon>
              {{showExpenseForm ? 'Close Expense' : '+ Record Expense'}}
            </button>
          </div>
        </div>
      </section>

      <!-- Deposit Money Form -->
      <div class="sec-panel" *ngIf="showDepositForm" style="margin-bottom:1.5rem;">
        <div class="sec-form" style="background: rgba(255, 248, 242, 0.95);">
          <h3 class="sec-form-title">Deposit Funds into Clinic Wallet</h3>
          <div class="sec-form-grid">
            <label class="sec-label">
              <span>Patient or Source</span>
              <input class="sec-input" [(ngModel)]="newDeposit.patientName" placeholder="e.g. Adel Imam or Cash Deposit" />
            </label>
            <label class="sec-label">
              <span>Amount (L.E.)</span>
              <input class="sec-input" type="number" [(ngModel)]="newDeposit.amount" placeholder="350" />
            </label>
            <label class="sec-label">
              <span>Deposit Type</span>
              <select class="sec-input" [(ngModel)]="newDeposit.type">
                <option>Session fee</option>
                <option>Device maintenance</option>
                <option>Consultation</option>
                <option>Direct Deposit</option>
                <option>Equipment rental</option>
              </select>
            </label>
            <label class="sec-label">
              <span>Status</span>
              <select class="sec-input" [(ngModel)]="newDeposit.status">
                <option>Paid</option>
                <option>Pending</option>
              </select>
            </label>
          </div>
          <div class="sec-form-actions">
            <button class="sec-primary-btn" (click)="addDeposit()">Deposit Money</button>
            <button class="sec-ghost-btn" (click)="showDepositForm = false">Cancel</button>
          </div>
        </div>
      </div>

      <!-- Record Expense Form -->
      <div class="sec-panel" *ngIf="showExpenseForm" style="margin-bottom:1.5rem;">
        <div class="sec-form" style="background: rgba(255, 248, 242, 0.95);">
          <h3 class="sec-form-title">Record Clinic Expense (Pay from Wallet)</h3>
          <div class="sec-form-grid">
            <label class="sec-label">
              <span>Description</span>
              <input class="sec-input" [(ngModel)]="newExpense.description" placeholder="e.g. Electrode gel, Electricity..." />
            </label>
            <label class="sec-label">
              <span>Amount (L.E.)</span>
              <input class="sec-input" type="number" [(ngModel)]="newExpense.amount" placeholder="120" />
            </label>
            <label class="sec-label">
              <span>Category</span>
              <select class="sec-input" [(ngModel)]="newExpense.category">
                <option>Supplies</option>
                <option>Equipment</option>
                <option>Utilities</option>
                <option>Staff</option>
                <option>Other</option>
              </select>
            </label>
          </div>
          <div class="sec-form-actions">
            <button class="sec-primary-btn" (click)="addExpense()">Confirm & Pay Expense</button>
            <button class="sec-ghost-btn" (click)="showExpenseForm = false">Cancel</button>
          </div>
        </div>
      </div>

      <!-- Financial Metrics Grid -->
      <div class="sec-finance-grid" style="padding:0; margin-bottom:1.5rem;">
        <div class="sec-finance-card income">
          <span class="sec-finance-label">Total Income / Revenue</span>
          <strong class="sec-finance-value">L.E. {{totalIncome}}</strong>
          <span class="sec-finance-sub">{{revenues.length}} paid transactions</span>
        </div>
        <div class="sec-finance-card expense">
          <span class="sec-finance-label">Total Operational Expenses</span>
          <strong class="sec-finance-value">L.E. {{totalExpenses}}</strong>
          <span class="sec-finance-sub">{{expenses.length}} recorded expenses</span>
        </div>
        <div class="sec-finance-card" [class.profit]="netProfit >= 0" [class.loss]="netProfit < 0">
          <span class="sec-finance-label">Net Profit</span>
          <strong class="sec-finance-value">L.E. {{netProfit}}</strong>
          <span class="sec-finance-sub">{{netProfit >= 0 ? 'Positive balance' : 'Negative balance'}}</span>
        </div>
      </div>

      <!-- Wallet Transaction Ledger -->
      <section class="sec-panel">
        <div class="sec-panel-header">
          <div>
            <h2>Clinic Wallet Ledger & Transactions</h2>
            <p>Complete history of patient fees, deposits, and operational expenses</p>
          </div>
          <div class="wallet-filter-tabs">
            <button class="wallet-filter-btn" [class.active]="walletFilter === 'all'" (click)="walletFilter = 'all'">All</button>
            <button class="wallet-filter-btn" [class.active]="walletFilter === 'income'" (click)="walletFilter = 'income'">Income (+)</button>
            <button class="wallet-filter-btn" [class.active]="walletFilter === 'expense'" (click)="walletFilter = 'expense'">Expenses (-)</button>
          </div>
        </div>

        <div class="sec-table-head wallet-cols">
          <span>Transaction</span>
          <span>Date</span>
          <span>Category / Type</span>
          <span>Amount</span>
          <span>Status</span>
        </div>

        <div class="sec-table-body">
          <div *ngFor="let item of filteredTransactions" class="sec-row wallet-cols">
            <div class="sec-cell sec-patient-cell">
              <div class="transaction-icon" [class.income-icon]="item.type === 'income'" [class.expense-icon]="item.type === 'expense'">
                {{item.type === 'income' ? '+' : '-'}}
              </div>
              <div>
                <strong>{{item.title}}</strong>
                <small *ngIf="item.patientName" style="color:#7a4f35;">Patient: {{item.patientName}}</small>
              </div>
            </div>
            <div class="sec-cell sec-muted">{{item.date}}</div>
            <div class="sec-cell">
              <span class="sec-type-badge">{{item.category}}</span>
            </div>
            <div class="sec-cell">
              <strong [class.sec-amount-paid]="item.type === 'income'" [class.sec-amount-expense]="item.type === 'expense'">
                {{item.type === 'income' ? '+' : '-'}}L.E. {{item.amount}}
              </strong>
            </div>
            <div class="sec-cell">
              <span class="sec-status-pill" [class.completed]="item.status === 'Paid' || item.status === 'Completed'" [class.scheduled]="item.status === 'Pending'">
                {{item.status}}
              </span>
            </div>
          </div>
        </div>

        <div class="sec-totals-row">
          <span>Net Wallet Balance</span>
          <strong class="sec-amount-paid" style="font-size:1.2rem;">L.E. {{walletBalance}}</strong>
        </div>
      </section>

      <!-- Analytics Breakdown -->
      <section class="sec-panel" style="margin-top:1.5rem; padding: 20px 24px;">
        <h3 style="margin:0 0 1rem; color:#3b1f0e; font-size:1rem;">Revenue by Appointment & Service Type</h3>
        <div class="sec-breakdown-list" style="padding:0; margin-bottom:1.5rem;">
          <div *ngFor="let rt of revenueByType" class="sec-breakdown-row">
            <span>{{rt.type}}</span>
            <div class="sec-breakdown-bar-wrap">
              <div class="sec-breakdown-bar" [style.width.%]="rt.percent"></div>
            </div>
            <strong>L.E. {{rt.total}}</strong>
          </div>
        </div>

        <h3 style="margin:1rem 0 1rem; color:#3b1f0e; font-size:1rem;">Expenses by Clinic Category</h3>
        <div class="sec-breakdown-list" style="padding:0;">
          <div *ngFor="let ec of expensesByCategory" class="sec-breakdown-row">
            <span>{{ec.category}}</span>
            <div class="sec-breakdown-bar-wrap">
              <div class="sec-breakdown-bar expense-bar" [style.width.%]="ec.percent"></div>
            </div>
            <strong>L.E. {{ec.total}}</strong>
          </div>
        </div>
      </section>
    </ng-container>
  `
})
export class SecretaryDashboardComponent {
  @Input() activeTab: 'appointments' | 'wallet' = 'appointments';
  @Output() tabChange = new EventEmitter<'appointments' | 'wallet'>();

  showAddForm = false;
  showDepositForm = false;
  showExpenseForm = false;
  walletFilter: 'all' | 'income' | 'expense' = 'all';

  // Patient Selection Mode: 'existing' vs 'new'
  patientMode: 'existing' | 'new' = 'existing';
  selectedExistingPatientId = '';
  selectedPatient: Patient | null = null;

  // New Patient Form Model
  newPatientData = {
    name: '',
    age: 35,
    condition: '',
    phone: ''
  };

  searchQuery = '';
  filterStatus: 'all' | 'Scheduled' | 'Completed' | 'Cancelled' = 'all';

  // Only two primary options in Clinic Secretary: Appointments & Clinic Wallet
  tabs = [
    { id: 'appointments' as const, label: 'Appointments', icon: 'clock' },
    { id: 'wallet' as const, label: 'Clinic Wallet', icon: 'wallet' },
  ];

  patientList: Patient[] = PATIENTS;
  appointments: Appointment[] = [...APPOINTMENTS];
  revenues: Revenue[] = [...REVENUES];
  expenses: Expense[] = [...EXPENSES];

  todayDateStr: string = new Date().toISOString().split('T')[0];

  newAppt: Partial<Appointment> = {
    patientName: '',
    date: new Date().toISOString().split('T')[0],
    time: '10:30 AM',
    type: 'Training Session',
    notes: 'Routine progress training',
    status: 'Scheduled',
    patientInitials: '',
    fee: 350,
    paymentStatus: 'Paid'
  };

  newDeposit: Partial<Revenue> = {
    patientName: '',
    amount: 350,
    type: 'Session fee',
    status: 'Paid',
    date: 'Today'
  };

  newExpense: Partial<Expense> = {
    description: '',
    amount: 0,
    category: 'Supplies',
    date: 'Today'
  };

  showRegisterPatientForm = false;
  registerSuccessMsg = '';

  directPatient = {
    name: '',
    age: 38,
    condition: '',
    health: 'Stable' as Health,
    wearingHoursPerDay: 6,
    muscleHealth: 70,
    muscleStrength: 65,
    muscleEndurance: 60,
    muscleFlexibility: 65,
    notes: ''
  };

  constructor(public svc: AppService) {
    this.patientList = this.svc.patients;
    // Select the first patient by default for convenience
    if (this.patientList.length > 0) {
      this.selectedExistingPatientId = this.patientList[0].id;
      this.selectedPatient = this.patientList[0];
      this.newAppt.patientName = this.selectedPatient.name;
      this.newAppt.patientId = this.selectedPatient.id;
      this.newAppt.patientInitials = this.selectedPatient.initials;
    }
  }

  toggleRegisterPatientForm(): void {
    this.showRegisterPatientForm = !this.showRegisterPatientForm;
    if (this.showRegisterPatientForm) {
      this.showAddForm = false;
      this.registerSuccessMsg = '';
    }
  }

  submitDirectPatient(): void {
    if (!this.directPatient.name.trim()) {
      alert('Please enter patient full name.');
      return;
    }
    if (!this.directPatient.condition.trim()) {
      alert('Please enter patient medical condition.');
      return;
    }

    const name = this.directPatient.name.trim();
    const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    const id = 'p' + (this.svc.patients.length + 1);
    const mHealth = Number(this.directPatient.muscleHealth) || 70;
    const mStrength = Number(this.directPatient.muscleStrength) || 65;
    const mEndurance = Number(this.directPatient.muscleEndurance) || 60;
    const mFlexibility = Number(this.directPatient.muscleFlexibility) || 65;

    const newP: Patient = {
      id: id,
      name: name,
      initials: initials,
      age: Number(this.directPatient.age) || 35,
      condition: this.directPatient.condition.trim(),
      device: 'NM-' + Math.floor(Math.random() * 900 + 2850),
      battery: 100,
      signal: 'Strong',
      recovery: Math.min(100, Math.round(mHealth * 0.95)),
      accuracy: 92.0,
      health: this.directPatient.health || 'Stable',
      lastSession: 'Registered by Secretary',
      minutes: 0,
      streak: 1,
      note: this.directPatient.notes || 'Registered by Clinic Secretary. Ready for doctor evaluation.',
      wearingHoursPerDay: Number(this.directPatient.wearingHoursPerDay) || 6,
      totalWearingDays: 1,
      muscleHealth: mHealth,
      muscleRecoveryRate: mHealth >= 75 ? 'Good' : mHealth >= 55 ? 'Moderate' : 'Slow',
      muscleStrength: mStrength,
      muscleEndurance: mEndurance,
      muscleFlexibility: mFlexibility,
      muscleHistory: [
        { week: 'W1', score: Math.max(10, mHealth - 12) },
        { week: 'W2', score: Math.max(15, mHealth - 8) },
        { week: 'W3', score: Math.max(20, mHealth - 5) },
        { week: 'W4', score: Math.max(25, mHealth - 2) },
        { week: 'W5', score: mHealth },
        { week: 'W6', score: mHealth }
      ],
      trainingPlan: [
        { name: 'Initial prosthetic fitting & sensor check', url: 'https://www.youtube.com/results?search_query=Initial+prosthetic+fitting+and+sensor+check+prosthetic+arm' },
        { name: 'Grip and release exercises', url: 'https://www.youtube.com/results?search_query=Grip+and+release+exercises+prosthetic+arm' },
        { name: 'Wrist rotation practice', url: 'https://www.youtube.com/results?search_query=Wrist+rotation+practice+prosthetic+arm' },
        { name: 'Daily task simulation', url: 'https://www.youtube.com/results?search_query=Daily+task+simulation+prosthetic+arm' }
      ],
      medicines: [
        { name: 'Vitamin B12', dose: '1000 mcg', frequency: 'Once daily', purpose: 'Nerve health support' },
        { name: 'Magnesium', dose: '400 mg', frequency: 'Once at night', purpose: 'Muscle recovery & relaxation' }
      ],
      sessionHistory: []
    };

    // Add to shared service
    this.svc.addPatient(newP);
    this.patientList = this.svc.patients;

    this.registerSuccessMsg = `🎉 Patient "${name}" successfully registered and added to the Doctor's Directory!`;
    setTimeout(() => {
      this.showRegisterPatientForm = false;
      this.registerSuccessMsg = '';
      this.directPatient = {
        name: '',
        age: 38,
        condition: '',
        health: 'Stable',
        wearingHoursPerDay: 6,
        muscleHealth: 70,
        muscleStrength: 65,
        muscleEndurance: 60,
        muscleFlexibility: 65,
        notes: ''
      };
    }, 2200);
  }

  toggleAddForm(): void {
    this.showAddForm = !this.showAddForm;
    if (this.showAddForm && !this.selectedPatient && this.patientList.length > 0) {
      this.onSelectExistingPatient();
    }
  }

  setPatientMode(mode: 'existing' | 'new'): void {
    this.patientMode = mode;
    if (mode === 'existing') {
      if (this.selectedExistingPatientId) {
        this.onSelectExistingPatient();
      } else if (this.patientList.length > 0) {
        this.selectedExistingPatientId = this.patientList[0].id;
        this.onSelectExistingPatient();
      }
    } else {
      this.selectedPatient = null;
      this.newAppt.patientName = this.newPatientData.name || '';
      this.newAppt.patientId = '';
      this.newAppt.patientInitials = '';
    }
  }

  onSelectExistingPatient(): void {
    const found = this.patientList.find(p => p.id === this.selectedExistingPatientId);
    if (found) {
      this.selectedPatient = found;
      this.newAppt.patientName = found.name;
      this.newAppt.patientId = found.id;
      this.newAppt.patientInitials = found.initials;
    }
  }

  onAppointmentTypeChange(): void {
    const feeMap: Record<string, number> = {
      'Training Session': 350,
      'Progress Review': 300,
      'Device Maintenance': 500,
      'Routine Check-up': 250,
      'Recalibration': 250,
      'Advanced Training': 400,
      'Initial Evaluation & Assessment': 350
    };
    if (this.newAppt.type && feeMap[this.newAppt.type]) {
      this.newAppt.fee = feeMap[this.newAppt.type];
    }
  }

  selectTab(id: 'appointments' | 'wallet'): void {
    this.activeTab = id;
    this.tabChange.emit(id);
  }

  get todayAppointments() {
    return this.appointments.filter(a => a.date.toLowerCase().includes('today'));
  }

  get monthPatients(): number {
    const ids = new Set(
      this.appointments
        .filter((a: any) => a.date.includes('Nov') && a.date.includes('2026'))
        .map((a: any) => a.patientId)
    );
    return ids.size;
  }

  get totalIncome(): number {
    return this.revenues.filter(r => r.status === 'Paid').reduce((s, r) => s + r.amount, 0);
  }

  get totalExpenses(): number {
    return this.expenses.reduce((s, e) => s + e.amount, 0);
  }

  get netProfit(): number {
    return this.totalIncome - this.totalExpenses;
  }

  get walletBalance(): number {
    return 1500 + this.netProfit;
  }

  get revenueByType() {
    const map: Record<string, number> = {};
    this.revenues.forEach(r => map[r.type] = (map[r.type] || 0) + r.amount);
    const max = Math.max(...Object.values(map), 1);
    return Object.entries(map).map(([type, total]) => ({ type, total, percent: Math.round((total / max) * 100) }));
  }

  get expensesByCategory() {
    const map: Record<string, number> = {};
    this.expenses.forEach(e => map[e.category] = (map[e.category] || 0) + e.amount);
    const max = Math.max(...Object.values(map), 1);
    return Object.entries(map).map(([category, total]) => ({ category, total, percent: Math.round((total / max) * 100) }));
  }

  get allTransactions() {
    const revs = this.revenues.map(r => ({
      id: r.id,
      title: `${r.type} (${r.patientName})`,
      patientName: r.patientName,
      date: r.date,
      amount: r.amount,
      type: 'income' as const,
      category: r.type,
      status: r.status
    }));

    const exps = this.expenses.map(e => ({
      id: e.id,
      title: e.description,
      patientName: '',
      date: e.date,
      amount: e.amount,
      type: 'expense' as const,
      category: e.category,
      status: 'Completed'
    }));

    return [...revs, ...exps];
  }

  get filteredTransactions() {
    if (this.walletFilter === 'income') {
      return this.allTransactions.filter(t => t.type === 'income');
    }
    if (this.walletFilter === 'expense') {
      return this.allTransactions.filter(t => t.type === 'expense');
    }
    return this.allTransactions;
  }

  get filteredAppointments() {
    return this.appointments.filter(a => {
      const matchesStatus = this.filterStatus === 'all' || a.status === this.filterStatus;
      const q = this.searchQuery.toLowerCase().trim();
      const matchesQuery = !q ||
        a.patientName.toLowerCase().includes(q) ||
        a.type.toLowerCase().includes(q) ||
        a.date.toLowerCase().includes(q) ||
        a.notes.toLowerCase().includes(q);
      return matchesStatus && matchesQuery;
    });
  }

  addAppointment(): void {
    let patientName = '';
    let patientId = '';
    let patientInitials = '';

    if (this.patientMode === 'existing') {
      if (!this.selectedPatient) {
        alert('Please select an existing patient from the list.');
        return;
      }
      patientName = this.selectedPatient.name;
      patientId = this.selectedPatient.id;
      patientInitials = this.selectedPatient.initials;
    } else {
      // New Patient Mode
      if (!this.newPatientData.name.trim()) {
        alert('Please enter the new patient full name.');
        return;
      }
      patientName = this.newPatientData.name.trim();
      patientInitials = patientName.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
      patientId = 'p' + (this.patientList.length + 1);

      // Register new patient into clinic patient list
      const newPatient: Patient = {
        id: patientId,
        name: patientName,
        initials: patientInitials,
        age: this.newPatientData.age || 35,
        condition: this.newPatientData.condition || 'Prosthesis assessment',
        device: 'NM-' + Math.floor(Math.random() * 900 + 2850),
        battery: 100,
        signal: 'Strong',
        recovery: 50,
        accuracy: 90.0,
        health: 'Stable',
        lastSession: 'First appointment',
        minutes: 0,
        streak: 1,
        note: 'Newly registered patient. Initial consultation scheduled.',
        wearingHoursPerDay: 4,
        totalWearingDays: 1,
        muscleHealth: 70,
        muscleRecoveryRate: 'Good',
        trainingPlan: [
          { name: 'Initial assessment & fitting', url: 'https://www.youtube.com/results?search_query=Initial+prosthetic+assessment+fitting+prosthetic+arm' },
          { name: 'Baseline muscle signal test', url: 'https://www.youtube.com/results?search_query=Baseline+muscle+signal+test+EMG+prosthetic+arm' },
        ],
        muscleStrength: 50, muscleEndurance: 50, muscleFlexibility: 50,
        muscleHistory: [{ week: 'W1', score: 50 }],
        medicines: [],
        sessionHistory: []
      };

      this.svc.addPatient(newPatient);
      this.patientList = this.svc.patients;
      // Reset new patient fields
      this.newPatientData = { name: '', age: 35, condition: '', phone: '' };
    }

    if (!this.newAppt.date) {
      alert('Please provide an appointment date.');
      return;
    }

    const fee = Number(this.newAppt.fee) || 350;
    const paymentStatus = this.newAppt.paymentStatus || 'Paid';

    const appt: Appointment = {
      id: 'a' + Date.now(),
      patientId: patientId,
      patientName: patientName,
      patientInitials: patientInitials,
      date: this.newAppt.date,
      time: this.newAppt.time || '10:00 AM',
      type: this.newAppt.type || 'Training Session',
      status: 'Scheduled',
      notes: this.newAppt.notes || 'Routine check',
      fee: fee,
      paymentStatus: paymentStatus
    };

    this.appointments.unshift(appt);

    // If paid, register directly into wallet revenue
    if (paymentStatus === 'Paid') {
      this.revenues.unshift({
        id: 'r' + Date.now(),
        patientName: patientName,
        date: 'Today',
        amount: fee,
        type: appt.type,
        status: 'Paid'
      });
    }

    this.showAddForm = false;
  }

  reschedule(a: Appointment): void {
    const newDate = prompt('Enter new date for appointment:', a.date);
    const newTime = prompt('Enter new time for appointment:', a.time);
    if (newDate) a.date = newDate;
    if (newTime) a.time = newTime;
  }

  cancelAppt(a: Appointment): void {
    a.status = 'Cancelled';
  }

  restoreAppt(a: Appointment): void {
    a.status = 'Scheduled';
  }

  markPaid(a: Appointment): void {
    a.paymentStatus = 'Paid';
    this.revenues.unshift({
      id: 'r' + Date.now(),
      patientName: a.patientName,
      date: 'Today',
      amount: a.fee || 350,
      type: a.type,
      status: 'Paid'
    });
  }

  addDeposit(): void {
    if (!this.newDeposit.amount) return;
    this.revenues.unshift({
      id: 'r' + Date.now(),
      patientName: this.newDeposit.patientName || 'Clinic Cash Deposit',
      date: 'Today',
      amount: Number(this.newDeposit.amount),
      type: this.newDeposit.type || 'Direct Deposit',
      status: (this.newDeposit.status as any) || 'Paid'
    });

    this.newDeposit = {
      patientName: '',
      amount: 350,
      type: 'Session fee',
      status: 'Paid',
      date: 'Today'
    };
    this.showDepositForm = false;
  }

  addExpense(): void {
    if (!this.newExpense.description || !this.newExpense.amount) return;
    this.expenses.unshift({
      id: 'e' + Date.now(),
      description: this.newExpense.description,
      date: 'Today',
      amount: Number(this.newExpense.amount),
      category: this.newExpense.category || 'Supplies'
    });

    this.newExpense = {
      description: '',
      amount: 0,
      category: 'Supplies',
      date: 'Today'
    };
    this.showExpenseForm = false;
  }
}


