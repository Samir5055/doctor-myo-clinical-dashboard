import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-metric-card',
  template: `
    <button *ngIf="clickable; else staticCard"
            class="metric-card metric-card-button"
            (click)="cardClick.emit()"
            [attr.aria-label]="'Open ' + label">
      <ng-container *ngTemplateOutlet="cardContent"></ng-container>
    </button>
    <ng-template #staticCard>
      <article class="metric-card">
        <ng-container *ngTemplateOutlet="cardContent"></ng-container>
      </article>
    </ng-template>
    <ng-template #cardContent>
      <div class="metric-icon" [ngClass]="tone">
        <app-icon [name]="icon"></app-icon>
      </div>
      <div class="metric-copy">
        <span>{{label}}</span>
        <strong>{{value}}</strong>
        <small>{{detail}}</small>
      </div>
    </ng-template>
  `
})
export class MetricCardComponent {
  @Input() icon = '';
  @Input() label = '';
  @Input() value = '';
  @Input() detail = '';
  @Input() tone = 'blue';
  @Input() clickable = false;
  @Output() cardClick = new EventEmitter<void>();
}
