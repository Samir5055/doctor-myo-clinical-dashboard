import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Gesture, View } from '../models';
import { PATIENTS } from '../data';
import { AppService } from '../app.service';

@Component({
  selector: 'app-live-signal',
  template: `
    <section class="page-heading">
      <div>
        <button class="text-button back-link" (click)="setView.emit('overview')">
          <span style="transform:rotate(180deg);display:flex"><app-icon name="arrow" [size]="15"></app-icon></span>Overview
        </button>
        <p class="eyebrow">Real-time monitoring</p>
        <h1>Live MYOWARE 2.0 signal</h1>
        <p>Confirm sensor placement and signal quality before starting the session.</p>
      </div>
      <div class="connected-badge" [class.disconnected]="!connected">
        <span></span>MYOWARE 2.0 {{connected ? 'connected' : 'disconnected'}}
      </div>
    </section>

    <!-- Patient search bar -->
    <div class="ls-patient-bar">
      <div class="ls-search-wrap">
        <svg class="ls-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input class="select-control ls-search-input"
               placeholder="Search patient…"
               [(ngModel)]="query"
               (input)="showDropdown = true"
               (focus)="showDropdown = true" />
        <button *ngIf="query" class="ls-clear-btn" (click)="clearSearch()">✕</button>
      </div>

      <!-- Dropdown results -->
      <div class="ls-dropdown" *ngIf="showDropdown && filteredPatients.length > 0">
        <button *ngFor="let p of filteredPatients"
                class="ls-dropdown-item"
                (click)="selectPatient(p)">
          <span class="ls-p-avatar">{{p.initials}}</span>
          <span class="ls-p-info">
            <strong>{{p.name}}</strong>
            <small>{{p.age}} yrs · {{p.condition}}</small>
          </span>
          <span class="health-pill" [ngClass]="healthClass(p.health)" style="margin-left:auto;">{{p.health}}</span>
        </button>
      </div>

      <!-- Selected patient chip -->
      <div class="ls-selected-patient" *ngIf="selectedPatient">
        <span class="ls-p-avatar">{{selectedPatient.initials}}</span>
        <span>
          <strong>{{selectedPatient.name}}</strong>
          <small>· {{selectedPatient.condition}} · Muscle health: <b>{{selectedPatient.muscleHealth}}%</b></small>
        </span>
        <button class="ls-clear-btn" (click)="clearPatient()">✕</button>
      </div>
    </div>

    <div class="signal-layout">
      <app-signal-chart
        [connected]="connected"
        (gestureChange)="gesture = $event"
        (movementChange)="moving = $event"
        (placementChange)="placementCentered = $event">
      </app-signal-chart>
      <aside class="signal-side">
        <section class="panel connection-control" [class.connected]="connected" [class.disconnected]="!connected">
          <div class="connection-status">
            <span></span>
            <div>
              <strong>Signal connection</strong>
              <small>{{connected ? 'Sensor data is streaming' : 'Sensor data is offline'}}</small>
            </div>
          </div>
          <button (click)="toggleConnected.emit()">{{connected ? 'Disconnect signal' : 'Reconnect signal'}}</button>
        </section>
        <section class="panel gesture-panel">
          <div class="gesture-heading">
            <div><p class="eyebrow">Movement detection</p><h2>Hand gesture</h2></div>
            <span><i></i>Live</span>
          </div>
          <div class="gesture-grid" aria-live="polite">
            <div class="gesture-box" [class.active]="connected && gesture === 'clench'">
              <app-icon name="clench" [size]="28"></app-icon>
              <strong>Clenching</strong>
              <small>{{!connected ? 'Unavailable' : gesture === 'clench' ? 'Detected now' : 'Waiting'}}</small>
            </div>
            <div class="gesture-box" [class.active]="connected && gesture === 'spread'">
              <app-icon name="spread" [size]="28"></app-icon>
              <strong>Spreading</strong>
              <small>{{!connected ? 'Unavailable' : gesture === 'spread' ? 'Detected now' : 'Waiting'}}</small>
            </div>
            <div class="gesture-box gesture-box-wide" [class.active]="connected && moving">
              <app-icon name="movement" [size]="28"></app-icon>
              <strong>Any hand movement</strong>
              <small>{{!connected ? 'Unavailable' : moving ? 'Movement detected' : 'No movement'}}</small>
            </div>
          </div>
        </section>
        <section class="panel quality-card" [class.offline]="!connected">
          <div class="quality-top">
            <div>
              <h2>{{connected ? 'Excellent signal' : 'Signal unavailable'}}</h2>
              <p>{{connected ? 'Placement is ready for recording.' : 'Reconnect the sensor to continue monitoring.'}}</p>
            </div>
          </div>
          <div class="quality-checks">
            <div>
              <span><app-icon [name]="connected ? 'check' : 'close'" [size]="15"></app-icon></span>
              <p><strong>Skin contact</strong><small>{{connected ? 'Stable connection' : 'No connection'}}</small></p>
            </div>
            <div>
              <span><app-icon [name]="connected ? 'check' : 'close'" [size]="15"></app-icon></span>
              <p><strong>Signal-to-noise</strong><small>{{connected ? '28.4 dB &middot; Excellent' : 'Unavailable'}}</small></p>
            </div>
            <div>
              <span><app-icon [name]="connected ? 'check' : 'close'" [size]="15"></app-icon></span>
              <p><strong>Electrode position</strong><small>{{connected ? 'Aligned with muscle fibers' : 'Unavailable'}}</small></p>
            </div>
          </div>
        </section>
        <section class="sensor-confirmation" [class.passed]="connected && placementCentered" [class.failed]="!connected || !placementCentered">
          <span class="sensor-lamp" aria-hidden="true"></span>
          <div>
            <strong>{{!connected ? 'No sensor signal' : placementCentered ? 'Sensor placement confirmed' : 'Sensor placement needs adjustment'}}</strong>
            <p>{{!connected ? 'Reconnect the sensor to check its placement.' : placementCentered ? 'The sensor is centered on the muscle belly with minimal signal noise.' : 'Reposition the sensor on the muscle belly to reduce signal noise.'}}</p>
          </div>
        </section>
      </aside>
    </div>
  `,
  styles: [`
    /* ── Back link ── */
    .back-link { margin-bottom: 6px; }

    /* ── Patient search bar ── */
    .ls-patient-bar {
      position: relative;
      margin-bottom: 22px;
    }
    .ls-search-wrap {
      display: flex;
      align-items: center;
      gap: 10px;
      background: #fff;
      border: 1.5px solid var(--line);
      border-radius: 12px;
      padding: 0 14px;
      max-width: 480px;
      box-shadow: 0 2px 8px #0f766e0f;
      transition: border-color 0.2s;
    }
    .ls-search-wrap:focus-within { border-color: var(--blue); }
    .ls-search-icon { color: var(--muted); flex-shrink: 0; }
    .ls-search-input {
      border: 0 !important;
      box-shadow: none !important;
      padding: 11px 0 !important;
      background: transparent;
      flex: 1;
      min-width: 0;
    }
    .ls-clear-btn {
      border: 0;
      background: none;
      color: var(--muted);
      font-size: 0.8rem;
      cursor: pointer;
      padding: 2px 4px;
    }
    .ls-clear-btn:hover { color: #ef5350; }

    /* ── Dropdown ── */
    .ls-dropdown {
      position: absolute;
      top: calc(100% + 6px);
      left: 0;
      width: 480px;
      max-width: 100%;
      background: #fff;
      border: 1px solid var(--line);
      border-radius: 14px;
      box-shadow: 0 8px 28px #0f766e1a;
      z-index: 50;
      max-height: 260px;
      overflow-y: auto;
    }
    .ls-dropdown-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 11px 16px;
      border: 0;
      background: none;
      width: 100%;
      cursor: pointer;
      transition: background 0.15s;
      text-align: left;
    }
    .ls-dropdown-item:hover { background: #f4f9f8; }
    .ls-dropdown-item + .ls-dropdown-item { border-top: 1px solid var(--line); }

    /* ── Patient avatar pill ── */
    .ls-p-avatar {
      width: 36px; height: 36px;
      border-radius: 10px;
      background: var(--blue-soft);
      color: var(--blue);
      font-weight: 800; font-size: 0.75rem;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .ls-p-info { display: flex; flex-direction: column; gap: 2px; }
    .ls-p-info strong { font-size: 0.88rem; color: var(--ink); }
    .ls-p-info small { font-size: 0.75rem; color: var(--muted); }

    /* ── Selected patient chip ── */
    .ls-selected-patient {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 10px;
      padding: 10px 14px;
      background: #edfaf7;
      border: 1.5px solid #a7f3d0;
      border-radius: 12px;
      max-width: 480px;
    }
    .ls-selected-patient strong { font-size: 0.88rem; }
    .ls-selected-patient small { font-size: 0.78rem; color: var(--muted); margin-left: 6px; }
    .ls-selected-patient small b { color: var(--blue); }
  
    /* ══════════════════════════════════════════════════════
       DARK THEME FOR LIVE MYOWARE 2.0 SIGNAL & SEARCH BAR
       Colors:
         - Background: #0F172A
         - Cards:      #1E293B
         - Sidebar:    #111827
         - Primary:    #3B82F6
         - Text:       #FFFFFF
       ══════════════════════════════════════════════════════ */
    :host-context(.dark-theme) .back-link {
      color: #3B82F6 !important;
      font-weight: 700 !important;
    }
    :host-context(.dark-theme) .back-link:hover {
      color: #60A5FA !important;
    }

    /* Patient Search Bar in Dark Theme */
    :host-context(.dark-theme) .ls-search-wrap {
      background: #1E293B !important;
      border: 1.5px solid #334155 !important;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.35) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ls-search-wrap:focus-within {
      border-color: #3B82F6 !important;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.25) !important;
    }
    :host-context(.dark-theme) .ls-search-icon {
      color: #3B82F6 !important;
    }
    :host-context(.dark-theme) .ls-search-input {
      color: #FFFFFF !important;
      background: transparent !important;
    }
    :host-context(.dark-theme) .ls-search-input::placeholder {
      color: rgba(241, 245, 249, 0.6) !important;
    }
    :host-context(.dark-theme) .ls-clear-btn {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .ls-clear-btn:hover {
      color: #EF4444 !important;
      opacity: 1;
    }

    /* Search Dropdown in Dark Theme */
    :host-context(.dark-theme) .ls-dropdown {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5) !important;
    }
    :host-context(.dark-theme) .ls-dropdown-item {
      background: transparent !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ls-dropdown-item:hover {
      background: #0F172A !important;
    }
    :host-context(.dark-theme) .ls-dropdown-item + .ls-dropdown-item {
      border-top: 1px solid #334155 !important;
    }
    :host-context(.dark-theme) .ls-p-avatar {
      background: rgba(59, 130, 246, 0.25) !important;
      border: 1px solid rgba(59, 130, 246, 0.5) !important;
      color: #3B82F6 !important;
      font-weight: 800;
    }
    :host-context(.dark-theme) .ls-p-info strong {
      color: #FFFFFF !important;
      font-weight: 700 !important;
    }
    :host-context(.dark-theme) .ls-p-info small {
      color: #FFFFFF !important;
      opacity: 0.85;
    }

    /* Selected Patient Chip in Dark Theme */
    :host-context(.dark-theme) .ls-selected-patient {
      background: #1E293B !important;
      border: 1.5px solid #3B82F6 !important;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .ls-selected-patient strong {
      color: #FFFFFF !important;
      font-weight: 800 !important;
    }
    :host-context(.dark-theme) .ls-selected-patient small {
      color: #FFFFFF !important;
      opacity: 0.9;
    }
    :host-context(.dark-theme) .ls-selected-patient small b {
      color: #3B82F6 !important;
      font-weight: 800 !important;
    }

    /* Side Panels in Dark Theme */
    :host-context(.dark-theme) .connection-control {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.3) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .connection-status strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .connection-status small {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .connection-control button {
      background: #3B82F6 !important;
      color: #FFFFFF !important;
      border: none !important;
      font-weight: 700 !important;
    }
    :host-context(.dark-theme) .connection-control button:hover {
      background: #2563EB !important;
    }

    :host-context(.dark-theme) .gesture-panel {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.3) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-heading h2 {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-box {
      background: #0F172A !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-box strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-box small {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .gesture-box.active {
      background: rgba(59, 130, 246, 0.25) !important;
      border-color: #3B82F6 !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-box.active strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .gesture-box.active small {
      color: #3B82F6 !important;
      font-weight: 700 !important;
    }

    :host-context(.dark-theme) .quality-card {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.3) !important;
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .quality-top {
      border-bottom-color: #334155 !important;
    }
    :host-context(.dark-theme) .quality-ring {
      background: #0F172A !important;
      border-color: #334155 !important;
    }
    :host-context(.dark-theme) .quality-ring strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .quality-ring span {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .quality-top h2 {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .quality-top p {
      color: #FFFFFF !important;
      opacity: 0.85;
    }
    :host-context(.dark-theme) .quality-checks strong {
      color: #FFFFFF !important;
    }
    :host-context(.dark-theme) .quality-checks small {
      color: #FFFFFF !important;
      opacity: 0.85;
    }

    :host-context(.dark-theme) .sensor-confirmation {
      background: #1E293B !important;
      border: 1px solid #334155 !important;
      color: #FFFFFF !important;
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.3) !important;
    }
    :host-context(.dark-theme) .sensor-confirmation strong,
    :host-context(.dark-theme) .sensor-confirmation p {
      color: #FFFFFF !important;
    }
`]
})
export class LiveSignalComponent {
  @Input() connected = true;
  @Output() toggleConnected = new EventEmitter<void>();
  @Output() setView = new EventEmitter<View>();

  gesture: Gesture = 'spread';
  moving = false;
  placementCentered = true;

  query = '';
  showDropdown = false;
  selectedPatient: any = null;

  readonly allPatients = PATIENTS;

  constructor(private svc: AppService) {
    // Close dropdown on outside click
  }

  get filteredPatients() {
    if (!this.query.trim()) return this.allPatients.slice(0, 8);
    const q = this.query.toLowerCase();
    return this.allPatients.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.condition.toLowerCase().includes(q) ||
      p.id.includes(q)
    ).slice(0, 8);
  }

  selectPatient(p: any): void {
    this.selectedPatient = p;
    this.query = p.name;
    this.showDropdown = false;
    this.svc.setPatientId(p.id);
  }

  clearSearch(): void {
    this.query = '';
    this.showDropdown = false;
    this.selectedPatient = null;
  }

  clearPatient(): void {
    this.selectedPatient = null;
    this.query = '';
  }

  healthClass(h: string): string {
    return h === 'Needs attention' ? 'warn' : h === 'Improving' ? 'good' : 'neutral';
  }
}
