import { Component, Input, Output, EventEmitter } from '@angular/core';
import { View } from '../models';
import { AppService } from '../app.service';

@Component({
  selector: 'app-sidebar',
  template: `
    <aside class="sidebar" [class.sidebar-open]="open" [class.sec-sidebar]="role === 'secretary'">

      <!-- Brand -->
      <div class="brand">
        <div class="brand-mark"><img src="assets/prosthesis.png" alt="MYOArm prosthesis" /></div>
        <div><strong>MYOArm</strong><span>{{role === 'secretary' ? 'Clinic Secretary' : 'Clinic'}}</span></div>
        <button class="icon-button sidebar-close" (click)="closeSidebar()" aria-label="Close options">
          <app-icon name="close"></app-icon>
        </button>
      </div>

      <!-- Navigation -->
      <nav class="main-nav" aria-label="Main navigation">
        <p class="eyebrow">{{role === 'secretary' ? 'Secretary Menu' : 'Navigation'}}</p>
        <button *ngFor="let item of currentNavItems"
                class="nav-item"
                [class.active]="view === item.id"
                (click)="selectView(item.id)">
          <app-icon [name]="item.icon"></app-icon>
          <span>{{item.label}}</span>
        </button>
      </nav>

      <div class="sb-divider"></div>

      <!-- Sign Out -->
      <nav class="main-nav sb-bottom-nav" aria-label="Account">
        <p class="eyebrow">Account</p>
        <button class="nav-item signout-nav-item" (click)="signOut()">
          <app-icon name="signout"></app-icon>
          <span>Sign Out</span>
        </button>
      </nav>

      <!-- Spacer pushes help to bottom -->
      <div class="sb-spacer"></div>

      <!-- For Help box — collapsible, pinned to bottom -->
      <div class="sidebar-help sidebar-help-muted">
        <button class="help-toggle" (click)="helpOpen = !helpOpen">
          <p class="eyebrow" style="margin:0;">For help</p>
          <span class="help-chevron" [class.open]="helpOpen">&#9660;</span>
        </button>
        <div class="help-body" [class.help-body-open]="helpOpen">
          <a href="https://wa.me/201062570171" target="_blank" rel="noopener noreferrer">
            <span>WhatsApp</span>+20 1062570171
          </a>
          <a href="https://mail.google.com/mail/?view=cm&fs=1&to=sm30107900@gmail.com" target="_blank" rel="noopener noreferrer">
            <span>Email</span>sm30107900@gmail.com
          </a>
        </div>
      </div>

    </aside>
  `,
  styles: [`
    /* ── Spacer ──────────────────────────────────────────── */
    .sb-spacer { flex: 1; }

    /* ── Divider ─────────────────────────────────────────── */
    .sb-divider {
      height: 1px;
      margin: 6px 0;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4) 30%, rgba(255,255,255,0.4) 70%, transparent);
    }
    .sec-sidebar .sb-divider {
      background: linear-gradient(90deg, transparent, rgba(194,145,106,0.35) 30%, rgba(194,145,106,0.35) 70%, transparent);
    }

    /* ── Bottom nav ──────────────────────────────────────── */
    .sb-bottom-nav { padding-top: 0; }

    /* ── Sign-out item ───────────────────────────────────── */
    .signout-nav-item { color: #e05252 !important; }
    .signout-nav-item:hover {
      color: #c0392b !important;
      background: rgba(220,38,38,0.10) !important;
      border-color: rgba(220,38,38,0.22) !important;
    }
    .sec-sidebar .signout-nav-item { color: #c0392b !important; }
    .sec-sidebar .signout-nav-item:hover { background: rgba(220,38,38,0.09) !important; }

    /* ── Collapsible Help ────────────────────────────────── */
    .help-toggle {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      background: none;
      border: none;
      cursor: pointer;
      padding: 0;
      color: inherit;
    }
    .help-chevron {
      transition: transform 0.3s ease;
      display: inline-block;
      font-size: 0.75rem;
      opacity: 0.6;
    }
    .help-chevron.open { transform: rotate(180deg); }
    .help-body {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.35s cubic-bezier(0.4,0,0.2,1);
    }
    .help-body.help-body-open { max-height: 130px; }
  `]
})
export class SidebarComponent {
  @Input() view: View = 'overview';
  @Input() open = false;
  @Input() role: 'doctor' | 'secretary' = 'doctor';
  @Output() viewChange = new EventEmitter<View>();
  @Output() closeEvent = new EventEmitter<void>();
  @Output() collapseEvent = new EventEmitter<void>();

  helpOpen = false;

  constructor(public svc: AppService) {}

  get currentNavItems(): { id: View; label: string; icon: string }[] {
    if (this.role === 'secretary') {
      return [
        { id: 'appointments', label: 'Appointments', icon: 'clock' },
        { id: 'wallet', label: 'Clinic Wallet', icon: 'wallet' },
      ];
    }
    return [
      { id: 'overview', label: 'Overview', icon: 'home' },
      { id: 'signal', label: 'Live Signal', icon: 'signal' },
      { id: 'patients', label: 'Patients', icon: 'target' },
      { id: 'appointments', label: 'Appointments', icon: 'clock' },
    ];
  }

  selectView(id: View): void {
    this.viewChange.emit(id);
    this.closeEvent.emit();
  }

  closeSidebar(): void {
    this.closeEvent.emit();
    this.collapseEvent.emit();
  }

  signOut(): void {
    this.closeEvent.emit();
    this.svc.signOut();
  }
}
