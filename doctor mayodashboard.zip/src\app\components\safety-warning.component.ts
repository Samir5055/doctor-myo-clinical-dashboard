import { Component, Input, Output, EventEmitter } from '@angular/core';
import { DeviceSettings, getSafetyIssues, SafetyIssue } from '../models';

@Component({
  selector: 'app-safety-warning',
  template: `
    <section class="safety-warning" role="alert" *ngIf="issues.length > 0">
      <div class="safety-warning-icon"><app-icon name="info" [size]="20"></app-icon></div>
      <div>
        <strong>{{issues.length === 1 ? 'Safety action required' : issues.length + ' safety actions required'}}</strong>
        <ul>
          <li *ngFor="let issue of issues">
            <b>{{issue.title}}</b>
            <span>{{issue.detail}}</span>
          </li>
        </ul>
      </div>
      <button *ngIf="showReview" (click)="reviewClick.emit()">
        Review settings <app-icon name="arrow" [size]="15"></app-icon>
      </button>
    </section>
  `
})
export class SafetyWarningComponent {
  @Input() set settings(val: DeviceSettings) {
    this._settings = val;
    this.issues = getSafetyIssues(val);
  }
  @Input() showReview = false;
  @Output() reviewClick = new EventEmitter<void>();

  _settings!: DeviceSettings;
  issues: SafetyIssue[] = [];
}
