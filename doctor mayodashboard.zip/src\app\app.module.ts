import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { SidebarComponent } from './components/sidebar.component';
import { PageHeaderComponent } from './components/page-header.component';
import { IconComponent } from './components/icon.component';
import { MetricCardComponent } from './components/metric-card.component';
import { SafetyWarningComponent } from './components/safety-warning.component';
import { OverviewComponent } from './components/overview.component';
import { SignalChartComponent } from './components/signal-chart.component';
import { LiveSignalComponent } from './components/live-signal.component';
import { PatientsComponent } from './components/patients.component';
import { PatientStatusComponent } from './components/patient-status.component';
import { PatientHistoryComponent } from './components/patient-history.component';
import { AppointmentsComponent } from './components/appointments.component';
import { DevicesComponent } from './components/devices.component';
import { SecretaryDashboardComponent } from './components/secretary-dashboard.component';
import { ProfilePickerComponent } from './components/profile-picker.component';

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    PageHeaderComponent,
    IconComponent,
    MetricCardComponent,
    SafetyWarningComponent,
    OverviewComponent,
    SignalChartComponent,
    LiveSignalComponent,
    PatientsComponent,
    PatientStatusComponent,
    PatientHistoryComponent,
    AppointmentsComponent,
    DevicesComponent,
    SecretaryDashboardComponent,
    ProfilePickerComponent,
  ],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
