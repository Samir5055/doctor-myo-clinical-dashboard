import { Component, Input } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-icon',
  template: `<svg [attr.width]="size" [attr.height]="size" viewBox="0 0 24 24" fill="none"
       stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
       aria-hidden="true" [innerHTML]="getPath()"></svg>`,
  styles: [':host { display: inline-flex; align-items: center; }']
})
export class IconComponent {
  @Input() name = '';
  @Input() size = 20;

  constructor(private sanitizer: DomSanitizer) {}

  private paths: Record<string, string> = {
    home: '<path d="M3 10.8 12 3l9 7.8"/><path d="M5.5 9.5V21h13V9.5M9 21v-7h6v7"/>',
    signal: '<path d="M3 12h3l2.2-6 4 12 3.2-8 2 4H21"/>',
    device: '<rect x="6" y="3" width="12" height="18" rx="3"/><path d="M10 7h4M10 17h4"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    arrow: '<path d="m9 18 6-6-6-6"/>',
    bluetooth: '<path d="m7 7 10 10-5 4V3l5 4L7 17"/>',
    battery: '<rect x="3" y="7" width="17" height="10" rx="2"/><path d="M23 11v2M6 10h9v4H6z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
    trend: '<path d="m3 17 6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    prosthesis: '<path d="M7.5 10.5V6M10.5 10.5V3.5M13.5 10.5V3.5M16.5 10.5V6"/><path d="M5 10.5h14v3.2a2.3 2.3 0 0 1-2.3 2.3H7.3A2.3 2.3 0 0 1 5 13.7z"/><path d="M5 12.2 2.8 9.8"/><circle cx="12" cy="13.2" r="1" fill="currentColor"/><path d="M9 16v1.5M15 16v1.5M8 17.5h8V21H8zM8 19.2h8"/>',
    clench: '<path d="M6 10V8.5a2 2 0 0 1 4 0V10M10 9V7.5a2 2 0 0 1 4 0V10M14 9V8a2 2 0 0 1 4 0v5"/><path d="M6 10H5a2 2 0 0 0-2 2v1a8 8 0 0 0 8 8h1a7 7 0 0 0 7-7v-3a2 2 0 0 0-4 0v1"/>',
    spread: '<path d="M7 11V5a2 2 0 0 1 4 0v5M11 10V3.5a2 2 0 0 1 4 0V10M15 10V5a2 2 0 0 1 4 0v8"/><path d="M7 11 5.5 9.5a2 2 0 0 0-3 2.6l4.8 6A7 7 0 0 0 12.8 21H13a6 6 0 0 0 6-6v-2"/>',
    movement: '<path d="M8 8V5a2 2 0 0 1 4 0v4M12 8V4a2 2 0 0 1 4 0v6M16 9V6a2 2 0 0 1 4 0v7"/><path d="m8 10-2-2a2 2 0 0 0-3 2.7l4 5.3A7 7 0 0 0 12.6 19H14a6 6 0 0 0 6-6"/><path d="m3 4 2-2 2 2M5 2v4M21 18l-2 2-2-2M19 20v-4"/>',
    activity: '<path d="M22 12h-4l-3 8L9 4l-3 8H2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    wallet: '<rect x="2" y="6" width="20" height="13" rx="2.5"/><path d="M16 12.5h.01"/><path d="M2 10h20"/><circle cx="16" cy="12.5" r="1.5"/><path d="M6 6V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2"/>',
    signout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    options: '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>',
    switchuser: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  };

  getPath(): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(this.paths[this.name] || '');
  }
}
