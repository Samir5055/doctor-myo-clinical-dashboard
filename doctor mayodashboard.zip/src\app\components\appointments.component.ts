﻿import { Component } from '@angular/core';
import { Appointment } from '../models';
import { APPOINTMENTS } from '../data';

@Component({
  selector: 'app-appointments',
  template: `
    <!-- Page Header -->
    <section class="page-heading">
      <div>
        <p class="eyebrow">Clinic schedule</p>
        <h1>Appointments</h1>
        <p>Manage and review all patient appointments.</p>
      </div>
      <div class="appt-summary-badges">
        <div class="appt-badge appt-badge-scheduled">
          <strong>{{countByStatus('Scheduled')}}</strong>
          <span>Upcoming</span>
        </div>
        <div class="appt-badge appt-badge-completed">
          <strong>{{countByStatus('Completed')}}</strong>
          <span>Completed</span>
        </div>
        <div class="appt-badge appt-badge-cancelled">
          <strong>{{countByStatus('Cancelled')}}</strong>
          <span>Cancelled</span>
        </div>
      </div>
    </section>

    <!-- Filter Bar -->
    <div class="appt-filter-bar">
      <button *ngFor="let f of filters"
              class="appt-filter-btn"
              [class.active]="filter === f.value"
              (click)="filter = f.value">
        {{f.label}}
        <span class="appt-filter-count">{{f.value === 'all' ? appointments.length : countByStatus(f.value)}}</span>
      </button>
    </div>

    <!-- Appointments Table -->
    <section class="panel appt-table-panel">
      <!-- Table Header -->
      <div class="appt-table-head">
        <span>Patient</span>
        <span>Date &amp; Time</span>
        <span>Appointment Type</span>
        <span>Fee</span>
        <span>Status</span>
        <span>Clinical Notes</span>
        <span>Action</span>
      </div>

      <!-- Rows -->
      <div class="appt-table-body">
        <div *ngFor="let a of filteredAppointments" class="appt-row"
             [class.appt-row-cancelled]="a.status === 'Cancelled'">

          <!-- Patient -->
          <div class="appt-cell appt-patient">
            <div class="patient-avatar appt-avatar">{{a.patientInitials}}</div>
            <div>
              <strong>{{a.patientName}}</strong>
              
            </div>
          </div>

          <!-- Date & Time -->
          <div class="appt-cell appt-datetime">
            <span class="appt-date">{{a.date}}</span>
            <span class="appt-time">{{a.time}}</span>
          </div>

          <!-- Type -->
          <div class="appt-cell">
            <span class="appt-type-badge">{{a.type}}</span>
          </div>

          <!-- Fee -->
          <div class="appt-cell">
            <strong style="color: #0d9488; font-size: 0.95rem;">L.E. {{a.fee || 350}}</strong>
          </div>

          <!-- Status -->
          <div class="appt-cell">
            <span class="health-pill"
              [class.good]="a.status === 'Completed'"
              [class.warn]="a.status === 'Cancelled'"
              [class.neutral]="a.status === 'Scheduled'">
              <i class="appt-status-dot"></i>{{a.status}}
            </span>
          </div>

          <!-- Notes -->
          <div class="appt-cell appt-notes">
            <span>{{a.notes}}</span>
          </div>

          <!-- Action -->
          <div class="appt-cell appt-action-cell">
            <!-- Scheduled -> can Cancel -->
            <button *ngIf="a.status === 'Scheduled'"
                    class="appt-action-btn appt-cancel-btn"
                    (click)="cancelAppointment(a)"
                    title="Cancel appointment">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
              Cancel
            </button>

            <!-- Cancelled -> can Restore -->
            <button *ngIf="a.status === 'Cancelled'"
                    class="appt-action-btn appt-restore-btn"
                    (click)="restoreAppointment(a)"
                    title="Restore to Scheduled">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.5"/>
              </svg>
              Restore
            </button>

            <!-- Completed -> no action -->
            <span *ngIf="a.status === 'Completed'" class="appt-action-done">—</span>
          </div>

        </div>

        <div class="appt-empty" *ngIf="filteredAppointments.length === 0">
          <app-icon name="info" [size]="20"></app-icon>
          <span>No appointments found for this filter.</span>
        </div>
      </div>
    </section>

    <!-- Toast notification -->
    <div class="appt-toast" [class.appt-toast-show]="toastMsg" [class.appt-toast-restore]="toastType === 'restore'">
      <span>{{toastMsg}}</span>
    </div>
  `,
  styles: [`
    /* Cancelled row dim */
    .appt-row-cancelled {
      opacity: 0.65;
    }

    /* Action column */
    .appt-action-cell {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .appt-action-done {
      color: rgba(255,255,255,0.25);
      font-size: 1rem;
    }

    /* Base action button */
    .appt-action-btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 12px;
      border-radius: 20px;
      border: none;
      font-size: 0.75rem;
      font-weight: 700;
      cursor: pointer;
      transition: transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease;
      white-space: nowrap;
    }
    .appt-action-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.25);
    }
    .appt-action-btn:active { transform: scale(0.96); }

    /* Cancel - red */
    .appt-cancel-btn {
      background: rgba(220,38,38,0.15);
      color: #f87171;
      border: 1px solid rgba(220,38,38,0.3);
    }
    .appt-cancel-btn:hover {
      background: rgba(220,38,38,0.28);
      color: #fca5a5;
    }

    /* Restore - green */
    .appt-restore-btn {
      background: rgba(16,185,129,0.15);
      color: #34d399;
      border: 1px solid rgba(16,185,129,0.3);
    }
    .appt-restore-btn:hover {
      background: rgba(16,185,129,0.28);
      color: #6ee7b7;
    }

    /* Toast */
    .appt-toast {
      position: fixed;
      bottom: 28px;
      left: 50%;
      transform: translateX(-50%) translateY(80px);
      background: rgba(220,38,38,0.92);
      color: #fff;
      padding: 11px 24px;
      border-radius: 24px;
      font-size: 0.85rem;
      font-weight: 600;
      box-shadow: 0 8px 28px rgba(0,0,0,0.35);
      opacity: 0;
      transition: transform 0.3s ease, opacity 0.3s ease;
      pointer-events: none;
      z-index: 999;
      white-space: nowrap;
    }
    .appt-toast.appt-toast-show {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }
    .appt-toast.appt-toast-restore {
      background: rgba(16,185,129,0.92);
    }
  `]
})
export class AppointmentsComponent {
  filter: string = 'all';
  appointments: Appointment[] = APPOINTMENTS;
  toastMsg = '';
  toastType: 'cancel' | 'restore' = 'cancel';
  private toastTimer: any;

  filters = [
    { label: 'All appointments', value: 'all' },
    { label: 'Scheduled', value: 'Scheduled' },
    { label: 'Completed', value: 'Completed' },
    { label: 'Cancelled', value: 'Cancelled' },
  ];

  get filteredAppointments(): Appointment[] {
    if (this.filter === 'all') return this.appointments;
    return this.appointments.filter(a => a.status === this.filter);
  }

  countByStatus(status: string): number {
    return this.appointments.filter(a => a.status === status).length;
  }

  cancelAppointment(a: Appointment): void {
    a.status = 'Cancelled';
    this.showToast(`Appointment for ${a.patientName} cancelled`, 'cancel');
  }

  restoreAppointment(a: Appointment): void {
    a.status = 'Scheduled';
    this.showToast(`Appointment for ${a.patientName} restored to Scheduled`, 'restore');
  }

  private showToast(msg: string, type: 'cancel' | 'restore'): void {
    this.toastMsg = msg;
    this.toastType = type;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { this.toastMsg = ''; }, 3000);
  }
}

